# Volt Hosting

A complete game-server hosting site: storefront, checkout, customer dashboard, support desk and admin panel. Orders provision real Pterodactyl servers, email the customer their panel credentials, and post branded events to Discord.

Built with Next.js 16 (App Router, Cache Components), React 19, Tailwind CSS 4, the shadcn base-nova preset, and Node's built-in SQLite.

---

## What is in the box

**Storefront**
- Glassmorphism, light-blue landing page with interactive hero console, game categories, custom server builder, region map, testimonials and FAQ.
- Six seeded categories: Minecraft, FiveM, Rust, SA-MP, Discord bots and Cloud VPS.
- Store index, per-game plan pages, and a configurator that prices RAM, CPU, NVMe and backup slots from admin settings.

**Checkout and provisioning**
- Login required, three payment method types: **Discord ticket** (UPI, Google Pay and other transfers), **manual / bank transfer**, and **Stripe Checkout**.
- Promo codes: percentage or fixed-amount discounts with a minimum spend, usage cap and expiry, all validated on the server.
- On payment, a Pterodactyl account is created for the customer (or reused by email), a server is built from the product/category egg overrides, and the panel username + password are emailed.
- Status appears in the dashboard within seconds: `installing → running`, plus a link to the panel and a one-click credential resend.

**Customer dashboard**
- Overview, servers with live status, billing/orders, account profile (avatar, bio and Discord handle) and password, support tickets with replies.
- Order progress polling on the checkout success page.

**Support**
- Ticket threads, priority and status, staff replies that email the customer, reopen/close.

**Admin panel**
- Overview with revenue chart, pending orders and attention list.
- Orders: mark paid, retry provisioning, cancel, refund, inspect the provisioned server.
- Servers: sync from panel, suspend/unsuspend, private notes, credentials.
- Products and categories with Pterodactyl overrides (nest, egg, docker image, startup, environment, allocation).
- Customers and roles, tickets, payments, promo codes, site/pricing/panel/SMTP/Discord settings, email log.

**Integrations**
- Discord webhooks for signups, paid orders, pending orders and tickets, with branded embeds and a test button per feed.
- SMTP (works with Gmail app passwords) with every attempt logged.
- Stripe webhook with HMAC signature verification at `/api/webhooks/stripe`.

---

## Requirements

- **Node.js 24 or newer** — the app uses the built-in `node:sqlite` module.
- A writable folder for the database (defaults to `./data/volt.db`).

## Quick start

```bash
npm install
cp .env.example .env.local   # then edit AUTH_SECRET and ADMIN_PASSWORD
npm run dev
```

Open http://localhost:3000.

The first boot creates the schema, seeds categories, products, the UPI/GPay, bank-transfer and Stripe payment methods, payment/pricing/site settings, and an admin account.

Default sign-in (change it in `.env.local` before first boot, or from the dashboard afterwards):

| Role | Email | Password |
| --- | --- | --- |
| Admin | `admin@volthosting.gg` | `VoltAdmin!2026` |

> To accept UPI or Google Pay, leave the **UPI, GPay & more** method enabled, fill in your Discord invite under **Admin → Payments**, and confirm each transfer before pressing **Mark paid & provision** on the order.

## Environment variables

| Variable | Purpose |
| --- | --- |
| `AUTH_SECRET` | Signs sessions and derives the AES-256-GCM key for panel/payment secrets. **Change this in production; rotating it invalidates sessions and stored secrets.** |
| `ADMIN_EMAIL`, `ADMIN_NAME`, `ADMIN_PASSWORD` | Used only when the first admin is created. |
| `VOLT_DB_PATH` | Optional path to the SQLite file. |
| `PORT` | Standard Next.js port override. |

Everything else — site branding, pricing, Pterodactyl, SMTP, Discord, payment gateways — is configured in **Admin → Settings** and stored in the database.

## Connecting Pterodactyl

1. In the panel, create an **Application API key** (Admin → Application API) with read/write access for servers, users and nodes.
2. In **Admin → Settings → Pterodactyl**, set the panel URL, paste the key, and fill the default node, nest, egg, allocation and docker image. These are fallbacks; a category or product can override the egg fields.
3. Press **Test connection**. It should report the nodes visible to the key.
4. Turn on **Provision servers automatically through the panel API**. Save.

With provisioning off, paid orders are marked failed with a clear message instead of disappearing — connect the panel, then use **Retry provisioning** on the order.

When provisioning a server the app:
- finds or creates a panel user (stored encrypted),
- creates the server with the planned RAM/disk/CPU/backup/database/allocation limits,
- stores the panel server id, uuid, address and credentials,
- emails the customer their login.

If the panel rejects the request, the order is marked failed with the panel's error on the order page, and **Retry provisioning** is available there.

## Email (SMTP / Gmail)

In **Admin → Settings → Email**, enable email and fill host, port, username, password, from name and address.

For Gmail: host `smtp.gmail.com`, port `587`, TLS off (STARTTLS), and a 16-character **App Password** (Google Account → Security → 2-Step Verification → App passwords) rather than your normal password. Port `465` with TLS on also works.

With email disabled, messages are recorded as **simulated** in **Admin → Email log** — useful for local testing.

## Discord webhooks

Create one webhook per channel (or reuse one) and paste the URLs in **Admin → Settings → Discord**. Signups, paid orders, orders waiting on UPI payment and new support tickets each post a branded embed: your site name and avatar as the author, an event colour, compact fields and a footer. All three channels are optional, and each feed has a **Test** button that sends a realistic sample without waiting for a customer.

## UPI, Google Pay and Discord-ticket payments

The seeded **UPI, GPay & more** method uses type **Discord**:

1. **Admin → Payments → UPI, GPay & more** — write the instructions the customer sees (UPI ID, QR upload link, what to include in the ticket) and paste your Discord invite. If you leave the invite blank, the site-wide invite from **Settings → Site** is used.
2. At checkout the customer picks the method, places the order, and lands on a confirmation page with the order number, the instructions and a **Open a ticket in Discord** button.
3. The order is **pending**, and the purchase webhook posts an *awaiting payment* embed with a link to the admin order.
4. Confirm the transfer yourself, then press **Mark paid & provision** on the order. That creates the Pterodactyl server and emails the customer their credentials.

Bank transfer is the same flow with type **Manual** and no Discord link.

## Promo codes

**Admin → Promo codes** creates discounts that appear in the checkout promo field.

- **Percent** takes 1–100% off; **fixed** takes a dollar amount off.
- Optional minimum spend, total usage cap and expiry date.
- The checkout price preview and the final order both re-check the code on the server — the browser cannot invent a discount.
- Usage is counted once, when the order is first marked paid.

## Stripe

1. Add a payment method in **Admin → Payments → Add method**, choose **Stripe**, and paste the publishable key, secret key and webhook signing secret. Secrets are stored encrypted and never sent to the browser.
2. In the Stripe dashboard, add an endpoint pointing to `https://your-domain/api/webhooks/stripe` for `checkout.session.completed` and `checkout.session.async_payment_succeeded`.
3. Make sure **Admin → Settings → Site → Public app URL** matches the real origin, since it is used to build the Stripe success/cancel URLs.
4. For local testing: `stripe listen --forward-to localhost:3000/api/webhooks/stripe`, then paste the printed `whsec_…` into the gateway.

The webhook verifies the `Stripe-Signature` header against the saved secret (5-minute tolerance), re-checks the order, provisions idempotently, and returns `500` if provisioning fails so Stripe retries.

## Scripts

```bash
npm run dev      # development server
npm run build    # production build
npm run start    # run the production build
npm run lint     # eslint
```

There is no separate typecheck script; `npx tsc --noEmit` works.

## Data and backups

SQLite lives in `./data/volt.db` (WAL mode) and is created automatically. Back up that folder — it contains users, orders, servers, tickets, settings and the email log. Panel credentials and Stripe secrets inside it are encrypted with `AUTH_SECRET`, so keep both the database **and** the secret.

`data/` and `.env*` are gitignored.

## Deploying

- Run a single instance (or a single writer) — embedded SQLite is not a multi-writer cluster.
- Set a strong `AUTH_SECRET`, set cookies over HTTPS, and put the app behind a reverse proxy that forwards `X-Forwarded-*`.
- Point the admin **Public app URL** at the public origin.
- Keep `data/` on persistent storage.
- `next build` prerenders most marketing pages; admin and dashboard render dynamically.

## Project map

```
src/
  app/
    (site)/            landing, store, checkout, support, legal, status
    (auth)/            login, register
    dashboard/         customer area
    admin/             operator area
    api/webhooks/      Stripe webhook
  components/          UI, forms, chrome, plan cards
  lib/
    db.ts              schema + seeds
    actions/           auth, checkout, support, servers, admin
    provision.ts       Pterodactyl provisioning, credentials email
    promo.ts           promo code validation and discount maths
    pterodactyl.ts     Application API client
    mail.ts            SMTP + HTML templates + email log
    discord.ts         webhook embeds
    queries.ts         reads and settings
  proxy.ts             optimistic cookie redirect for /dashboard and /admin
```

## Common issues

- **`node:sqlite` not found** — upgrade to Node 24+.
- **Nothing is emailed** — SMTP is off or credentials are wrong. Check **Admin → Email log** for the exact error; Gmail needs an app password.
- **Order stuck on pending** — Discord/manual method: mark it paid once the transfer arrives. Stripe: check the webhook secret and endpoint events.
- **Provisioning fails** — the panel's error is shown on the order page. Usual causes: wrong nest/egg id, allocation already assigned, or the application key lacks server-create permission.
- **Sessions vanish after deploy** — `AUTH_SECRET` changed. Use one stable value.

---

Built as a complete reference implementation. The marketing copy, seeded plans and stats are illustrative; replace them with your own before selling.
