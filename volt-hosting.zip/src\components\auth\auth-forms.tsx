"use client";

import { useActionState, useState } from "react";
import Link from "next/link";
import { ArrowRight, Eye, EyeOff, Loader2 } from "lucide-react";
import { loginAction, registerAction } from "@/lib/actions/auth";
import type { ActionState } from "@/lib/types";

function Alert({ state }: { state: ActionState }) {
  if (!state?.error) return null;
  return (
    <p
      role="alert"
      className="rounded-lg border border-[#f3c6c6] bg-[#fff5f5] px-3 py-2 text-[0.78rem] text-[#a13b3b]"
    >
      {state.error}
    </p>
  );
}

function PasswordField({
  name = "password",
  label = "Password",
  autoComplete = "current-password",
  hint,
  placeholder = "••••••••",
}: {
  name?: string;
  label?: string;
  autoComplete?: string;
  hint?: string;
  placeholder?: string;
}) {
  const [visible, setVisible] = useState(false);
  return (
    <div>
      <label htmlFor={name} className="field-label">
        {label}
      </label>
      <div className="relative">
        <input
          id={name}
          name={name}
          type={visible ? "text" : "password"}
          autoComplete={autoComplete}
          required
          placeholder={placeholder}
          className="input pr-10"
        />
        <button
          type="button"
          onClick={() => setVisible((current) => !current)}
          aria-label={visible ? "Hide password" : "Show password"}
          aria-pressed={visible}
          className="absolute right-1 top-1 grid size-8 place-items-center rounded-md text-mutedblue transition hover:bg-white hover:text-ink"
        >
          {visible ? <EyeOff className="size-3.5" /> : <Eye className="size-3.5" />}
        </button>
      </div>
      {hint && <p className="field-hint">{hint}</p>}
    </div>
  );
}

export function LoginForm({ next }: { next?: string }) {
  const [state, action, pending] = useActionState(loginAction, null);

  return (
    <div>
      <h2 className="display-soft text-[1.45rem] text-ink">Welcome back</h2>
      <p className="mt-1 text-[0.8rem] text-ink-soft/80">
        Sign in to reach your servers, invoices and tickets.
      </p>

      <form action={action} className="mt-5 space-y-3.5">
        {next && <input type="hidden" name="next" value={next} />}
        <Alert state={state} />

        <div>
          <label htmlFor="email" className="field-label">
            Email
          </label>
          <input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            required
            placeholder="you@example.com"
            className="input"
          />
        </div>

        <PasswordField />

        <button type="submit" disabled={pending} className="btn btn-primary w-full">
          {pending ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Signing in
            </>
          ) : (
            <>
              Sign in
              <ArrowRight className="size-4" />
            </>
          )}
        </button>
      </form>

      <p className="mt-4 text-center text-[0.78rem] text-mutedblue">
        New here?{" "}
        <Link
          href={next ? `/register?next=${encodeURIComponent(next)}` : "/register"}
          className="font-semibold text-[#0a63ff] hover:underline"
        >
          Create an account
        </Link>
      </p>
    </div>
  );
}

export function RegisterForm({ next }: { next?: string }) {
  const [state, action, pending] = useActionState(registerAction, null);

  return (
    <div>
      <h2 className="display-soft text-[1.45rem] text-ink">Create your account</h2>
      <p className="mt-1 text-[0.8rem] text-ink-soft/80">
        Takes about twenty seconds. Your first server can follow right after.
      </p>

      <form action={action} className="mt-5 space-y-3.5">
        {next && <input type="hidden" name="next" value={next} />}
        <Alert state={state} />

        <div>
          <label htmlFor="name" className="field-label">
            Name
          </label>
          <input
            id="name"
            name="name"
            autoComplete="name"
            required
            placeholder="Your name"
            className="input"
          />
        </div>

        <div>
          <label htmlFor="email" className="field-label">
            Email
          </label>
          <input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            required
            placeholder="you@example.com"
            className="input"
          />
          <p className="field-hint">Panel credentials go to this address.</p>
        </div>

        <PasswordField
          label="Password"
          autoComplete="new-password"
          hint="8+ characters, with a letter and a number."
        />

        <PasswordField
          name="confirm"
          label="Confirm password"
          autoComplete="new-password"
        />

        <button type="submit" disabled={pending} className="btn btn-primary w-full">
          {pending ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Creating account
            </>
          ) : (
            <>
              Create account
              <ArrowRight className="size-4" />
            </>
          )}
        </button>
      </form>

      <p className="mt-3 text-[0.66rem] leading-relaxed text-mutedblue">
        By creating an account you agree to the{" "}
        <Link href="/terms" className="underline hover:text-ink">
          terms of service
        </Link>{" "}
        and{" "}
        <Link href="/privacy" className="underline hover:text-ink">
          privacy policy
        </Link>
        .
      </p>

      <p className="mt-3 text-center text-[0.78rem] text-mutedblue">
        Already have an account?{" "}
        <Link
          href={next ? `/login?next=${encodeURIComponent(next)}` : "/login"}
          className="font-semibold text-[#0a63ff] hover:underline"
        >
          Sign in
        </Link>
      </p>
    </div>
  );
}
