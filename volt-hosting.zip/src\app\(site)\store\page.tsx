import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Globe2, ShieldCheck, Timer } from "lucide-react";
import { GameIcon, GAME_ORBS } from "@/components/game-icon";
import { PlanCard } from "@/components/plan-card";
import { GAME_META } from "@/lib/defaults";
import { money } from "@/lib/format";
import { getCategories, getFeaturedProducts, getProducts } from "@/lib/queries";

export const metadata: Metadata = {
  title: "Game server hosting",
  description:
    "Minecraft, FiveM, Rust, SA-MP, Discord bots and VPS hosting on Ryzen 9 hardware with NVMe storage and DDoS filtering.",
};

export default function StorePage() {
  const categories = getCategories({ activeOnly: true });
  const products = getProducts({ activeOnly: true });
  const featured = getFeaturedProducts();

  return (
    <>
      <section className="relative overflow-hidden pb-8 pt-8 sm:pt-10">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -left-40 top-0 -z-10 size-[34rem] rounded-full bg-[radial-gradient(circle,rgba(86,197,255,0.28),transparent_68%)] blur-2xl"
        />
        <div className="container-x">
          <nav aria-label="Breadcrumb" className="text-[0.72rem] text-mutedblue">
            <Link href="/" className="hover:text-ink">
              Home
            </Link>
            <span className="mx-1.5">/</span>
            <span className="text-ink">Store</span>
          </nav>

          <div className="mt-5 grid items-end gap-6 lg:grid-cols-[1fr_auto]">
            <div>
              <h1 className="display max-w-[18ch] text-[2.3rem] text-ink sm:text-[3rem]">
                Choose the world. We handle the rest.
              </h1>
              <p className="lede mt-4 max-w-[52ch]">
                Six hosting categories, one control plane. Every plan includes
                the Pterodactyl panel, NVMe storage, backups and game-aware DDoS
                filtering.
              </p>
            </div>
            <dl className="flex flex-wrap gap-x-6 gap-y-2 text-[0.76rem] text-ink-soft/80">
              {[
                { icon: Timer, label: "90-second setup" },
                { icon: Globe2, label: "Eight regions" },
                { icon: ShieldCheck, label: "DDoS included" },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.label} className="inline-flex items-center gap-1.5">
                    <Icon className="size-3.5 text-[#0a63ff]" />
                    {item.label}
                  </div>
                );
              })}
            </dl>
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {categories.map((category) => {
              const meta = GAME_META[category.slug];
              const plans = products.filter(
                (product) => product.category_id === category.id,
              );
              const from = plans.reduce(
                (lowest, plan) => Math.min(lowest, plan.price_cents),
                Number.POSITIVE_INFINITY,
              );
              return (
                <Link
                  key={category.id}
                  href={`/store/${category.slug}`}
                  className="glass group relative overflow-hidden rounded-2xl p-5 transition duration-300 hover:-translate-y-0.5 hover:shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_22px_44px_-30px_rgba(10,80,160,0.6)]"
                >
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute -right-16 -top-16 size-44 rounded-full opacity-70 transition group-hover:opacity-100"
                    style={{
                      background:
                        GAME_ORBS[category.slug] ??
                        "radial-gradient(circle, rgba(90,190,255,0.35), transparent 70%)",
                    }}
                  />
                  <div className="relative flex items-start justify-between">
                    <span className="grid size-11 place-items-center rounded-xl border border-white bg-white/80 text-[#0a63ff] shadow-sm">
                      <GameIcon slug={category.slug} className="size-5" />
                    </span>
                    <ArrowRight className="size-4 text-[#7fa5c2] transition group-hover:-rotate-45 group-hover:text-[#0a63ff]" />
                  </div>
                  <h2 className="display-soft relative mt-4 text-[1.14rem] text-ink">
                    {category.name}
                  </h2>
                  <p className="relative mt-1 line-clamp-2 min-h-[2.5rem] text-[0.78rem] leading-relaxed text-ink-soft/80">
                    {category.tagline || meta?.blurb || category.description}
                  </p>
                  <div className="relative mt-4 flex items-center justify-between border-t border-white/80 pt-3 text-[0.72rem]">
                    <span className="text-mutedblue">
                      {plans.length} {plans.length === 1 ? "plan" : "plans"}
                    </span>
                    <span className="font-semibold text-ink">
                      from{" "}
                      <span className="mono tabular">
                        {Number.isFinite(from)
                          ? money(from)
                          : meta?.startingAt ?? "—"}
                      </span>
                      /mo
                    </span>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      <section className="section pt-6">
        <div className="container-x">
          <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
            <div>
              <span className="chip">Most deployed</span>
              <h2 className="display mt-3 max-w-[20ch] text-[1.8rem] text-ink sm:text-[2.2rem]">
                Plans people pick when they stop comparing.
              </h2>
            </div>
            <Link
              href="/#pricing"
              className="btn btn-secondary btn-sm"
            >
              Build custom specs
              <ArrowRight className="size-3.5" />
            </Link>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {featured.map((plan) => (
              <PlanCard key={plan.id} plan={plan} />
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
