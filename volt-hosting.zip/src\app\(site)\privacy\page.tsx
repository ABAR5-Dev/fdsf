import type { Metadata } from "next";
import { LegalPage } from "@/components/legal-page";
import { getSite } from "@/lib/queries";

export const metadata: Metadata = {
  title: "Privacy",
  description:
    "What Volt Hosting collects, why we collect it, where it goes, and how to get it removed. Written for humans, not auditors.",
};

export default function PrivacyPage() {
  const site = getSite();
  const name = site.siteName;

  return (
    <LegalPage
      title="Privacy"
      updated="27 November 2026"
      intro={`We collect what is needed to sell you a server and keep it running. This page names every category, why it exists, and who else touches it.`}
      sections={[
        {
          id: "collect",
          title: "What we collect",
          bullets: [
            "Account: your name, email address, a salted password hash, and the role on your account. We never store passwords in plain text.",
            "Billing: orders, amounts, term length, billing address where a payment processor requires it, and the processor's reference. Card numbers never reach our server.",
            "Servers: the name, region, resources and status of each server, plus the panel username issued for it.",
            "Support: ticket text, priorities, replies and the email address on your account.",
            "Operations: session records, IP address and user agent for security, and delivery results for every email we attempt.",
          ],
        },
        {
          id: "why",
          title: "Why we use it",
          paragraphs: [
            "To create your account, take payment, provision the server you bought, email credentials and receipts, answer support tickets, prevent abuse, and keep the platform secure. We also use aggregated, non-identifying figures to understand capacity and pricing.",
            "We do not sell personal data, run advertising profiles, or use third-party analytics that follow you across sites.",
          ],
        },
        {
          id: "panel-credentials",
          title: "Panel credentials",
          paragraphs: [
            "When we create your Pterodactyl account we generate a random password, email it to you once, and store it encrypted with AES-256-GCM. Staff cannot read the plaintext from the admin panel. The decrypted value is used only to include it in your credentials email and to provision the server.",
            "You can change the panel password from the panel at any time. Losing it does not lose your server; open a ticket and we will reset it.",
          ],
        },
        {
          id: "payments",
          title: "Payments",
          paragraphs: [
            "Card payments are processed by Stripe. Your card details go directly to Stripe and are subject to their privacy policy; we receive a tokenised reference, the amount and the outcome, never the card number or CVC. Stripe API secrets are stored encrypted on our side.",
            "For manual payment methods, billing staff see the reference you provide. Do not send card numbers in a ticket.",
          ],
        },
        {
          id: "email",
          title: "Email",
          paragraphs: [
            "Transactional email is sent through the SMTP mailbox configured by the operator. The provider processes the recipient address, subject and body on our behalf. Our email log records the recipient, subject, status and any delivery error so support can diagnose missing mail.",
          ],
        },
        {
          id: "discord",
          title: "Discord notifications",
          paragraphs: [
            "When enabled, new signups, purchases and support tickets are posted to the operator's Discord channels through webhooks. A signup post includes the account name and email address; a purchase post includes the customer name, email, item and location; a ticket post includes the customer, priority and message. These channels are private to the operator's staff and community moderators.",
            "If you would rather your account not appear in those posts, contact us and we will exclude it.",
          ],
        },
        {
          id: "cookies",
          title: "Cookies and sessions",
          paragraphs: [
            "We set one first-party cookie, volt_session, which is HttpOnly, SameSite=Lax and expires after thirty days of inactivity. It is an opaque session identifier stored in our database; signing out deletes it. We do not set advertising or cross-site tracking cookies.",
          ],
        },
        {
          id: "sharing",
          title: "Who else sees it",
          paragraphs: [
            "Only the processors needed to run the service: Stripe for card payments, the Pterodactyl panel that hosts customer servers, the SMTP provider for email, Discord for the notifications above, and our infrastructure or DDoS-protection provider where applicable. Each receives only what its task requires.",
            "We disclose data to authorities only where legally compelled, and we will tell you unless a lawful order prevents it.",
          ],
        },
        {
          id: "retention",
          title: "How long we keep it",
          bullets: [
            "Account data: while your account exists, then deleted on request, except records we must keep for tax and accounting.",
            "Server data: seven days after cancellation, then deleted. Export anything you need before that window closes.",
            "Email log: ninety days, so support can trace recent delivery.",
            "Security sessions: until expiry, sign-out, or thirty days of inactivity.",
          ],
        },
        {
          id: "security",
          title: "How it is protected",
          paragraphs: [
            "Passwords use scrypt with a per-user salt. Session tokens are random 256-bit values stored hashed. Panel credentials and payment secrets use AES-256-GCM with a key derived from the deployment's secret. Traffic is encrypted with TLS, and access to the admin panel is limited to accounts with the admin role.",
            "No system is perfect. If a breach affects your data, we will contact you with what happened and what to do.",
          ],
        },
        {
          id: "rights",
          title: "Your choices",
          paragraphs: [
            `You can access and correct most data from your dashboard, export your server files over SFTP, and request deletion of your account. To exercise a right you cannot reach yourself, email ${site.supportEmail}. We respond within thirty days, and we will not charge you for a reasonable request.`,
            "You can also complain to your local data-protection authority. We would appreciate the chance to fix it first.",
          ],
        },
        {
          id: "children",
          title: "Age",
          paragraphs: [
            "The service is not directed at children under 16. If you are younger than the age of digital consent where you live, you need a parent or guardian to hold the account.",
          ],
        },
        {
          id: "changes",
          title: "Changes",
          paragraphs: [
            `If we change how we handle personal data, we will update this page and, for material changes, tell you by email or in the dashboard before the change takes effect. Questions: ${site.supportEmail}.`,
          ],
        },
      ]}
      footer={
        <>
          <p className="font-semibold text-[#083f72]">Short version</p>
          <p className="mt-1.5">
            We hold your name, email, orders, servers and tickets to run {name}.
            We do not sell any of it. Card data stays with Stripe, panel
            passwords are encrypted, and you can ask us to delete your account
            whenever you like.
          </p>
        </>
      }
    />
  );
}
