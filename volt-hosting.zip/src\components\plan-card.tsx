import Link from "next/link";
import { ArrowRight, Check, Cpu, Database, HardDrive, MemoryStick } from "lucide-react";
import { billingLabel, cpuLabel, diskLabel, money, ramLabel } from "@/lib/format";
import type { ProductWithCategory } from "@/lib/types";

function readFeatures(value: string): string[] {
  try {
    const parsed = JSON.parse(value);
    if (Array.isArray(parsed)) return parsed.map(String).filter(Boolean);
  } catch {
    // fall through to line splitting
  }
  return value
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
}

export function PlanCard({
  plan,
  className = "",
}: {
  plan: ProductWithCategory;
  className?: string;
}) {
  const features = readFeatures(plan.features);
  const popular = plan.popular === 1;

  return (
    <article
      className={[
        "relative flex flex-col rounded-2xl p-5",
        popular
          ? "glass border-[#bfe2ff] shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_24px_50px_-34px_rgba(10,80,160,0.65)]"
          : "glass-quiet",
        className,
      ].join(" ")}
    >
      {popular && (
        <span className="absolute -top-2.5 left-5 rounded-full bg-gradient-to-b from-[#1a8cff] to-[#0a63ff] px-2.5 py-0.5 text-[0.62rem] font-bold text-white shadow-sm">
          Most deployed
        </span>
      )}

      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="display-soft text-[1.15rem] text-ink">{plan.name}</h3>
          <p className="mt-0.5 text-[0.72rem] text-mutedblue">
            {plan.category_name}
          </p>
        </div>
        <span className="rounded-lg border border-white bg-white/70 px-2 py-1 text-[0.62rem] font-semibold text-[#0a5fbe]">
          {plan.players > 0 ? `${plan.players}+ slots` : "Unlimited"}
        </span>
      </div>

      <div className="mt-4 flex items-baseline gap-1.5">
        <span className="mono tabular text-[1.85rem] font-semibold leading-none tracking-[-0.04em] text-ink">
          {money(plan.price_cents)}
        </span>
        <span className="text-[0.74rem] text-mutedblue">/ month</span>
      </div>
      <p className="mt-1 text-[0.68rem] text-mutedblue">
        {billingLabel(1)} billing · cancel anytime
      </p>

      <p className="mt-3 min-h-[2.6rem] text-[0.8rem] leading-relaxed text-ink-soft/85">
        {plan.description}
      </p>

      <dl className="mt-4 grid grid-cols-2 gap-2">
        {[
          { icon: MemoryStick, label: "Memory", value: ramLabel(plan.ram_mb) },
          { icon: Cpu, label: "CPU", value: cpuLabel(plan.cpu_pct) },
          { icon: HardDrive, label: "NVMe", value: diskLabel(plan.disk_mb) },
          {
            icon: Database,
            label: "Backups",
            value:
              plan.backups > 0
                ? `${plan.backups} slot${plan.backups === 1 ? "" : "s"}`
                : "None",
          },
        ].map((spec) => {
          const Icon = spec.icon;
          return (
            <div
              key={spec.label}
              className="rounded-xl border border-white/90 bg-white/55 px-2.5 py-2"
            >
              <dt className="flex items-center gap-1 text-[0.6rem] font-medium text-mutedblue">
                <Icon className="size-3" />
                {spec.label}
              </dt>
              <dd className="mono mt-0.5 text-[0.76rem] font-semibold text-ink">
                {spec.value}
              </dd>
            </div>
          );
        })}
      </dl>

      {features.length > 0 && (
        <ul className="mt-4 space-y-1.5">
          {features.slice(0, 4).map((feature) => (
            <li
              key={feature}
              className="flex items-start gap-1.5 text-[0.76rem] leading-snug text-ink-soft/85"
            >
              <Check className="mt-0.5 size-3 shrink-0 text-[#0a8f5b]" />
              {feature}
            </li>
          ))}
        </ul>
      )}

      <Link
        href={`/checkout?product=${plan.slug}`}
        className={[
          "btn btn-sm mt-5 w-full",
          popular ? "btn-primary" : "btn-secondary",
        ].join(" ")}
      >
        Deploy {plan.name}
        <ArrowRight className="size-3.5" />
      </Link>
    </article>
  );
}
