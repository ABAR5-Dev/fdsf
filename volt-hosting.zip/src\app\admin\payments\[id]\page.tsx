import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { GatewayForm } from "@/components/app/payment-forms";
import { StatusPill } from "@/components/status-pill";
import { getGatewayById } from "@/lib/queries";

type PageProps = { params: Promise<{ id: string }> };

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const gateway = getGatewayById(id);
  return { title: gateway?.name ?? "Payment method" };
}

export default async function EditPaymentPage({ params }: PageProps) {
  await requireAdmin("/admin/payments");
  const { id } = await params;
  const gateway = getGatewayById(id);
  if (!gateway) notFound();

  let config: Record<string, unknown> = {};
  try {
    config = JSON.parse(gateway.config) as Record<string, unknown>;
  } catch {
    config = {};
  }

  const initial = {
    instructions:
      typeof config.instructions === "string" ? config.instructions : "",
    discordUrl:
      typeof config.discordUrl === "string" ? config.discordUrl : "",
    publishableKey:
      typeof config.publishableKey === "string" ? config.publishableKey : "",
    hasSecret: Boolean(config.secretKeyEnc || config.secretKey),
  };

  return (
    <div className="mx-auto max-w-[860px]">
      <Link
        href="/admin/payments"
        className="inline-flex items-center gap-1.5 text-[0.74rem] font-medium text-mutedblue transition hover:text-ink"
      >
        <ArrowLeft className="size-3.5" />
        Payments
      </Link>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <h1 className="display text-[1.8rem] text-ink sm:text-[2.1rem]">
          {gateway.name}
        </h1>
        <StatusPill
          label={gateway.enabled === 1 ? "Offered" : "Off"}
          tone={gateway.enabled === 1 ? "mint" : "slate"}
          dot
        />
      </div>
      <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
        Change the type only when you are ready to reconfigure its fields.
      </p>

      <div className="mt-5">
        <GatewayForm gateway={gateway} initial={initial} />
      </div>
    </div>
  );
}
