import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowRight, Server } from "lucide-react";
import { ServerCard } from "@/components/app/server-card";
import { getCurrentUser } from "@/lib/auth";
import { syncUserServers } from "@/lib/provision";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "My servers" };

export default async function ServersPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/servers");

  const servers = await syncUserServers(user.id);
  const running = servers.filter((server) => server.status === "running").length;

  return (
    <div className="mx-auto max-w-[1120px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">
            My servers
          </h1>
          <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
            {servers.length === 0
              ? "Nothing deployed yet."
              : `${servers.length} ${
                  servers.length === 1 ? "service" : "services"
                }, ${running} running. Status refreshes when this page loads.`}
          </p>
        </div>
        <Link href="/store" className="btn btn-primary btn-sm">
          <Server className="size-4" />
          Deploy a server
        </Link>
      </div>

      {servers.length === 0 ? (
        <div className="glass mt-6 rounded-2xl p-10 text-center">
          <span className="mx-auto grid size-12 place-items-center rounded-2xl bg-white/80 text-[#0a63ff] shadow-sm">
            <Server className="size-6" />
          </span>
          <h2 className="display-soft mt-4 text-[1.25rem] text-ink">
            Your rack is empty.
          </h2>
          <p className="mx-auto mt-1.5 max-w-[44ch] text-[0.82rem] leading-relaxed text-ink-soft/80">
            Minecraft, FiveM, Rust, SA-MP or a Discord bot — pick one and the
            panel account is created for you.
          </p>
          <Link href="/store" className="btn btn-primary btn-sm mt-5">
            Browse the store
            <ArrowRight className="size-3.5" />
          </Link>
        </div>
      ) : (
        <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {servers.map((server) => (
            <ServerCard key={server.id} server={server} />
          ))}
        </div>
      )}

      <div className="glass mt-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl px-4 py-3">
        <p className="text-[0.78rem] text-ink-soft/85">
          Need a different size? Custom builds can be ordered in under a minute.
        </p>
        <Link
          href="/#pricing"
          className="inline-flex items-center gap-1 text-[0.76rem] font-semibold text-[#0a63ff] hover:underline"
        >
          Build custom specs
          <ArrowRight className="size-3.5" />
        </Link>
      </div>
    </div>
  );
}
