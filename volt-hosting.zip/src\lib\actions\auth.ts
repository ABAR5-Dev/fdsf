"use server";

import { randomUUID } from "node:crypto";
import { mkdir, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { db } from "../db";
import {
  createSession,
  destroySession,
  getCurrentUser,
} from "../auth";
import { hashPassword, verifyPassword } from "../crypto";
import { getUserByEmail, getUserById } from "../queries";
import { notifySignup } from "../discord";
import { sendWelcomeEmail } from "../mail";
import type { ActionState } from "../types";

function safeNext(value: FormDataEntryValue | null): string | null {
  if (typeof value !== "string") return null;
  if (!value.startsWith("/") || value.startsWith("//")) return null;
  return value;
}

const AVATAR_TYPES: Record<string, string> = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp",
  "image/gif": "gif",
};
const MAX_AVATAR_BYTES = 2 * 1024 * 1024;

async function deleteAvatarFile(url: string) {
  if (!url.startsWith("/uploads/avatars/")) return;
  const file = path.join(
    process.cwd(),
    "public",
    url.replace(/^\//, ""),
  );
  await unlink(file).catch(() => undefined);
}

export async function registerAction(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const name = String(formData.get("name") ?? "").trim();
  const email = String(formData.get("email") ?? "")
    .trim()
    .toLowerCase();
  const password = String(formData.get("password") ?? "");
  const confirm = String(formData.get("confirm") ?? "");
  const next = safeNext(formData.get("next"));

  if (name.length < 2) return { error: "Enter your name." };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { error: "Enter a valid email address." };
  }
  if (password.length < 8) {
    return { error: "Use at least 8 characters for your password." };
  }
  if (!/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
    return { error: "Include at least one letter and one number." };
  }
  if (password !== confirm) {
    return { error: "The passwords do not match." };
  }
  if (getUserByEmail(email)) {
    return { error: "An account with that email already exists. Sign in instead." };
  }

  const id = randomUUID();
  db.prepare(
    `INSERT INTO users (id, email, name, password_hash, role, created_at)
     VALUES (?, ?, ?, ?, 'customer', ?)`,
  ).run(id, email, name, hashPassword(password), new Date().toISOString());

  const user = getUserById(id);
  await createSession(id);
  if (user) {
    void notifySignup({ name: user.name, email: user.email });
    void sendWelcomeEmail(user);
  }

  redirect(next || "/dashboard");
}

export async function loginAction(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const email = String(formData.get("email") ?? "")
    .trim()
    .toLowerCase();
  const password = String(formData.get("password") ?? "");
  const next = safeNext(formData.get("next"));

  if (!email || !password) {
    return { error: "Enter your email and password." };
  }

  const user = getUserByEmail(email);
  if (!user || !verifyPassword(password, user.password_hash)) {
    return { error: "That email and password combination did not work." };
  }

  await createSession(user.id);
  redirect(next || (user.role === "admin" ? "/admin" : "/dashboard"));
}

export async function logoutAction() {
  await destroySession();
  redirect("/");
}

export async function updateProfileAction(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await getCurrentUser();
  if (!user) return { error: "Your session expired. Sign in again." };

  const name = String(formData.get("name") ?? "").trim();
  const email = String(formData.get("email") ?? "")
    .trim()
    .toLowerCase();

  if (name.length < 2) return { error: "Enter your name." };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { error: "Enter a valid email address." };
  }

  const existing = getUserByEmail(email);
  if (existing && existing.id !== user.id) {
    return { error: "That email is already in use by another account." };
  }

  const bio = String(formData.get("bio") ?? "")
    .trim()
    .slice(0, 240);

  const discordInput = String(formData.get("discord_handle") ?? "")
    .trim()
    .replace(/^@/, "");
  if (discordInput && !/^[a-zA-Z0-9._]{2,32}$/.test(discordInput)) {
    return {
      error: "A Discord username can use letters, numbers, dots and underscores (2–32 characters).",
    };
  }

  let avatarUrl = user.avatarUrl;
  const removeAvatar = formData.get("remove_avatar") === "on";
  const avatar = formData.get("avatar");

  if (avatar instanceof File && avatar.size > 0) {
    if (avatar.size > MAX_AVATAR_BYTES) {
      return { error: "Choose an image smaller than 2 MB." };
    }
    const extension = AVATAR_TYPES[avatar.type];
    if (!extension) {
      return { error: "Use a PNG, JPG, WebP or GIF image for your avatar." };
    }

    try {
      const directory = path.join(process.cwd(), "public", "uploads", "avatars");
      await mkdir(directory, { recursive: true });
      const filename = `${randomUUID()}.${extension}`;
      await writeFile(
        path.join(directory, filename),
        new Uint8Array(await avatar.arrayBuffer()),
      );
      await deleteAvatarFile(user.avatarUrl);
      avatarUrl = `/uploads/avatars/${filename}`;
    } catch (error) {
      console.error("[avatar] upload failed:", error);
      return {
        error:
          "The image could not be saved. Make sure the public/uploads folder is writable.",
      };
    }
  } else if (removeAvatar) {
    await deleteAvatarFile(user.avatarUrl);
    avatarUrl = "";
  }

  db.prepare(
    `UPDATE users SET name = ?, email = ?, avatar_url = ?, bio = ?,
     discord_handle = ? WHERE id = ?`,
  ).run(name, email, avatarUrl, bio, discordInput, user.id);

  revalidatePath("/", "layout");
  revalidatePath("/dashboard/account");
  revalidatePath("/dashboard");
  revalidatePath("/admin/users");
  return { success: "Your profile has been updated." };
}

export async function changePasswordAction(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const session = await getCurrentUser();
  if (!session) return { error: "Your session expired. Sign in again." };

  const current = String(formData.get("current") ?? "");
  const password = String(formData.get("password") ?? "");
  const confirm = String(formData.get("confirm") ?? "");
  const user = getUserById(session.id);
  if (!user) return { error: "Account not found." };

  if (!verifyPassword(current, user.password_hash)) {
    return { error: "Your current password is not correct." };
  }
  if (password.length < 8 || !/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
    return { error: "Use 8+ characters with at least one letter and one number." };
  }
  if (password !== confirm) {
    return { error: "The new passwords do not match." };
  }

  db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(
    hashPassword(password),
    user.id,
  );
  return { success: "Password changed." };
}
