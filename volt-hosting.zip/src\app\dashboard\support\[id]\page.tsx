import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import {
  ArrowLeft,
  CheckCircle2,
  Lock,
  MessageSquarePlus,
  ShieldCheck,
} from "lucide-react";
import { ReplyBox } from "@/components/app/ticket-forms";
import { StatusPill } from "@/components/status-pill";
import { getCurrentUser } from "@/lib/auth";
import {
  PRIORITY_META,
  TICKET_STATUS_META,
  dateTimeLabel,
  initials,
  relativeTime,
} from "@/lib/format";
import { getTicketById, getTicketMessages } from "@/lib/queries";
import { closeTicketAction } from "@/lib/actions/support";

type PageProps = { params: Promise<{ id: string }> };

const CATEGORY_LABEL: Record<string, string> = {
  server: "Game server",
  panel: "Panel access",
  billing: "Billing",
  general: "General",
};

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const user = await getCurrentUser();
  if (!user) return { title: "Ticket" };
  const ticket = getTicketById(id);
  return { title: ticket?.user_id === user.id ? ticket.subject : "Ticket" };
}

export default async function TicketPage({ params }: PageProps) {
  const { id } = await params;
  const user = await getCurrentUser();
  if (!user) redirect(`/login?next=/dashboard/support/${id}`);

  const ticket = getTicketById(id);
  if (!ticket || ticket.user_id !== user.id) notFound();

  const messages = getTicketMessages(ticket.id);
  const status = TICKET_STATUS_META[ticket.status] ?? TICKET_STATUS_META.open;
  const priority = PRIORITY_META[ticket.priority] ?? PRIORITY_META.normal;

  return (
    <div className="mx-auto max-w-[960px]">
      <Link
        href="/dashboard/support"
        className="inline-flex items-center gap-1.5 text-[0.74rem] font-medium text-mutedblue transition hover:text-ink"
      >
        <ArrowLeft className="size-3.5" />
        Support
      </Link>

      <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="display text-[1.6rem] leading-tight text-ink sm:text-[1.95rem]">
              {ticket.subject}
            </h1>
            <StatusPill label={status.label} tone={status.tone} dot />
          </div>
          <p className="mt-1.5 text-[0.74rem] text-mutedblue">
            {CATEGORY_LABEL[ticket.category] ?? ticket.category} ·{" "}
            {priority.label} priority · opened {relativeTime(ticket.created_at)}
          </p>
        </div>
        {ticket.status !== "closed" && (
          <form action={closeTicketAction}>
            <input type="hidden" name="ticket_id" value={ticket.id} />
            <button type="submit" className="btn btn-secondary btn-sm">
              <CheckCircle2 className="size-3.5" />
              Close ticket
            </button>
          </form>
        )}
      </div>

      <section className="glass mt-5 rounded-2xl p-4 sm:p-5">
        <ol className="space-y-5">
          {messages.map((message) => {
            const staff = message.is_staff === 1;
            return (
              <li key={message.id} className="flex gap-3">
                <span
                  className={`grid size-8 shrink-0 place-items-center rounded-full text-[0.66rem] font-semibold ${
                    staff
                      ? "bg-[#0a63ff] text-white"
                      : "border border-white/90 bg-white/80 text-ink-soft"
                  }`}
                  aria-hidden
                >
                  {initials(message.author_name)}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[0.8rem] font-semibold text-ink">
                      {message.author_name}
                    </span>
                    {staff && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-[#e8f1ff] px-1.5 py-0.5 text-[0.6rem] font-semibold text-[#0a63ff]">
                        <ShieldCheck className="size-2.5" />
                        Volt team
                      </span>
                    )}
                    <span className="text-[0.66rem] text-mutedblue">
                      {relativeTime(message.created_at)}
                    </span>
                  </div>
                  <div
                    className={`mt-1 rounded-xl px-3 py-2.5 text-[0.8rem] leading-relaxed whitespace-pre-wrap ${
                      staff
                        ? "border border-[#d6e6ff] bg-[#f2f7ff] text-ink"
                        : "border border-white/90 bg-white/60 text-ink-soft"
                    }`}
                  >
                    {message.body}
                  </div>
                </div>
              </li>
            );
          })}
        </ol>

        <div className="mt-5 border-t border-white/90 pt-1">
          {ticket.status === "closed" ? (
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/90 bg-white/55 px-3.5 py-3">
              <div className="flex items-start gap-2 text-[0.76rem] leading-relaxed text-ink-soft/85">
                <Lock className="mt-0.5 size-3.5 shrink-0 text-[#7fa5c2]" />
                <span>
                  Closed {relativeTime(ticket.updated_at)}. If it happens again,
                  open a new ticket and reference this one.
                </span>
              </div>
              <Link
                href="/dashboard/support/new"
                className="btn btn-secondary btn-sm"
              >
                <MessageSquarePlus className="size-3.5" />
                New ticket
              </Link>
            </div>
          ) : (
            <ReplyBox ticketId={ticket.id} />
          )}
        </div>
      </section>

      <p className="mt-3 px-1 text-[0.7rem] text-mutedblue">
        Opened {dateTimeLabel(ticket.created_at)} · last activity{" "}
        {relativeTime(ticket.updated_at)}
      </p>
    </div>
  );
}
