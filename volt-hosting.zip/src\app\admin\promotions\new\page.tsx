import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { PromoForm } from "@/components/app/promo-form";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "New promo code" };

export default async function NewPromoPage() {
  await requireAdmin("/admin/promotions/new");
  return (
    <div className="mx-auto max-w-[860px]">
      <Link
        href="/admin/promotions"
        className="inline-flex items-center gap-1.5 text-[0.74rem] font-medium text-mutedblue transition hover:text-ink"
      >
        <ArrowLeft className="size-3.5" />
        Promo codes
      </Link>
      <h1 className="display mt-3 text-[1.9rem] text-ink sm:text-[2.2rem]">
        New promo code
      </h1>
      <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
        Customers enter this in the checkout summary. It applies to the plan
        price for the term they picked.
      </p>
      <div className="glass mt-5 rounded-2xl p-4 sm:p-5">
        <PromoForm />
      </div>
    </div>
  );
}
