import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { getOrderById, getServersForUser } from "@/lib/queries";
import { syncServerStatus } from "@/lib/provision";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const order = getOrderById(id);
  if (!order || (order.user_id !== user.id && user.role !== "admin")) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const server = getServersForUser(order.user_id).find(
    (item) => item.order_id === order.id,
  );
  if (server && (server.status === "installing" || server.status === "provisioning")) {
    await syncServerStatus(server.id);
  }
  const refreshed = server
    ? getServersForUser(order.user_id).find((item) => item.id === server.id)
    : undefined;

  return NextResponse.json({
    orderStatus: order.status,
    serverStatus: refreshed?.status ?? null,
    serverId: refreshed?.id ?? null,
  });
}
