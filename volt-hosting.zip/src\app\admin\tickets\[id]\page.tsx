import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  Clock3,
  Mail,
  MessageSquare,
  ShieldCheck,
  UserRound,
} from "lucide-react";
import { AdminReplyBox } from "@/components/app/admin-ticket-forms";
import { StatusPill } from "@/components/status-pill";
import {
  PRIORITY_META,
  TICKET_STATUS_META,
  dateTimeLabel,
  initials,
  relativeTime,
} from "@/lib/format";
import { getTicketById, getTicketMessages } from "@/lib/queries";
import {
  setTicketPriorityAction,
  setTicketStatusAction,
} from "@/lib/actions/admin";

type PageProps = { params: Promise<{ id: string }> };

const CATEGORY_LABEL: Record<string, string> = {
  server: "Game server",
  panel: "Panel access",
  billing: "Billing",
  general: "General",
};

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const ticket = getTicketById(id);
  return { title: ticket?.subject ?? "Ticket" };
}

export default async function AdminTicketPage({ params }: PageProps) {
  await requireAdmin("/admin/tickets");
  const { id } = await params;
  const ticket = getTicketById(id);
  if (!ticket) notFound();

  const messages = getTicketMessages(ticket.id);
  const status = TICKET_STATUS_META[ticket.status] ?? TICKET_STATUS_META.open;
  const priority = PRIORITY_META[ticket.priority] ?? PRIORITY_META.normal;

  return (
    <div className="mx-auto max-w-[1120px]">
      <Link
        href="/admin/tickets"
        className="inline-flex items-center gap-1.5 text-[0.74rem] font-medium text-mutedblue transition hover:text-ink"
      >
        <ArrowLeft className="size-3.5" />
        Tickets
      </Link>

      <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="display text-[1.6rem] leading-tight text-ink sm:text-[1.95rem]">
              {ticket.subject}
            </h1>
            <StatusPill label={status.label} tone={status.tone} dot />
          </div>
          <p className="mt-1.5 text-[0.74rem] text-mutedblue">
            {CATEGORY_LABEL[ticket.category] ?? ticket.category} ·{" "}
            {priority.label} priority · {ticket.message_count} messages
          </p>
        </div>
        <a
          href={`mailto:${ticket.user_email}?subject=${encodeURIComponent(
            `Re: ${ticket.subject}`,
          )}`}
          className="btn btn-secondary btn-sm"
        >
          <Mail className="size-3.5" />
          Email customer
        </a>
      </div>

      <div className="mt-4 grid items-start gap-4 lg:grid-cols-[1.2fr_0.8fr]">
        <section className="glass rounded-2xl p-4 sm:p-5">
          <ol className="space-y-5">
            {messages.map((message) => {
              const staff = message.is_staff === 1;
              return (
                <li key={message.id} className="flex gap-3">
                  <span
                    className={`grid size-8 shrink-0 place-items-center rounded-full text-[0.66rem] font-semibold ${
                      staff
                        ? "bg-[#0a63ff] text-white"
                        : "border border-white/90 bg-white/80 text-ink-soft"
                    }`}
                    aria-hidden
                  >
                    {initials(message.author_name)}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[0.8rem] font-semibold text-ink">
                        {message.author_name}
                      </span>
                      {staff && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-[#e8f1ff] px-1.5 py-0.5 text-[0.6rem] font-semibold text-[#0a63ff]">
                          <ShieldCheck className="size-2.5" />
                          Staff
                        </span>
                      )}
                      <span className="text-[0.66rem] text-mutedblue">
                        {relativeTime(message.created_at)}
                      </span>
                    </div>
                    <div
                      className={`mt-1 rounded-xl px-3 py-2.5 text-[0.8rem] leading-relaxed whitespace-pre-wrap ${
                        staff
                          ? "border border-[#d6e6ff] bg-[#f2f7ff] text-ink"
                          : "border border-white/90 bg-white/60 text-ink-soft"
                      }`}
                    >
                      {message.body}
                    </div>
                  </div>
                </li>
              );
            })}
          </ol>

          <div className="mt-5 border-t border-white/90 pt-1">
            {ticket.status === "closed" ? (
              <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/90 bg-white/55 px-3.5 py-3 text-[0.76rem] text-ink-soft/85">
                <span>This ticket is closed. Reopen it to reply.</span>
                <form action={setTicketStatusAction}>
                  <input type="hidden" name="ticket_id" value={ticket.id} />
                  <input type="hidden" name="status" value="open" />
                  <button type="submit" className="btn btn-secondary btn-sm">
                    Reopen
                  </button>
                </form>
              </div>
            ) : (
              <AdminReplyBox ticketId={ticket.id} />
            )}
          </div>
        </section>

        <aside className="space-y-4">
          <section className="glass rounded-2xl p-4">
            <h2 className="flex items-center gap-1.5 text-[0.88rem] font-semibold text-ink">
              <UserRound className="size-4 text-[#0a63ff]" />
              Customer
            </h2>
            <div className="mt-2.5 flex items-center gap-2.5">
              <span className="grid size-9 place-items-center rounded-full bg-white/80 text-[0.66rem] font-bold text-[#0a4bb0] ring-1 ring-white">
                {initials(ticket.user_name)}
              </span>
              <div className="min-w-0">
                <p className="truncate text-[0.82rem] font-semibold text-ink">
                  {ticket.user_name}
                </p>
                <p className="truncate text-[0.72rem] text-mutedblue">
                  {ticket.user_email}
                </p>
              </div>
            </div>
          </section>

          <section className="glass rounded-2xl p-4">
            <h2 className="text-[0.88rem] font-semibold text-ink">Case file</h2>
            <dl className="mt-2.5 space-y-1.5 text-[0.74rem]">
              <div className="flex items-center justify-between gap-3">
                <dt className="flex items-center gap-1.5 text-mutedblue">
                  <MessageSquare className="size-3.5" />
                  Ticket
                </dt>
                <dd className="mono truncate text-ink" title={ticket.id}>
                  {ticket.id.slice(0, 8)}
                </dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="flex items-center gap-1.5 text-mutedblue">
                  <Clock3 className="size-3.5" />
                  Opened
                </dt>
                <dd className="text-ink">{dateTimeLabel(ticket.created_at)}</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="flex items-center gap-1.5 text-mutedblue">
                  <Clock3 className="size-3.5" />
                  Updated
                </dt>
                <dd className="text-ink">{relativeTime(ticket.updated_at)}</dd>
              </div>
            </dl>
          </section>

          <section className="glass rounded-2xl p-4">
            <h2 className="text-[0.88rem] font-semibold text-ink">Triage</h2>
            <form action={setTicketStatusAction} className="mt-2.5">
              <input type="hidden" name="ticket_id" value={ticket.id} />
              <label htmlFor="status" className="field-label">
                Status
              </label>
              <div className="flex gap-2">
                <select
                  id="status"
                  name="status"
                  defaultValue={ticket.status}
                  className="select h-8 text-[0.76rem]"
                >
                  <option value="open">Open</option>
                  <option value="answered">Answered</option>
                  <option value="closed">Closed</option>
                </select>
                <button type="submit" className="btn btn-secondary btn-sm shrink-0">
                  Set
                </button>
              </div>
            </form>

            <form action={setTicketPriorityAction} className="mt-3">
              <input type="hidden" name="ticket_id" value={ticket.id} />
              <label htmlFor="priority" className="field-label">
                Priority
              </label>
              <div className="flex gap-2">
                <select
                  id="priority"
                  name="priority"
                  defaultValue={ticket.priority}
                  className="select h-8 text-[0.76rem]"
                >
                  <option value="low">Low</option>
                  <option value="normal">Normal</option>
                  <option value="high">High</option>
                  <option value="urgent">Urgent</option>
                </select>
                <button type="submit" className="btn btn-secondary btn-sm shrink-0">
                  Set
                </button>
              </div>
            </form>
          </section>
        </aside>
      </div>
    </div>
  );
}
