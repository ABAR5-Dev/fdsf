import {
  Bot,
  Boxes,
  CarFront,
  Flame,
  Gamepad2,
  Pickaxe,
  Server,
} from "lucide-react";

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  minecraft: Pickaxe,
  fivem: CarFront,
  rust: Flame,
  samp: Gamepad2,
  "discord-bots": Bot,
  vps: Server,
};

export const GAME_ORBS: Record<string, string> = {
  minecraft:
    "radial-gradient(60% 60% at 70% 30%, rgba(46,190,255,0.45), transparent 70%), radial-gradient(40% 40% at 20% 80%, rgba(125,240,221,0.32), transparent 70%)",
  fivem:
    "radial-gradient(60% 60% at 72% 26%, rgba(30,140,255,0.5), transparent 70%), radial-gradient(42% 42% at 18% 82%, rgba(18,200,255,0.34), transparent 70%)",
  rust: "radial-gradient(60% 60% at 72% 28%, rgba(229,107,47,0.42), transparent 70%), radial-gradient(44% 44% at 20% 80%, rgba(255,196,107,0.3), transparent 70%)",
  samp: "radial-gradient(60% 60% at 72% 28%, rgba(13,147,136,0.4), transparent 70%), radial-gradient(44% 44% at 20% 80%, rgba(109,242,214,0.3), transparent 70%)",
  "discord-bots":
    "radial-gradient(60% 60% at 72% 28%, rgba(59,108,255,0.45), transparent 70%), radial-gradient(44% 44% at 20% 80%, rgba(154,167,255,0.32), transparent 70%)",
  vps: "radial-gradient(60% 60% at 72% 28%, rgba(20,118,201,0.4), transparent 70%), radial-gradient(44% 44% at 20% 80%, rgba(102,217,255,0.3), transparent 70%)",
};

export function GameIcon({
  slug,
  className = "size-5",
}: {
  slug: string;
  className?: string;
}) {
  const Icon = ICONS[slug] ?? Boxes;
  return <Icon className={className} />;
}
