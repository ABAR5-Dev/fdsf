import type { Metadata } from "next";
import { Suspense } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import {
  ArrowRight,
  CheckCircle2,
  Clock3,
  Mail,
  MessageSquare,
  Server,
  TicketPercent,
  XCircle,
} from "lucide-react";
import { OrderProgress } from "@/components/checkout/order-progress";
import { getCurrentUser } from "@/lib/auth";
import {
  billingLabel,
  cpuLabel,
  dateTimeLabel,
  diskLabel,
  money,
  ramLabel,
} from "@/lib/format";
import {
  getGatewayById,
  getOrderById,
  getServersForUser,
  getSite,
} from "@/lib/queries";

export const metadata: Metadata = {
  title: "Order status",
  robots: { index: false },
};

type PageProps = { searchParams: Promise<{ order?: string }> };

export default function SuccessPage({ searchParams }: PageProps) {
  return (
    <Suspense fallback={<SuccessSkeleton />}>
      <SuccessGate searchParams={searchParams} />
    </Suspense>
  );
}

async function SuccessGate({ searchParams }: PageProps) {
  const user = await getCurrentUser();
  const { order: orderId } = await searchParams;
  if (!user) {
    redirect(
      `/login?next=${encodeURIComponent(`/checkout/success?order=${orderId ?? ""}`)}`,
    );
  }
  if (!orderId) redirect("/dashboard");

  const order = getOrderById(orderId);
  if (!order || (order.user_id !== user.id && user.role !== "admin")) {
    redirect("/dashboard");
  }

  const server = getServersForUser(order.user_id).find(
    (item) => item.order_id === order.id,
  );
  const gateway = order.gateway_id ? getGatewayById(order.gateway_id) : undefined;
  const specs = (() => {
    try {
      return JSON.parse(order.specs) as {
        ramMb?: number;
        cpuPct?: number;
        diskMb?: number;
        backups?: number;
      };
    } catch {
      return {};
    }
  })();

  const failed = order.status === "failed";
  const pending = order.status === "pending";
  const running = server?.status === "running";

  let gatewayConfig: Record<string, unknown> = {};
  try {
    gatewayConfig = JSON.parse(gateway?.config ?? "{}") as Record<string, unknown>;
  } catch {
    gatewayConfig = {};
  }
  const needsDiscordTicket = pending && gateway?.type === "discord";
  const discordInstructions =
    typeof gatewayConfig.instructions === "string"
      ? gatewayConfig.instructions
      : "";
  const discordInvite =
    (typeof gatewayConfig.discordUrl === "string" && gatewayConfig.discordUrl) ||
    getSite().discordInvite;
  const orderNumber = order.id.slice(0, 8).toUpperCase();

  return (
    <div className="container-x py-8">
      <div className="grid items-start gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <section className="glass rounded-2xl p-6 sm:p-7">
          <span
            className={[
              "grid size-12 place-items-center rounded-2xl",
              failed
                ? "bg-[#fff1f1] text-[#b03b3b]"
                : running || order.status === "active"
                  ? "bg-[#e9f9f0] text-[#0a8f5b]"
                  : "bg-[#e6f2ff] text-[#0a63ff]",
            ].join(" ")}
          >
            {failed ? (
              <XCircle className="size-6" />
            ) : running || order.status === "active" ? (
              <CheckCircle2 className="size-6" />
            ) : (
              <Clock3 className="size-6" />
            )}
          </span>

          <h1 className="display mt-4 text-[1.9rem] text-ink sm:text-[2.3rem]">
            {failed
              ? "Your server hit a snag."
              : pending
                ? "Order received."
                : running
                  ? "Your server is live."
                  : "You're in. The server is installing."}
          </h1>
          <p className="mt-2 max-w-[52ch] text-[0.86rem] leading-relaxed text-ink-soft/85">
            {failed
              ? "Payment went through, but provisioning stopped. Nothing is lost — support can recover the order and finish the install."
              : pending
                ? needsDiscordTicket
                  ? `We sent your order number to ${user.email}. Open a ticket in Discord and our billing team will reply with the UPI or Google Pay details.`
                  : `We are waiting for ${gateway?.name ?? "your payment method"} to confirm. Instructions were emailed to ${user.email}.`
                : `Panel credentials were emailed to ${user.email}. The install usually finishes within 90 seconds — this page updates itself.`}
          </p>

          <OrderProgress
            orderId={order.id}
            initialOrderStatus={order.status}
            initialServerStatus={server?.status ?? null}
          />

          <div className="mt-6 flex flex-wrap gap-2">
            {server ? (
              <Link
                href={`/dashboard/servers/${server.id}`}
                className="btn btn-primary btn-sm"
              >
                <Server className="size-4" />
                Open server
              </Link>
            ) : (
              <Link href="/dashboard" className="btn btn-primary btn-sm">
                Go to dashboard
                <ArrowRight className="size-4" />
              </Link>
            )}
            <Link href="/dashboard/support/new" className="btn btn-secondary btn-sm">
              <MessageSquare className="size-4" />
              Get help
            </Link>
          </div>

          <p className="mt-4 flex items-start gap-2 rounded-xl border border-white/90 bg-white/50 px-3 py-2.5 text-[0.74rem] leading-relaxed text-ink-soft/85">
            <Mail className="mt-0.5 size-3.5 shrink-0 text-[#0a63ff]" />
            Your panel username and password are emailed to{" "}
            <span className="font-medium text-ink">{user.email}</span> as soon as
            the server is assigned. If the email is not there in five minutes,
            check spam, then open a ticket.
          </p>
        </section>

        <aside className="glass rounded-2xl p-5">
          <div className="flex items-center justify-between">
            <h2 className="text-[0.9rem] font-semibold text-ink">Order details</h2>
            <span className="mono text-[0.64rem] text-mutedblue">
              {order.id.slice(0, 8).toUpperCase()}
            </span>
          </div>

          <div className="mt-3 rounded-xl border border-white/90 bg-white/55 p-3">
            <p className="text-[0.84rem] font-semibold text-ink">{order.item_name}</p>
            <p className="mt-0.5 text-[0.72rem] text-mutedblue">
              {order.server_name} · {order.region}
            </p>
          </div>

          <dl className="mt-4 space-y-1.5 text-[0.78rem]">
            <div className="flex justify-between gap-4">
              <dt className="text-mutedblue">Memory</dt>
              <dd className="mono text-ink">{ramLabel(specs.ramMb ?? 0)}</dd>
            </div>
            <div className="flex justify-between gap-4">
              <dt className="text-mutedblue">CPU</dt>
              <dd className="mono text-ink">{cpuLabel(specs.cpuPct ?? 0)}</dd>
            </div>
            <div className="flex justify-between gap-4">
              <dt className="text-mutedblue">NVMe</dt>
              <dd className="mono text-ink">{diskLabel(specs.diskMb ?? 0)}</dd>
            </div>
            <div className="flex justify-between gap-4">
              <dt className="text-mutedblue">Backups</dt>
              <dd className="mono text-ink">
                {specs.backups ?? 0} slot{(specs.backups ?? 0) === 1 ? "" : "s"}
              </dd>
            </div>
            <div className="flex justify-between gap-4">
              <dt className="text-mutedblue">Billing</dt>
              <dd className="text-ink">{billingLabel(order.billing_months)}</dd>
            </div>
            <div className="flex justify-between gap-4">
              <dt className="text-mutedblue">Placed</dt>
              <dd className="text-ink">{dateTimeLabel(order.created_at)}</dd>
            </div>
          </dl>

          {order.discount_cents > 0 && (
            <div className="mt-3 flex justify-between gap-4 border-t border-[#dcecfa]/80 pt-3 text-[0.78rem] text-[#177a52]">
              <span>Promo {order.promo_code}</span>
              <span className="mono">−{money(order.discount_cents)}</span>
            </div>
          )}

          <div
            className={[
              "flex items-baseline justify-between border-t border-[#dcecfa]/80 pt-3",
              order.discount_cents > 0 ? "mt-1.5" : "mt-4",
            ].join(" ")}
          >
            <span className="text-[0.82rem] font-semibold text-ink">
              {pending ? "Due" : "Total paid"}
            </span>
            <span className="mono tabular text-[1.3rem] font-semibold tracking-[-0.03em] text-ink">
              {money(order.amount_cents)}
            </span>
          </div>

          {server && (
            <div className="mt-4 rounded-xl border border-white/90 bg-white/55 p-3">
              <p className="text-[0.64rem] font-medium text-mutedblue">
                Server address
              </p>
              <p className="mono mt-0.5 text-[0.8rem] font-semibold text-ink">
                {server.ip}
                {server.port ? `:${server.port}` : ""}
              </p>
            </div>
          )}

          <p className="mt-4 text-[0.68rem] leading-relaxed text-mutedblue">
            Manage renewals, invoices and panel access from your dashboard.
          </p>
        </aside>
      </div>

      {pending && discordInstructions && (
        <section className="glass mt-6 rounded-2xl p-5 sm:p-6">
          <div className="flex flex-wrap items-start gap-4">
            <span
              className={[
                "grid size-11 shrink-0 place-items-center rounded-2xl",
                needsDiscordTicket
                  ? "bg-[#5865f2]/12 text-[#5865f2]"
                  : "bg-[#e6f2ff] text-[#0a63ff]",
              ].join(" ")}
            >
              {needsDiscordTicket ? (
                <TicketPercent className="size-5" />
              ) : (
                <Mail className="size-5" />
              )}
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h2 className="text-[1rem] font-semibold text-ink">
                  {needsDiscordTicket
                    ? "Finish this order in Discord"
                    : "Payment instructions"}
                </h2>
                <span className="chip mono text-[0.66rem]">
                  Order #{orderNumber}
                </span>
              </div>
              <p className="mt-2 whitespace-pre-line text-[0.8rem] leading-relaxed text-ink-soft/85">
                {discordInstructions}
              </p>
              {needsDiscordTicket && (
                <a
                  href={discordInvite}
                  target="_blank"
                  rel="noreferrer"
                  className="btn btn-primary btn-sm mt-3"
                >
                  <MessageSquare className="size-4" />
                  Open a ticket in Discord
                  <ArrowRight className="size-3.5" />
                </a>
              )}
              <p className="mt-3 text-[0.7rem] leading-relaxed text-mutedblue">
                Your {order.server_name} server is reserved. It is provisioned
                and your panel login is emailed as soon as the payment is
                confirmed — usually within a few minutes during support hours.
              </p>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}

function SuccessSkeleton() {
  return (
    <div className="container-x py-8">
      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <div className="h-[30rem] animate-pulse rounded-2xl bg-white/60" />
        <div className="h-80 animate-pulse rounded-2xl bg-white/60" />
      </div>
    </div>
  );
}
