import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowRight, LifeBuoy, MessageSquarePlus } from "lucide-react";
import { StatusPill } from "@/components/status-pill";
import { getCurrentUser } from "@/lib/auth";
import {
  PRIORITY_META,
  TICKET_STATUS_META,
  relativeTime,
} from "@/lib/format";
import { getTicketsForUser } from "@/lib/queries";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Support" };

const CATEGORY_LABEL: Record<string, string> = {
  server: "Game server",
  panel: "Panel access",
  billing: "Billing",
  general: "General",
};

export default async function SupportPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/support");

  const tickets = getTicketsForUser(user.id);
  const open = tickets.filter((ticket) => ticket.status !== "closed").length;

  return (
    <div className="mx-auto max-w-[1120px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">Support</h1>
          <p className="mt-1.5 max-w-[52ch] text-[0.84rem] leading-relaxed text-ink-soft/80">
            {open > 0
              ? `${open} open ${open === 1 ? "conversation" : "conversations"}. Replies land here and in your email.`
              : "Open a ticket and a person who knows the panel will answer. Median first reply is eleven minutes."}
          </p>
        </div>
        <Link href="/dashboard/support/new" className="btn btn-primary btn-sm">
          <MessageSquarePlus className="size-4" />
          New ticket
        </Link>
      </div>

      {tickets.length === 0 ? (
        <div className="glass mt-6 rounded-2xl p-10 text-center">
          <span className="mx-auto grid size-12 place-items-center rounded-2xl bg-white/80 text-[#0a63ff] shadow-sm">
            <LifeBuoy className="size-6" />
          </span>
          <h2 className="display-soft mt-4 text-[1.25rem] text-ink">
            Nothing open. Good sign.
          </h2>
          <p className="mx-auto mt-1.5 max-w-[42ch] text-[0.82rem] leading-relaxed text-ink-soft/80">
            If a server misbehaves or a payment looks off, start here. We can
            read the node logs with the server name.
          </p>
          <Link href="/dashboard/support/new" className="btn btn-primary btn-sm mt-5">
            Open your first ticket
          </Link>
        </div>
      ) : (
        <div className="mt-5 space-y-2.5">
          {tickets.map((ticket) => {
            const status = TICKET_STATUS_META[ticket.status] ?? TICKET_STATUS_META.open;
            const priority = PRIORITY_META[ticket.priority] ?? PRIORITY_META.normal;
            return (
              <Link
                key={ticket.id}
                href={`/dashboard/support/${ticket.id}`}
                className="glass group flex flex-wrap items-center gap-3 rounded-2xl p-4 transition hover:-translate-y-px"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="truncate text-[0.88rem] font-semibold text-ink">
                      {ticket.subject}
                    </h2>
                    <StatusPill label={status.label} tone={status.tone} dot />
                    <span className="text-[0.66rem] text-mutedblue">
                      {CATEGORY_LABEL[ticket.category] ?? ticket.category}
                    </span>
                  </div>
                  <p className="mt-1 text-[0.7rem] text-mutedblue">
                    {ticket.message_count}{" "}
                    {ticket.message_count === 1 ? "message" : "messages"} · updated{" "}
                    {relativeTime(ticket.updated_at)} · {priority.label} priority
                  </p>
                </div>
                <ArrowRight className="size-4 text-[#7fa5c2] transition group-hover:-rotate-45 group-hover:text-[#0a63ff]" />
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
