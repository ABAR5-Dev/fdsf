import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ExternalLink } from "lucide-react";
import { CategoryForm } from "@/components/app/category-form";
import { StatusPill } from "@/components/status-pill";
import { getCategoryById, getProducts } from "@/lib/queries";

type PageProps = { params: Promise<{ id: string }> };

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const category = getCategoryById(id);
  return { title: category?.name ?? "Category" };
}

export default async function EditCategoryPage({ params }: PageProps) {
  await requireAdmin("/admin/categories");
  const { id } = await params;
  const category = getCategoryById(id);
  if (!category) notFound();

  const products = getProducts({ categoryId: category.id });

  return (
    <div className="mx-auto max-w-[960px]">
      <Link
        href="/admin/categories"
        className="inline-flex items-center gap-1.5 text-[0.74rem] font-medium text-mutedblue transition hover:text-ink"
      >
        <ArrowLeft className="size-3.5" />
        Categories
      </Link>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <h1 className="display text-[1.8rem] text-ink sm:text-[2.1rem]">
            {category.name}
          </h1>
          <StatusPill
            label={category.active === 1 ? "Live" : "Hidden"}
            tone={category.active === 1 ? "mint" : "slate"}
            dot
          />
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[0.72rem] text-mutedblue">
            {products.length} {products.length === 1 ? "product" : "products"}
          </span>
          {category.active === 1 && (
            <Link
              href={`/store/${category.slug}`}
              target="_blank"
              className="btn btn-secondary btn-sm"
            >
              View in store
              <ExternalLink className="size-3.5" />
            </Link>
          )}
        </div>
      </div>

      <div className="mt-5">
        <CategoryForm category={category} />
      </div>
    </div>
  );
}
