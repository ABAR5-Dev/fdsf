"use client";

import { useActionState } from "react";
import { CheckCircle2, Loader2, Save } from "lucide-react";
import { saveServerNotesAction } from "@/lib/actions/admin";

export function ServerNotesForm({
  serverId,
  notes,
}: {
  serverId: string;
  notes: string;
}) {
  const [state, action, pending] = useActionState(saveServerNotesAction, null);

  return (
    <form action={action} className="mt-2">
      <input type="hidden" name="server_id" value={serverId} />
      <textarea
        name="notes"
        rows={5}
        defaultValue={notes}
        placeholder="Internal notes: node migration, ticket history, customer requests."
        className="textarea"
        aria-label="Internal server notes"
      />
      {state?.error && (
        <p role="alert" className="mt-1.5 text-[0.72rem] text-[#a13b3b]">
          {state.error}
        </p>
      )}
      {state?.success && (
        <p className="mt-1.5 flex items-center gap-1 text-[0.72rem] text-[#0a7a4e]">
          <CheckCircle2 className="size-3" />
          {state.success}
        </p>
      )}
      <div className="mt-2 flex items-center justify-between gap-2">
        <span className="text-[0.66rem] text-mutedblue">
          Visible to staff only unless you paste it into a reply.
        </span>
        <button type="submit" disabled={pending} className="btn btn-secondary btn-sm">
          {pending ? (
            <>
              <Loader2 className="size-3.5 animate-spin" />
              Saving
            </>
          ) : (
            <>
              <Save className="size-3.5" />
              Save notes
            </>
          )}
        </button>
      </div>
    </form>
  );
}
