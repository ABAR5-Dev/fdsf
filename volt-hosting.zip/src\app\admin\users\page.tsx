import type { Metadata } from "next";
import { Search, ShieldCheck, UserRoundCog, Users } from "lucide-react";
import { Avatar } from "@/components/avatar";
import { StatusPill } from "@/components/status-pill";
import { getCurrentUser } from "@/lib/auth";
import { dateLabel, money } from "@/lib/format";
import { getAllOrders, getAllServers, getUsers } from "@/lib/queries";
import { setUserRoleAction } from "@/lib/actions/admin";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Customers" };

type PageProps = { searchParams: Promise<{ q?: string }> };

export default async function AdminUsersPage({ searchParams }: PageProps) {
  const { q = "" } = await searchParams;
  const query = q.trim().toLowerCase();
  const me = await getCurrentUser();
  const users = getUsers();
  const servers = getAllServers();
  const orders = getAllOrders(500);

  const filtered = users.filter((user) => {
    if (!query) return true;
    return `${user.name} ${user.email}`.toLowerCase().includes(query);
  });

  const admins = users.filter((user) => user.role === "admin").length;

  return (
    <div className="mx-auto max-w-[1240px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">Customers</h1>
          <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
            Accounts, spend and who can open the admin panel.
          </p>
        </div>
        <span className="text-[0.74rem] text-mutedblue">
          {users.length} accounts · {admins} admin{admins === 1 ? "" : "s"}
        </span>
      </div>

      <form method="get" action="/admin/users" className="relative mt-4 max-w-[320px]">
        <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-[#8aa8bc]" />
        <input
          name="q"
          defaultValue={q}
          placeholder="Name or email"
          className="input h-9 pl-8 text-[0.78rem]"
        />
      </form>

      <section className="glass mt-3 rounded-2xl p-2 sm:p-3">
        {filtered.length === 0 ? (
          <div className="py-14 text-center">
            <span className="mx-auto grid size-11 place-items-center rounded-xl bg-white/80 text-[#0a63ff]">
              <Users className="size-5" />
            </span>
            <p className="mt-3 text-[0.86rem] font-semibold text-ink">
              {query ? "No customer matches." : "No accounts yet."}
            </p>
            <p className="mt-1 text-[0.76rem] text-mutedblue">
              {query
                ? "Try part of the email address."
                : "Signups appear here as soon as they register."}
            </p>
          </div>
        ) : (
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th scope="col">Account</th>
                  <th scope="col">Panel user</th>
                  <th scope="col">Joined</th>
                  <th scope="col">Servers</th>
                  <th scope="col">Spend</th>
                  <th scope="col">Role</th>
                  <th scope="col" className="text-right">
                    Access
                  </th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((user) => {
                  const owned = servers.filter((server) => server.user_id === user.id);
                  const spent = orders
                    .filter(
                      (order) =>
                        order.user_id === user.id &&
                        order.paid_at &&
                        order.status !== "refunded",
                    )
                    .reduce((sum, order) => sum + order.amount_cents, 0);
                  const isMe = me?.id === user.id;
                  return (
                    <tr key={user.id}>
                      <td>
                        <div className="flex items-center gap-2">
                          <Avatar
                            name={user.name}
                            src={user.avatar_url ?? ""}
                            size={28}
                          />
                          <div className="min-w-0">
                            <span className="block truncate text-[0.8rem] font-medium text-ink">
                              {user.name}
                              {isMe ? " (you)" : ""}
                            </span>
                            <span className="truncate text-[0.64rem] text-mutedblue">
                              {user.email}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="mono whitespace-nowrap text-[0.7rem] text-ink-soft">
                        {user.panel_username ?? "—"}
                      </td>
                      <td className="whitespace-nowrap text-[0.72rem] text-mutedblue">
                        {dateLabel(user.created_at)}
                      </td>
                      <td className="mono whitespace-nowrap text-[0.74rem]">
                        {owned.length}
                      </td>
                      <td className="mono whitespace-nowrap text-[0.74rem]">
                        {money(spent)}
                      </td>
                      <td>
                        <StatusPill
                          label={user.role === "admin" ? "Admin" : "Customer"}
                          tone={user.role === "admin" ? "blue" : "slate"}
                          dot
                        />
                      </td>
                      <td className="text-right">
                        {isMe ? (
                          <span className="inline-flex items-center gap-1 text-[0.68rem] text-mutedblue">
                            <ShieldCheck className="size-3" />
                            You
                          </span>
                        ) : (
                          <form action={setUserRoleAction}>
                            <input type="hidden" name="user_id" value={user.id} />
                            <input
                              type="hidden"
                              name="role"
                              value={user.role === "admin" ? "customer" : "admin"}
                            />
                            <button
                              type="submit"
                              className="inline-flex items-center gap-1 rounded-lg border border-white/90 bg-white/60 px-2 py-1 text-[0.68rem] font-medium text-ink-soft transition hover:border-[#c3d6e6] hover:text-[#0a63ff]"
                            >
                              <UserRoundCog className="size-3" />
                              {user.role === "admin" ? "Make customer" : "Make admin"}
                            </button>
                          </form>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <p className="mt-3 px-1 text-[0.7rem] leading-relaxed text-mutedblue">
        Admins can see every customer, server and payment method. Promote only
        people who need that. You cannot remove your own admin role.
      </p>
    </div>
  );
}
