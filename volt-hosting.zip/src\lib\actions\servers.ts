"use server";

import { revalidatePath } from "next/cache";
import { getCurrentUser } from "../auth";
import { getServerForUser } from "../queries";
import { syncServerStatus } from "../provision";

export async function refreshServerAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) return;
  const id = String(formData.get("server_id") ?? "");
  const server = getServerForUser(id, user.id);
  if (!server) return;
  await syncServerStatus(server.id);
  revalidatePath(`/dashboard/servers/${server.id}`);
  revalidatePath("/dashboard/servers");
  revalidatePath("/dashboard");
}
