"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  Bot,
  CarFront,
  Check,
  Copy,
  Flame,
  Gamepad2,
  Pickaxe,
  Radio,
  RotateCcw,
  Zap,
} from "lucide-react";
import { money } from "@/lib/format";
import type { PricingSettings } from "@/lib/types";

type Tone = "cmd" | "info" | "ok" | "accent" | "muted";
type Line = { text: string; tone: Tone };

const GAMES = [
  {
    slug: "minecraft",
    label: "Minecraft",
    icon: Pickaxe,
    runtime: "temurin java 21 · paper 1.21",
    port: 25565,
    ping: 18,
    subtitle: "SMP · vanilla+",
  },
  {
    slug: "fivem",
    label: "FiveM",
    icon: CarFront,
    runtime: "fxserver 9243 · txAdmin",
    port: 30120,
    ping: 21,
    subtitle: "LS County RP",
  },
  {
    slug: "rust",
    label: "Rust",
    icon: Flame,
    runtime: "oxide · rust staging",
    port: 28015,
    ping: 24,
    subtitle: "Rusted North",
  },
  {
    slug: "samp",
    label: "SA-MP",
    icon: Gamepad2,
    runtime: "open.mp 1.4 · pawno",
    port: 7777,
    ping: 19,
    subtitle: "Grove Street",
  },
  {
    slug: "discord-bots",
    label: "Bots",
    icon: Bot,
    runtime: "node 22 · npm ci",
    port: 3000,
    ping: 12,
    subtitle: "Pocket Bot",
  },
] as const;

export function HeroConsole({ pricing }: { pricing: PricingSettings }) {
  const [gameSlug, setGameSlug] = useState<string>("minecraft");
  const [ramGb, setRamGb] = useState(4);
  const [name, setName] = useState("smp-season-six");
  const [phase, setPhase] = useState<"booting" | "online">("booting");
  const [lines, setLines] = useState<Line[]>([]);
  const [copied, setCopied] = useState(false);
  const logRef = useRef<HTMLDivElement>(null);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);

  const game = GAMES.find((item) => item.slug === gameSlug) ?? GAMES[0];
  const monthly =
    pricing.baseCents + Math.round(ramGb * pricing.ramPerGbCents);

  const clearTimers = useCallback(() => {
    timers.current.forEach((timer) => clearTimeout(timer));
    timers.current = [];
  }, []);

  const runBoot = useCallback(
    (slug: string, ram: number, serverName: string, delay = 0) => {
      clearTimers();
      const selected = GAMES.find((item) => item.slug === slug) ?? GAMES[0];
      const safeName =
        serverName
          .toLowerCase()
          .replace(/[^a-z0-9-]+/g, "-")
          .replace(/^-+|-+$/g, "")
          .slice(0, 24) || selected.slug;
      const address = `${safeName}.${selected.slug === "discord-bots" ? "bot" : "fra"}.volt.gg`;

      const script: Line[] = [
        {
          text: `$ volt deploy ${selected.slug} --ram ${ram} --region fra`,
          tone: "cmd",
        },
        { text: "resolving capacity on fra-03", tone: "info" },
        {
          text: `allocation reserved · ${ram} GB RAM · ${Math.max(10, ram * 3)} GB NVMe`,
          tone: "ok",
        },
        { text: `pulling ${selected.runtime}`, tone: "info" },
        { text: "writing startup variables and ports", tone: "info" },
        { text: "world container built · 6.2s", tone: "ok" },
        { text: `✓ ${selected.subtitle.toLowerCase()} is online`, tone: "accent" },
        {
          text: `${address}:${selected.port}`,
          tone: "accent",
        },
        { text: "panel credentials sent to your inbox", tone: "muted" },
      ];

      setLines([script[0]]);
      setPhase("booting");

      let elapsed = delay;
      script.slice(1).forEach((line, index) => {
        elapsed += 300 + Math.round(Math.random() * 260);
        const timer = setTimeout(() => {
          setLines((current) => [...current, line]);
          if (index === script.length - 2) setPhase("online");
        }, elapsed);
        timers.current.push(timer);
      });
    },
    [clearTimers],
  );

  useEffect(() => {
    const reduced =
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const timer = setTimeout(() => {
      runBoot("minecraft", 4, "smp-season-six", reduced ? 0 : 450);
    }, 250);
    return () => {
      clearTimeout(timer);
      clearTimers();
    };
  }, [runBoot, clearTimers]);

  useEffect(() => {
    const node = logRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [lines]);

  const copyAddress = async () => {
    const address = `${name || game.subtitle}.${game.slug === "discord-bots" ? "bot" : "fra"}.volt.gg:${game.port}`;
    try {
      await navigator.clipboard.writeText(address);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  };

  const fill = `${((ramGb - 2) / 14) * 100}%`;

  return (
    <div className="relative">
      <div
        aria-hidden="true"
        className="absolute -inset-6 -z-10 rounded-[38px] bg-[radial-gradient(60%_60%_at_70%_0%,rgba(39,178,255,0.34),transparent_70%)] blur-2xl"
      />
      <div className="console noise overflow-hidden rounded-[26px] p-2.5 sm:p-3">
        <div className="console-grid pointer-events-none absolute inset-0 opacity-70" />

        <div className="relative">
          {/* window chrome */}
          <div className="flex items-center justify-between gap-3 px-1.5 pb-2.5 pt-1">
            <div className="flex items-center gap-2">
              <span className="size-2 rounded-full bg-[#ff6b6b]/70" />
              <span className="size-2 rounded-full bg-[#ffce6b]/70" />
              <span className="size-2 rounded-full bg-[#5be3a6]/80" />
              <span className="mono ml-1.5 text-[0.64rem] tracking-wide text-[#8ec6e8]/80">
                volt://deploy · fra-03
              </span>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-[#5ad2ff]/25 bg-[#5ad2ff]/10 px-2 py-0.5 text-[0.6rem] font-semibold text-[#8fe6ff]">
              <span className="live-dot size-1.5 rounded-full bg-[#5be3a6]" />
              live preview
            </span>
          </div>

          {/* terminal */}
          <div
            ref={logRef}
            className="scrollbar-thin h-[178px] overflow-y-auto rounded-xl border border-[#7ecdff]/12 bg-[#031726]/70 px-3 py-2.5 sm:h-[196px]"
            role="log"
            aria-live="polite"
            aria-label="Deployment preview output"
          >
            <div className="space-y-[5px]">
              {lines.map((line, index) => (
                <p
                  key={`${line.text}-${index}`}
                  className={[
                    "mono flex gap-2 text-[0.68rem] leading-[1.55] sm:text-[0.72rem]",
                    line.tone === "cmd" && "text-[#e8f8ff]",
                    line.tone === "info" && "text-[#8fb9d6]",
                    line.tone === "ok" && "text-[#7fdcc8]",
                    line.tone === "accent" && "text-[#6fdcff]",
                    line.tone === "muted" && "text-[#6e93ac]",
                  ]
                    .filter(Boolean)
                    .join(" ")}
                >
                  <span className="select-none text-[#3f7fa3]">
                    {line.tone === "cmd" ? "" : "›"}
                  </span>
                  <span className={line.tone === "accent" ? "font-semibold" : ""}>
                    {line.text}
                  </span>
                </p>
              ))}
              {phase === "online" && (
                <p className="mono flex gap-2 text-[0.68rem] leading-[1.55] text-[#6fdcff] sm:text-[0.72rem]">
                  <span className="select-none text-[#3f7fa3]">›</span>
                  <span className="caret" />
                </p>
              )}
            </div>
          </div>

          {/* controls */}
          <div className="mt-2.5 rounded-xl border border-[#7ecdff]/14 bg-[#061f35]/70 p-2.5">
            <div
              className="scrollbar-thin flex items-center gap-1 overflow-x-auto pb-0.5"
              role="tablist"
              aria-label="Game"
            >
              {GAMES.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.slug}
                    type="button"
                    role="tab"
                    aria-selected={gameSlug === item.slug}
                    data-active={gameSlug === item.slug}
                    onClick={() => {
                      setGameSlug(item.slug);
                      setPhase("booting");
                      setLines([]);
                    }}
                    className="console-tab"
                  >
                    <Icon className="size-3.5" />
                    {item.label}
                  </button>
                );
              })}
            </div>

            <div className="mt-2.5 grid gap-2.5 sm:grid-cols-[1.1fr_1fr]">
              <label className="block">
                <span className="mb-1 block text-[0.6rem] font-semibold text-[#8fb9d6]">
                  Server name
                </span>
                <input
                  value={name}
                  onChange={(event) =>
                    setName(event.target.value.replace(/[^a-zA-Z0-9-]/g, "").slice(0, 24))
                  }
                  spellCheck={false}
                  className="console-field mono"
                  placeholder="my-server"
                  aria-label="Server name"
                />
              </label>
              <div>
                <div className="mb-1 flex items-center justify-between text-[0.6rem] font-semibold text-[#8fb9d6]">
                  <span>Memory</span>
                  <span className="mono text-[#bcecff]">{ramGb} GB</span>
                </div>
                <input
                  type="range"
                  min={2}
                  max={16}
                  step={1}
                  value={ramGb}
                  aria-label="Memory in gigabytes"
                  onChange={(event) => setRamGb(Number(event.target.value))}
                  className="console-range mt-2.5"
                  style={{ "--range-fill": fill } as React.CSSProperties}
                />
              </div>
            </div>

            <div className="mt-3 flex items-center justify-between gap-3">
              <div>
                <p className="mono text-[0.95rem] font-semibold leading-none text-white">
                  {money(monthly)}
                  <span className="ml-1 text-[0.62rem] font-medium text-[#7fa9c4]">
                    /mo
                  </span>
                </p>
                <p className="mt-1 text-[0.6rem] text-[#6e93ad]">
                  {game.subtitle} · Frankfurt
                </p>
              </div>
              <div className="flex items-center gap-1.5">
                {phase === "online" ? (
                  <>
                    <button
                      type="button"
                      onClick={copyAddress}
                      className="inline-flex items-center gap-1 rounded-lg border border-[#7ecdff]/25 bg-[#7ecdff]/10 px-2 py-1.5 text-[0.66rem] font-semibold text-[#bcecff] transition hover:bg-[#7ecdff]/16"
                    >
                      {copied ? <Check className="size-3" /> : <Copy className="size-3" />}
                      {copied ? "Copied" : "Address"}
                    </button>
                    <Link
                      href={`/checkout?custom=${game.slug}&ram=${ramGb}&name=${encodeURIComponent(name || game.subtitle)}`}
                      className="inline-flex items-center gap-1 rounded-lg bg-gradient-to-b from-[#36a7ff] to-[#0b7be0] px-2.5 py-1.5 text-[0.68rem] font-semibold text-white shadow-[0_8px_18px_-8px_rgba(30,170,255,0.9)] transition hover:brightness-110"
                    >
                      Get this server
                      <ArrowRight className="size-3" />
                    </Link>
                  </>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => runBoot(gameSlug, ramGb, name)}
                      className="inline-flex items-center gap-1 rounded-lg bg-[#0d2c46]/80 px-2 py-1.5 text-[0.66rem] font-semibold text-[#8fb9d6] transition hover:text-[#cdeeff]"
                      title="Replay the preview"
                    >
                      <RotateCcw className="size-3" />
                      Replay
                    </button>
                    <button
                      type="button"
                      onClick={() => runBoot(gameSlug, ramGb, name)}
                      className="inline-flex items-center gap-1 rounded-lg bg-gradient-to-b from-[#36a7ff] to-[#0b7be0] px-2.5 py-1.5 text-[0.68rem] font-semibold text-white shadow-[0_8px_18px_-8px_rgba(30,170,255,0.9)] transition hover:brightness-110"
                    >
                      <Zap className="size-3" />
                      Preview deploy
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* telemetry strip */}
          <div className="mt-2 flex items-center justify-between gap-2 px-1.5 pb-0.5 text-[0.6rem] text-[#6e93ad]">
            <span className="inline-flex items-center gap-1.5">
              <Radio className="size-3 text-[#5be3a6]" />
              {phase === "online" ? "accepting connections" : "provisioning"}
            </span>
            <span className="mono flex items-center gap-3">
              <span>{game.ping} ms</span>
              <span className="hidden sm:inline">128 tick</span>
              <span>99.99%</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
