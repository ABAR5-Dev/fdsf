const TONES: Record<string, string> = {
  blue: "border-[#cfe6ff] bg-[#e6f2ff] text-[#0a5fbe]",
  mint: "border-[#c9eeda] bg-[#e9f9f0] text-[#0a7a4e]",
  amber: "border-[#f5e2c0] bg-[#fff6e6] text-[#8a5a12]",
  rose: "border-[#f3d0d0] bg-[#fff1f1] text-[#a13b3b]",
  slate: "border-[#dfeaf3] bg-[#f0f5f9] text-[#557289]",
};

export function StatusPill({
  label,
  tone,
  dot,
}: {
  label: string;
  tone: string;
  dot?: boolean;
}) {
  return (
    <span className={`pill border ${TONES[tone] ?? TONES.slate}`}>
      {dot && <span className="pill-dot" aria-hidden="true" />}
      {label}
    </span>
  );
}
