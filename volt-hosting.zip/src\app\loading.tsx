export default function Loading() {
  return (
    <div className="container-x flex min-h-[60vh] flex-col items-center justify-center py-20">
      <span className="relative grid size-12 place-items-center">
        <span className="absolute inset-0 animate-ping rounded-2xl bg-[#0a63ff]/15" />
        <span className="relative grid size-12 place-items-center rounded-2xl border border-white/90 bg-white/75 shadow-sm">
          <span className="size-4 animate-spin rounded-full border-2 border-[#cfe6ff] border-t-[#0a63ff]" />
        </span>
      </span>
      <p className="mono mt-4 text-[0.7rem] text-mutedblue">booting…</p>
    </div>
  );
}
