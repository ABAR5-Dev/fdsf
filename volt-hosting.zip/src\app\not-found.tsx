import Link from "next/link";
import { ArrowRight, Compass } from "lucide-react";
import { Brand } from "@/components/brand";

export default function NotFound() {
  return (
    <div className="container-x flex min-h-[72vh] max-w-[640px] flex-col items-center justify-center py-16 text-center">
      <Brand />
      <span className="mt-10 grid size-14 place-items-center rounded-2xl border border-white/90 bg-white/70 text-[#0a63ff] shadow-sm">
        <Compass className="size-6" />
      </span>
      <p className="mono mt-5 text-[0.7rem] text-mutedblue">error 404</p>
      <h1 className="display mt-2 text-[2.2rem] text-ink sm:text-[2.7rem]">
        This world has not been generated.
      </h1>
      <p className="mt-3 max-w-[44ch] text-[0.88rem] leading-relaxed text-ink-soft/85">
        The page you were looking for moved, never existed, or the link has a
        typo. The store and your dashboard are both one click away.
      </p>
      <div className="mt-6 flex flex-wrap justify-center gap-2">
        <Link href="/" className="btn btn-primary btn-sm">
          Back to home
          <ArrowRight className="size-4" />
        </Link>
        <Link href="/store" className="btn btn-secondary btn-sm">
          Browse game servers
        </Link>
        <Link href="/dashboard" className="btn btn-secondary btn-sm">
          Dashboard
        </Link>
      </div>
    </div>
  );
}
