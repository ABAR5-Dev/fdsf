"use client";

import { termDiscount } from "@/lib/format";
import type { PricingSettings } from "@/lib/types";

const TERMS = [1, 3, 12];

export function BillingTerms({
  value,
  onChange,
  pricing,
  name = "billing_months",
}: {
  value: number;
  onChange?: (months: number) => void;
  pricing: PricingSettings;
  name?: string;
}) {
  return (
    <div
      className="inline-flex w-full rounded-xl border border-white/90 bg-white/55 p-1"
      role={onChange ? "group" : undefined}
      aria-label="Billing term"
    >
      {TERMS.map((months) => {
        const discount = termDiscount(months, pricing);
        const selected = value === months;
        return (
          <button
            key={months}
            type={onChange ? "button" : "submit"}
            name={onChange ? undefined : name}
            value={onChange ? undefined : months}
            onClick={onChange ? () => onChange(months) : undefined}
            aria-pressed={onChange ? selected : undefined}
            className={[
              "flex-1 rounded-lg px-2 py-2 text-[0.78rem] font-semibold transition",
              selected
                ? "bg-white text-ink shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_6px_14px_-10px_rgba(10,80,160,0.5)]"
                : "text-mutedblue hover:text-ink",
            ].join(" ")}
          >
            {months === 1 ? "Monthly" : months === 3 ? "Quarterly" : "Yearly"}
            {discount > 0 && (
              <span
                className={[
                  "ml-1 text-[0.62rem] font-bold",
                  selected ? "text-[#177a52]" : "text-[#3f9c72]",
                ].join(" ")}
              >
                −{discount}%
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
