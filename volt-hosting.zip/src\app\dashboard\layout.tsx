import { Suspense } from "react";
import { redirect } from "next/navigation";
import { AppChrome, type NavItem } from "@/components/app/app-chrome";
import { getCurrentUser } from "@/lib/auth";
import { getTicketsForUser } from "@/lib/queries";

// The customer dashboard is session-scoped, so let navigation wait for the
// user lookup instead of trying to paint a static shell first.
export const instant = false;

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <Suspense fallback={<ChromeSkeleton />}>
      <DashboardShell>{children}</DashboardShell>
    </Suspense>
  );
}

async function DashboardShell({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard");

  const tickets = getTicketsForUser(user.id);
  const openTickets = tickets.filter((ticket) => ticket.status !== "closed").length;

  const items: NavItem[] = [
    { href: "/dashboard", label: "Overview", icon: "LayoutDashboard", exact: true },
    { href: "/dashboard/servers", label: "My servers", icon: "Server" },
    { href: "/dashboard/billing", label: "Billing", icon: "ReceiptText" },
    {
      href: "/dashboard/support",
      label: "Support",
      icon: "LifeBuoy",
      badge: openTickets,
    },
    { href: "/dashboard/account", label: "Account", icon: "UserRound" },
  ];

  return (
    <AppChrome
      items={items}
      user={{
        name: user.name,
        email: user.email,
        role: user.role,
        avatarUrl: user.avatarUrl,
      }}
      area="customer"
    >
      {children}
    </AppChrome>
  );
}

function ChromeSkeleton() {
  return (
    <div className="app-shell">
      <aside className="app-sidebar">
        <div className="px-2">
          <div className="size-9 animate-pulse rounded-[11px] bg-white/70" />
        </div>
        <div className="mt-8 space-y-2 px-2">
          {[0, 1, 2, 3, 4].map((item) => (
            <div key={item} className="h-9 animate-pulse rounded-lg bg-white/55" />
          ))}
        </div>
      </aside>
      <div className="min-w-0">
        <div className="h-14 border-b border-white/60 bg-white/40" />
        <div className="space-y-4 px-4 py-6 sm:px-6 lg:px-8">
          <div className="h-8 w-64 animate-pulse rounded-lg bg-white/70" />
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {[0, 1, 2, 3].map((item) => (
              <div key={item} className="h-24 animate-pulse rounded-2xl bg-white/55" />
            ))}
          </div>
          <div className="h-64 animate-pulse rounded-2xl bg-white/55" />
        </div>
      </div>
    </div>
  );
}
