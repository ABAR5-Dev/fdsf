import Link from "next/link";
import { cn } from "@/lib/utils";

export function BoltMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      fill="none"
      aria-hidden="true"
      className={cn("h-full w-full", className)}
    >
      <path
        d="M16 2.4 27.7 9v14L16 29.6 4.3 23V9L16 2.4Z"
        fill="url(#bolt-face)"
        stroke="rgba(255,255,255,0.55)"
        strokeWidth="1"
      />
      <path
        d="M18.2 8.2 11 17.4h4.1l-1.3 6.6 7.2-9.5h-4.2l1.4-6.3Z"
        fill="#ffffff"
      />
      <defs>
        <linearGradient id="bolt-face" x1="5" y1="3" x2="28" y2="30">
          <stop stopColor="#2f8dff" />
          <stop offset="0.55" stopColor="#0a63ff" />
          <stop offset="1" stopColor="#0a49c8" />
        </linearGradient>
      </defs>
    </svg>
  );
}

export function Brand({
  name = "Volt Hosting",
  href = "/",
  compact = false,
}: {
  name?: string;
  href?: string;
  compact?: boolean;
}) {
  return (
    <Link
      href={href}
      className="group inline-flex items-center gap-2.5 rounded-xl focus-visible:outline-offset-4"
      aria-label={`${name} home`}
    >
      <span className="relative grid size-9 shrink-0 place-items-center rounded-[11px] bg-white/70 p-[3px] shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_8px_18px_-10px_rgba(10,80,170,0.5)] ring-1 ring-white/90 transition-transform duration-300 group-hover:-rotate-3">
        <BoltMark />
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="display-soft text-[1.02rem] tracking-[-0.03em] text-ink">
            {name}
          </span>
          <span className="mono mt-0.5 text-[0.56rem] tracking-[0.14em] text-mutedblue/80">
            GAME INFRASTRUCTURE
          </span>
        </span>
      )}
    </Link>
  );
}
