import { db } from "./db";
import type { PromoCodeRow } from "./types";

export type PromoEvaluation =
  | { ok: true; promo: PromoCodeRow; discountCents: number }
  | { ok: false; error: string };

export function normalizePromoCode(value: string): string {
  return value.trim().toUpperCase().replace(/\s+/g, "");
}

export function promoExpired(expiresAt: string | null): boolean {
  return Boolean(expiresAt && new Date(expiresAt).getTime() < Date.now());
}

export function getPromoByCode(code: string): PromoCodeRow | undefined {
  const normalized = normalizePromoCode(code);
  if (!normalized) return undefined;
  return db
    .prepare("SELECT * FROM promo_codes WHERE code = ? COLLATE NOCASE")
    .get(normalized) as PromoCodeRow | undefined;
}

/**
 * Server-side source of truth for a promo code. Never trust a discount the
 * browser sends; recompute it from the stored code and the order total.
 */
export function evaluatePromo(
  rawCode: string,
  amountCents: number,
): PromoEvaluation {
  const code = normalizePromoCode(rawCode);
  if (!code) return { ok: false, error: "Enter a promo code." };
  if (code.length > 32) return { ok: false, error: "That promo code is not valid." };

  const promo = getPromoByCode(code);
  if (!promo) return { ok: false, error: "That promo code is not valid." };
  if (!promo.active) {
    return { ok: false, error: "That promo code is no longer active." };
  }
  if (promo.expires_at && new Date(promo.expires_at).getTime() <= Date.now()) {
    return { ok: false, error: "That promo code has expired." };
  }
  if (promo.max_uses > 0 && promo.used_count >= promo.max_uses) {
    return { ok: false, error: "That promo code has been used up." };
  }
  if (amountCents < promo.min_cents) {
    return {
      ok: false,
      error: "Your order does not meet the minimum spend for this code.",
    };
  }

  const raw =
    promo.kind === "percent"
      ? Math.round((amountCents * Math.min(100, Math.max(0, promo.value))) / 100)
      : Math.max(0, Math.round(promo.value));

  const discountCents = Math.min(amountCents, raw);
  if (discountCents <= 0) {
    return { ok: false, error: "That promo code does not apply to this order." };
  }

  return { ok: true, promo, discountCents };
}
