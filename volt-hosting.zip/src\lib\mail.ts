import { randomUUID } from "node:crypto";
import nodemailer from "nodemailer";
import { db } from "./db";
import { getPterodactyl, getSite, getSmtp } from "./queries";
import { escapeHtml, money, ramLabel, diskLabel } from "./format";
import type { OrderRow, ServerRow, UserRow } from "./types";

type MailInput = {
  to: string;
  subject: string;
  html: string;
  text: string;
};

function logEmail(input: MailInput, status: string, error?: string) {
  db.prepare(
    `INSERT INTO email_log (id, to_email, subject, status, error, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
  ).run(
    randomUUID(),
    input.to,
    input.subject,
    status,
    error ?? null,
    new Date().toISOString(),
  );
}

export async function sendMail(
  input: MailInput,
): Promise<{ ok: boolean; skipped?: boolean; error?: string }> {
  const smtp = getSmtp();

  if (!smtp.enabled || !smtp.host || !smtp.fromEmail) {
    logEmail(input, "simulated");
    if (process.env.NODE_ENV !== "production") {
      console.info(
        `[mail:simulated] to=${input.to} subject="${input.subject}"`,
      );
    }
    return { ok: true, skipped: true };
  }

  try {
    const transport = nodemailer.createTransport({
      host: smtp.host,
      port: smtp.port,
      secure: smtp.secure,
      auth:
        smtp.user.trim().length > 0
          ? { user: smtp.user, pass: smtp.pass }
          : undefined,
      connectionTimeout: 12_000,
      greetingTimeout: 12_000,
      socketTimeout: 20_000,
    });

    await transport.sendMail({
      from: `"${smtp.fromName || getSite().siteName}" <${smtp.fromEmail}>`,
      to: input.to,
      subject: input.subject,
      html: input.html,
      text: input.text,
    });

    logEmail(input, "sent");
    return { ok: true };
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Unknown SMTP failure";
    logEmail(input, "failed", message);
    console.error("[mail] send failed:", message);
    return { ok: false, error: message };
  }
}

function shell(title: string, body: string, siteName: string) {
  return `<!doctype html>
<html>
  <body style="margin:0;padding:0;background:#eaf6ff;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#08243d;">
    <div style="max-width:600px;margin:0 auto;padding:36px 20px;">
      <div style="display:flex;align-items:center;gap:10px;padding:0 4px 20px;">
        <span style="display:inline-block;width:34px;height:34px;border-radius:11px;background:linear-gradient(135deg,#0a63ff,#19c8ff);color:#fff;font-weight:800;text-align:center;line-height:34px;">V</span>
        <span style="font-size:15px;font-weight:700;letter-spacing:-0.02em;color:#08243d;">${escapeHtml(siteName)}</span>
      </div>
      <div style="background:#ffffff;border:1px solid #d3ecff;border-radius:22px;padding:34px 32px;box-shadow:0 24px 70px rgba(23,92,160,0.12);">
        <h1 style="margin:0 0 14px;font-size:24px;line-height:1.2;letter-spacing:-0.03em;color:#061f38;">${title}</h1>
        ${body}
      </div>
      <p style="font-size:12px;line-height:1.6;color:#567893;padding:20px 8px 0;margin:0;">
        This message was sent by ${escapeHtml(siteName)}. If you did not request it, you can safely ignore it.
      </p>
    </div>
  </body>
</html>`;
}

function p(text: string) {
  return `<p style="margin:0 0 14px;font-size:15px;line-height:1.65;color:#33546f;">${text}</p>`;
}

function button(label: string, href: string) {
  return `<a href="${href}" style="display:inline-block;margin:8px 0 18px;background:linear-gradient(135deg,#0a63ff,#12a6ff);color:#ffffff;text-decoration:none;font-size:14px;font-weight:700;padding:13px 22px;border-radius:12px;">${label}</a>`;
}

export async function sendWelcomeEmail(user: UserRow) {
  const site = getSite();
  const body = `
    ${p(`Hi ${escapeHtml(user.name.split(" ")[0] || user.name)},`)}
    ${p(`Your ${escapeHtml(site.siteName)} account is ready. You can deploy a game server, track invoices and reach the support team from your dashboard.`)}
    ${button("Open your dashboard", `${site.appUrl}/dashboard`)}
    ${p("If you get stuck, reply to this email or open a support ticket. A real person will answer.")}
  `;
  return sendMail({
    to: user.email,
    subject: `Welcome to ${site.siteName}`,
    html: shell("Your account is ready.", body, site.siteName),
    text: `Hi ${user.name}, your ${site.siteName} account is ready. Open your dashboard at ${site.appUrl}/dashboard.`,
  });
}

type ServerMailInput = {
  user: UserRow;
  server: ServerRow;
  order: OrderRow;
  password: string;
};

export async function sendServerReadyEmail({
  user,
  server,
  order,
  password,
}: ServerMailInput) {
  const site = getSite();
  const panelUrl = getPterodactyl().panelUrl.replace(/\/+$/, "");
  const serverDashboard = `${site.appUrl}/dashboard/servers/${server.id}`;
  const panelLogin = panelUrl ? `${panelUrl}/auth/login` : serverDashboard;

  const body = `
    ${p(`Hi ${escapeHtml(user.name.split(" ")[0] || user.name)},`)}
    ${p(`<strong>${escapeHtml(server.name)}</strong> has been assigned to your account and is ${server.status === "installing" ? "installing now" : "ready to use"}. Your Pterodactyl credentials are below.`)}
    <table style="width:100%;border-collapse:collapse;margin:6px 0 18px;font-size:14px;">
      <tr><td style="padding:9px 0;color:#6a8aa3;">Panel login</td><td style="padding:9px 0;text-align:right;font-weight:600;">${escapeHtml(panelUrl || "Configured in your dashboard")}</td></tr>
      <tr><td style="padding:9px 0;color:#6a8aa3;">Username</td><td style="padding:9px 0;text-align:right;font-weight:600;">${escapeHtml(server.panel_username)}</td></tr>
      <tr><td style="padding:9px 0;color:#6a8aa3;">Password</td><td style="padding:9px 0;text-align:right;font-weight:600;font-family:ui-monospace,monospace;">${escapeHtml(password)}</td></tr>
      <tr><td style="padding:9px 0;color:#6a8aa3;">RAM / CPU</td><td style="padding:9px 0;text-align:right;font-weight:600;">${ramLabel(server.ram_mb)} / ${server.cpu_pct / 100} vCPU</td></tr>
      <tr><td style="padding:9px 0;color:#6a8aa3;">NVMe</td><td style="padding:9px 0;text-align:right;font-weight:600;">${diskLabel(server.disk_mb)}</td></tr>
      <tr><td style="padding:9px 0;color:#6a8aa3;">Location</td><td style="padding:9px 0;text-align:right;font-weight:600;">${escapeHtml(server.region)}</td></tr>
      <tr><td style="padding:9px 0;color:#6a8aa3;">Order total</td><td style="padding:9px 0;text-align:right;font-weight:600;">${money(order.amount_cents, "USD")}</td></tr>
    </table>
    ${button("Open in your dashboard", serverDashboard)}
    ${p("For security, change the panel password after your first login. Keep this email private.")}
    ${p("Need a hand? Reply to this email or open a ticket from your dashboard.")}
  `;

  return sendMail({
    to: user.email,
    subject:
      server.status === "installing"
        ? `${server.name} is installing`
        : `${server.name} is ready`,
    html: shell(
      server.status === "installing"
        ? "Your server is installing."
        : "Your server is ready.",
      body,
      site.siteName,
    ),
    text: `Your server ${server.name} is ready. Panel: ${panelLogin || serverDashboard}. Username: ${server.panel_username}. Password: ${password}.`,
  });
}

export async function sendTicketReplyEmail(input: {
  to: string;
  name: string;
  subject: string;
  ticketId: string;
  reply: string;
}) {
  const site = getSite();
  const body = `
    ${p(`Hi ${escapeHtml(input.name.split(" ")[0] || input.name)},`)}
    ${p(`Support replied to <strong>${escapeHtml(input.subject)}</strong>:`)}
    <blockquote style="margin:0 0 18px;padding:14px 16px;background:#f2f9ff;border-left:3px solid #0a63ff;border-radius:8px;font-size:14px;line-height:1.65;color:#33546f;">${escapeHtml(input.reply).replaceAll("\n", "<br>")}</blockquote>
    ${button("View the ticket", `${site.appUrl}/dashboard/support/${input.ticketId}`)}
  `;
  return sendMail({
    to: input.to,
    subject: `Re: ${input.subject}`,
    html: shell("New reply from support.", body, site.siteName),
    text: `Support replied to ${input.subject}: ${input.reply}`,
  });
}

export async function sendPaymentPendingEmail(input: {
  user: UserRow;
  order: OrderRow;
  instructions: string;
}) {
  const site = getSite();
  const body = `
    ${p(`Hi ${escapeHtml(input.user.name.split(" ")[0] || input.user.name)},`)}
    ${p(`We received order <strong>${escapeHtml(input.order.id.slice(0, 8).toUpperCase())}</strong>. It is reserved and will be provisioned as soon as your payment of <strong>${money(input.order.amount_cents)}</strong> is confirmed.`)}
    ${p(escapeHtml(input.instructions).replaceAll("\n", "<br>"))}
    ${button("View order", `${site.appUrl}/checkout/success?order=${input.order.id}`)}
  `;
  return sendMail({
    to: input.user.email,
    subject: `Payment instructions for ${input.order.item_name}`,
    html: shell("Your order is reserved.", body, site.siteName),
    text: input.instructions,
  });
}
