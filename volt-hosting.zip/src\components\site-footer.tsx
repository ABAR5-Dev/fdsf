import Link from "next/link";
import { ArrowUpRight, MessagesSquare } from "lucide-react";
import { getSite } from "@/lib/queries";
import { Brand } from "./brand";
import { CopyrightYear } from "./copyright-year";

const COLUMNS = [
  {
    title: "Hosting",
    links: [
      { href: "/store/minecraft", label: "Minecraft" },
      { href: "/store/fivem", label: "FiveM" },
      { href: "/store/rust", label: "Rust" },
      { href: "/store/samp", label: "SA-MP" },
      { href: "/store/discord-bots", label: "Discord bots" },
      { href: "/store/vps", label: "Cloud VPS" },
    ],
  },
  {
    title: "Account",
    links: [
      { href: "/dashboard", label: "Dashboard" },
      { href: "/dashboard/servers", label: "My servers" },
      { href: "/dashboard/billing", label: "Billing" },
      { href: "/dashboard/support", label: "Support tickets" },
      { href: "/register", label: "Create account" },
    ],
  },
  {
    title: "Company",
    links: [
      { href: "/#why-volt", label: "Why Volt" },
      { href: "/#network", label: "Network" },
      { href: "/terms", label: "Terms of service" },
      { href: "/privacy", label: "Privacy" },
      { href: "/support", label: "Contact" },
    ],
  },
];

export function SiteFooter() {
  const site = getSite();

  return (
    <footer className="relative mt-16 overflow-hidden border-t border-white/70 bg-[#f7fcff]/62 pb-8 pt-14 backdrop-blur-xl">
      <div className="container-x">
        <div className="grid gap-10 lg:grid-cols-[1.35fr_repeat(3,minmax(0,0.7fr))]">
          <div>
            <Brand name={site.siteName} />
            <p className="mt-4 max-w-[30ch] text-sm leading-relaxed text-ink-soft/80">
              Game infrastructure that gets out of the way. Pick a world, pick
              your RAM, and let us handle the boring part.
            </p>
            <a
              href={site.discordInvite || "#"}
              target="_blank"
              rel="noreferrer"
              className="btn btn-secondary btn-sm mt-5"
            >
              <MessagesSquare className="size-4 text-[#5865f2]" />
              Join the Discord
              <ArrowUpRight className="size-3.5" />
            </a>
          </div>

          {COLUMNS.map((column) => (
            <div key={column.title}>
              <h2 className="text-[0.78rem] font-semibold text-ink">{column.title}</h2>
              <ul className="mt-3 space-y-2.5">
                {column.links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-[0.82rem] text-ink-soft/75 transition hover:text-[#0847a8]"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="hairline my-8" />

        <div className="flex flex-col gap-4 text-[0.75rem] text-mutedblue sm:flex-row sm:items-center sm:justify-between">
          <p>
            © <CopyrightYear /> {site.siteName}. Servers hosted in Frankfurt, London, New
            York, Dallas, Los Angeles, Singapore, Sydney and São Paulo.
          </p>
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
            <Link
              href="/status"
              className="inline-flex items-center gap-1.5 hover:text-[#0847a8]"
            >
              <span className="size-1.5 rounded-full bg-[#20b878]" />
              All systems operational
            </Link>
            <Link href="/terms" className="hover:text-[#0847a8]">
              Terms
            </Link>
            <Link href="/privacy" className="hover:text-[#0847a8]">
              Privacy
            </Link>
            <a
              href={`mailto:${site.supportEmail}`}
              className="hover:text-[#0847a8]"
            >
              {site.supportEmail}
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
