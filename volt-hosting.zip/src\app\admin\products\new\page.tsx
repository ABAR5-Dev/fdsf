import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { ProductForm } from "@/components/app/product-form";
import { getCategories } from "@/lib/queries";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "New product" };

export default async function NewProductPage() {
  await requireAdmin("/admin/products/new");
  const categories = getCategories();

  return (
    <div className="mx-auto max-w-[960px]">
      <Link
        href="/admin/products"
        className="inline-flex items-center gap-1.5 text-[0.74rem] font-medium text-mutedblue transition hover:text-ink"
      >
        <ArrowLeft className="size-3.5" />
        Products
      </Link>
      <h1 className="display mt-3 text-[1.9rem] text-ink sm:text-[2.2rem]">
        New product
      </h1>
      <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
        The slug and Pterodactyl mapping are created from these values.
      </p>

      {categories.length === 0 ? (
        <div className="glass mt-5 rounded-2xl p-8 text-center">
          <p className="text-[0.86rem] font-semibold text-ink">
            Create a category first.
          </p>
          <p className="mt-1 text-[0.76rem] text-mutedblue">
            Products belong to a category, and the category carries the egg
            defaults.
          </p>
          <Link href="/admin/categories" className="btn btn-primary btn-sm mt-4">
            Go to categories
          </Link>
        </div>
      ) : (
        <div className="mt-5">
          <ProductForm categories={categories} />
        </div>
      )}
    </div>
  );
}
