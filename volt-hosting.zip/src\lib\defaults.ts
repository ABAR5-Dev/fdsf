import type {
  DiscordSettings,
  PaymentSettings,
  PricingSettings,
  PterodactylSettings,
  SiteSettings,
  SmtpSettings,
} from "./types";

export const SITE_DEFAULTS: SiteSettings = {
  siteName: "Volt Hosting",
  tagline: "From checkout to spawn point in 90 seconds.",
  supportEmail: "support@volthosting.gg",
  appUrl: "http://localhost:3000",
  discordInvite: "https://discord.gg/volthosting",
};

export const PRICING_DEFAULTS: PricingSettings = {
  baseCents: 199,
  ramPerGbCents: 95,
  cpuPerCoreCents: 60,
  diskPerGbCents: 10,
  backupCents: 50,
  quarterlyDiscount: 10,
  yearlyDiscount: 20,
};

export const PTERODACTYL_DEFAULTS: PterodactylSettings = {
  enabled: false,
  panelUrl: "https://panel.volthosting.gg",
  apiKey: "",
  defaultNodeId: "",
  defaultNestId: "",
  defaultEggId: "",
  defaultDockerImage: "ghcr.io/pterodactyl/yolks:java_21",
  defaultStartup:
    "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}",
  defaultEnvironment:
    '{\n  "SERVER_JARFILE": "server.jar",\n  "MC_VERSION": "latest"\n}',
  defaultAllocationId: "",
};

export const SMTP_DEFAULTS: SmtpSettings = {
  enabled: false,
  host: "",
  port: 587,
  secure: false,
  user: "",
  pass: "",
  fromName: "Volt Hosting",
  fromEmail: "hello@volthosting.gg",
};

export const DISCORD_DEFAULTS: DiscordSettings = {
  enabled: false,
  username: "Volt Hosting",
  iconUrl: "",
  signupWebhook: "",
  purchaseWebhook: "",
  ticketWebhook: "",
};

export const PAYMENT_DEFAULTS: PaymentSettings = {
  enabled: true,
  currency: "USD",
  note: "All prices are billed in USD. Servers renew automatically unless cancelled.",
};

export const REGIONS = [
  { id: "fra", name: "Frankfurt", country: "DE", latency: 18 },
  { id: "lon", name: "London", country: "UK", latency: 24 },
  { id: "nyc", name: "New York", country: "US", latency: 31 },
  { id: "dal", name: "Dallas", country: "US", latency: 42 },
  { id: "lax", name: "Los Angeles", country: "US", latency: 58 },
  { id: "sgp", name: "Singapore", country: "SG", latency: 73 },
  { id: "syd", name: "Sydney", country: "AU", latency: 88 },
  { id: "gru", name: "São Paulo", country: "BR", latency: 96 },
] as const;

export const GAME_META: Record<
  string,
  {
    icon: string;
    headline: string;
    blurb: string;
    bullets: string[];
    gradient: string;
    startingAt: string;
    statLabel: string;
    statValue: string;
  }
> = {
  minecraft: {
    icon: "Boxes",
    headline: "Worlds that load before your friends do.",
    blurb:
      "Paper, Fabric, Forge and modpacks on fast NVMe storage. One-click installs, scheduled backups and a console that keeps up with you.",
    bullets: [
      "One-click Paper, Fabric & Forge",
      "Unlimited player slots",
      "Automatic rolling backups",
      "Java 8 through 21",
    ],
    gradient: "from-[#0b63ff] via-[#1bb7ff] to-[#7df0dd]",
    startingAt: "$3.99",
    statLabel: "worlds online",
    statValue: "4,820",
  },
  fivem: {
    icon: "Car",
    headline: "Build a city. Keep the streets full.",
    blurb:
      "Artifact updates, txAdmin and one-click resources, backed by the single-thread performance FiveM actually cares about.",
    bullets: [
      "txAdmin pre-installed",
      "Automatic artifact updates",
      "32-player-ready tuning",
      "One-click resource deploys",
    ],
    gradient: "from-[#062a66] via-[#0b63ff] to-[#18c8ff]",
    startingAt: "$11.99",
    statLabel: "cities deployed",
    statValue: "1,240",
  },
  rust: {
    icon: "Flame",
    headline: "High tickrate. Clean wipes.",
    blurb:
      "Oxide and uMod support, scheduled wipes and the CPU headroom to keep 200-player fights responsive.",
    bullets: [
      "Oxide / uMod ready",
      "Scheduled wipe automation",
      "High tickrate nodes",
      "Rust+ companion ready",
    ],
    gradient: "from-[#7a2410] via-[#e56b2f] to-[#ffc46b]",
    startingAt: "$13.99",
    statLabel: "wipe cycles run",
    statValue: "18,300",
  },
  samp: {
    icon: "Gamepad2",
    headline: "The classics deserve low ping.",
    blurb:
      "SA-MP and open.mp servers with fast restarts, DDoS filtering and a lean panel that stays out of the way.",
    bullets: [
      "SA-MP & open.mp support",
      "Instant restart",
      "DDoS-protected network",
      "Plugin upload via SFTP",
    ],
    gradient: "from-[#063c3c] via-[#0d9388] to-[#6df2d6]",
    startingAt: "$2.99",
    statLabel: "servers running",
    statValue: "960",
  },
  "discord-bots": {
    icon: "Bot",
    headline: "Your bot, always awake.",
    blurb:
      "Node, Python and Java runtimes with keep-alive monitoring, scheduled restarts and room to grow your guild.",
    bullets: [
      "Node, Python, Java & Go",
      "24/7 keep-alive",
      "Git deploys",
      "Environment variables built in",
    ],
    gradient: "from-[#183a78] via-[#3b6cff] to-[#9aa7ff]",
    startingAt: "$1.99",
    statLabel: "bots online",
    statValue: "6,410",
  },
  vps: {
    icon: "Server",
    headline: "Root access. No noisy neighbours.",
    blurb:
      "Fixed resources, NVMe storage and a choice of Linux images for the workloads that outgrow shared hosting.",
    bullets: [
      "Full root access",
      "Dedicated vCPU threads",
      "Snapshots & reinstalls",
      "10 Gbps network uplink",
    ],
    gradient: "from-[#0b2a4a] via-[#1476c9] to-[#66d9ff]",
    startingAt: "$9.99",
    statLabel: "instances live",
    statValue: "780",
  },
};

export const FAQS = [
  {
    q: "How fast is setup, really?",
    a: "Paid orders are provisioned automatically. In most cases your panel login and server details arrive by email within 90 seconds. If your chosen location is at capacity, we will place you on the next node and email you the exact ETA.",
  },
  {
    q: "Can I move my existing world or database?",
    a: "Yes. Upload your world through SFTP or the panel file manager, then point the startup jar at it. Support can migrate a world for you on any plan — open a ticket and attach the archive.",
  },
  {
    q: "Do you limit RAM, CPU or player slots?",
    a: "Each plan has fixed RAM, CPU and NVMe limits so nobody shares your resources. There are no player-slot limits; what your server can hold depends on your configuration and the workload.",
  },
  {
    q: "What is your refund policy?",
    a: "New game servers are covered by a 72-hour first-purchase guarantee. Open a billing ticket within that window and we will refund the first invoice, no interrogation.",
  },
  {
    q: "Can I upgrade later without losing data?",
    a: "Yes. Upgrades keep the same server and files. We adjust your panel limits and invoice the difference for the remainder of the billing term.",
  },
  {
    q: "Is DDoS protection included?",
    a: "Every plan sits behind our filtered network with game-aware rules. There is no separate DDoS add-on and no traffic cap on the protection layer.",
  },
];

export const NETWORK = [
  { city: "Frankfurt", code: "FRA", x: 50.4, y: 32, latency: "18 ms" },
  { city: "London", code: "LON", x: 46.4, y: 27, latency: "24 ms" },
  { city: "New York", code: "NYC", x: 27.4, y: 35, latency: "31 ms" },
  { city: "Dallas", code: "DAL", x: 20.6, y: 42, latency: "42 ms" },
  { city: "Los Angeles", code: "LAX", x: 13.8, y: 41, latency: "58 ms" },
  { city: "Singapore", code: "SGP", x: 77.4, y: 57, latency: "73 ms" },
  { city: "Sydney", code: "SYD", x: 87.8, y: 73, latency: "88 ms" },
  { city: "São Paulo", code: "GRU", x: 35.2, y: 70, latency: "96 ms" },
];

export const TESTIMONIALS = [
  {
    quote:
      "Moved a 40-player Minecraft network across on a Friday night. The only thing that broke was our old host's uptime graph.",
    name: "Riley K.",
    role: "Owner, Northbound SMP",
  },
  {
    quote:
      "The panel is the first one my moderators understood without a five-minute call. Backups alone paid for the upgrade.",
    name: "Sam O.",
    role: "Community lead, LS County RP",
  },
  {
    quote:
      "A ticket about a broken plugin got a real answer in eight minutes, at 2am. That is the whole review.",
    name: "Nadia F.",
    role: "Developer, Rusted North",
  },
];

export const SOCIAL_PROOF = [
  { value: "12.4k", label: "communities hosted" },
  { value: "8", label: "edge locations" },
  { value: "99.99%", label: "network uptime" },
  { value: "4.9/5", label: "support rating" },
];
