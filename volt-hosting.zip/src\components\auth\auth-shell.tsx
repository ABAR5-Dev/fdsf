import Link from "next/link";
import { ArrowLeft, Check, KeyRound, Mail, Server } from "lucide-react";
import { Brand } from "@/components/brand";
import { CopyrightYear } from "@/components/copyright-year";

const STEPS = [
  {
    icon: Server,
    title: "Order a server",
    body: "Pick a plan or build your specs. Payment reserves the node immediately.",
  },
  {
    icon: KeyRound,
    title: "We create the panel account",
    body: "Your Pterodactyl user and server are provisioned automatically.",
  },
  {
    icon: Mail,
    title: "Credentials land in your inbox",
    body: "The panel URL, username and password arrive by email, ready to use.",
  },
];

export function AuthShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative min-h-screen">
      <div className="container-x flex min-h-screen flex-col py-5">
        <header className="flex items-center justify-between">
          <Brand />
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-[0.78rem] font-medium text-mutedblue transition hover:text-ink"
          >
            <ArrowLeft className="size-3.5" />
            Back to site
          </Link>
        </header>

        <div className="grid flex-1 items-center gap-10 py-10 lg:grid-cols-[minmax(0,1fr)_420px] lg:gap-16">
          <section className="order-2 lg:order-1">
            <span className="chip chip-accent">
              <span className="live-dot size-1.5 rounded-full bg-[#20b878]" />
              Provisioning online
            </span>
            <h1 className="display mt-5 max-w-[15ch] text-[2.3rem] text-ink sm:text-[3rem]">
              Everything after checkout is automatic.
            </h1>
            <p className="lede mt-4 max-w-[48ch]">
              One account holds your servers, invoices and support tickets. No
              control-panel setup, no waiting on a manual activation.
            </p>

            <ol className="mt-7 max-w-md space-y-4">
              {STEPS.map((step, index) => {
                const Icon = step.icon;
                return (
                  <li key={step.title} className="flex gap-3">
                    <span className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-lg border border-white bg-white/70 text-[#0a63ff] shadow-sm">
                      <Icon className="size-4" />
                    </span>
                    <div>
                      <p className="text-[0.84rem] font-semibold text-ink">
                        {step.title}
                      </p>
                      <p className="mt-0.5 text-[0.78rem] leading-relaxed text-ink-soft/80">
                        {step.body}
                      </p>
                    </div>
                    <span className="mono ml-auto pt-1 text-[0.6rem] text-[#9ab7cc]">
                      0{index + 1}
                    </span>
                  </li>
                );
              })}
            </ol>

            <div className="console noise mt-8 hidden max-w-md overflow-hidden rounded-xl p-3 sm:block">
              <div className="space-y-1">
                {[
                  ["$ volt provision --order VLT-8241", "text-[#8fb9d6]"],
                  ["✓ panel account created", "text-[#7fdcc8]"],
                  ["✓ server installed · fra-03", "text-[#7fdcc8]"],
                  ["→ credentials sent to your inbox", "text-[#a9d8ff]"],
                ].map(([line, tone]) => (
                  <p
                    key={line}
                    className={`mono text-[0.64rem] leading-relaxed ${tone}`}
                  >
                    {line}
                  </p>
                ))}
              </div>
            </div>
          </section>

          <section className="order-1 lg:order-2">
            <div className="glass rounded-3xl p-6 sm:p-7">{children}</div>
            <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-[0.68rem] text-mutedblue">
              <Check className="size-3 text-[#0a8f5b]" />
              Passwords are hashed. Sessions are HttpOnly.
            </p>
          </section>
        </div>

        <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-white/70 pt-4 text-[0.68rem] text-mutedblue">
          <span>© <CopyrightYear /> Volt Hosting</span>
          <div className="flex gap-4">
            <Link href="/terms" className="hover:text-ink">
              Terms
            </Link>
            <Link href="/privacy" className="hover:text-ink">
              Privacy
            </Link>
            <Link href="/support" className="hover:text-ink">
              Support
            </Link>
          </div>
        </footer>
      </div>
    </div>
  );
}
