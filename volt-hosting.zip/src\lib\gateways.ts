import { decryptSecret } from "./crypto";

export function parseGatewayConfig(raw: string): Record<string, unknown> {
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      return parsed as Record<string, unknown>;
    }
  } catch {
    // fall through to an empty config
  }
  return {};
}

/**
 * Reads a Stripe secret stored by the admin panel. New values are encrypted
 * (`secretKeyEnc`); plaintext keys from earlier builds are still accepted.
 */
export function gatewaySecret(
  config: Record<string, unknown>,
  key: "secretKey" | "webhookSecret",
): string {
  const encrypted = config[`${key}Enc`];
  if (typeof encrypted === "string" && encrypted) {
    const value = decryptSecret(encrypted);
    if (value) return value.trim();
  }
  const plain = config[key];
  return typeof plain === "string" ? plain.trim() : "";
}
