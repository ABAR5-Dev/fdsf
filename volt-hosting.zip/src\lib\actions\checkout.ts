"use server";

import { randomUUID } from "node:crypto";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { db } from "../db";
import { getCurrentUser } from "../auth";
import {
  getCategoryBySlug,
  getGatewayById,
  getOrderById,
  getPayments,
  getProductBySlug,
  getPricing,
  getSite,
  getUserById,
} from "../queries";
import { calculateCustomCents, specsFromProduct, termPrice } from "../format";
import { gatewaySecret } from "../gateways";
import { evaluatePromo } from "../promo";
import { sendPaymentPendingEmail } from "../mail";
import { notifyPendingOrder } from "../discord";
import { REGIONS } from "../defaults";
import type { ActionState, Specs } from "../types";

function parseJson<T>(value: string | null | undefined, fallback: T): T {
  if (!value) return fallback;
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, Math.round(value)));
}

export async function createOrderAction(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await getCurrentUser();
  if (!user) {
    return { error: "Your session expired. Sign in and try again." };
  }

  const payments = getPayments();
  if (!payments.enabled) {
    return { error: "Payments are temporarily paused. Please try again shortly." };
  }

  const kind = String(formData.get("kind") ?? "product");
  const monthsRaw = Number(formData.get("billing_months") ?? 1);
  const months = [1, 3, 12].includes(monthsRaw) ? monthsRaw : 1;
  const gatewayId = String(formData.get("gateway_id") ?? "");
  const serverName = String(formData.get("server_name") ?? "").trim();
  const region = String(formData.get("region") ?? "Frankfurt");
  const terms = formData.get("terms");

  if (terms !== "on") {
    return { error: "Accept the terms of service to continue." };
  }
  if (serverName.length < 2 || serverName.length > 48) {
    return { error: "Give your server a name between 2 and 48 characters." };
  }
  if (!REGIONS.some((item) => item.name === region)) {
    return { error: "Choose a valid location." };
  }

  const gateway = getGatewayById(gatewayId);
  if (!gateway || !gateway.enabled) {
    return { error: "Choose an available payment method." };
  }

  const pricing = getPricing();
  let productId: string | null = null;
  let categoryId: string | null = null;
  let itemName = "";
  let monthlyCents = 0;
  let specs: Specs;

  if (kind === "custom") {
    const category = getCategoryBySlug(
      String(formData.get("category_slug") ?? ""),
    );
    if (!category || !category.active) {
      return { error: "That game is not available right now." };
    }
    const ramGb = clamp(Number(formData.get("ram_gb") ?? 4), 1, 64);
    const cpuCores = clamp(Number(formData.get("cpu_cores") ?? 2), 1, 16);
    const diskGb = clamp(Number(formData.get("disk_gb") ?? 20), 5, 500);
    const backups = clamp(Number(formData.get("backups") ?? 1), 0, 10);
    specs = {
      ramMb: ramGb * 1024,
      cpuPct: cpuCores * 100,
      diskMb: diskGb * 1024,
      backups,
      databases: Math.max(1, Math.min(5, Math.ceil(ramGb / 4))),
      allocations: Math.max(1, Math.min(5, Math.ceil(ramGb / 8))),
      players: 0,
    };
    monthlyCents = calculateCustomCents(specs, pricing);
    categoryId = category.id;
    itemName = `${category.name} custom build`;
  } else {
    const product = getProductBySlug(String(formData.get("product_slug") ?? ""));
    if (!product || !product.active) {
      return { error: "That plan is no longer available." };
    }
    productId = product.id;
    categoryId = product.category_id;
    monthlyCents = product.price_cents;
    specs = specsFromProduct(product);
    itemName = `${product.name} — ${product.category_name}`;
  }

  const subtotal = termPrice(monthlyCents, months, pricing);

  const promoRaw = String(formData.get("promo_code") ?? "").trim();
  let promoCode: string | null = null;
  let discountCents = 0;
  if (promoRaw) {
    const promo = evaluatePromo(promoRaw, subtotal);
    if (!promo.ok) return { error: promo.error };
    promoCode = promo.promo.code;
    discountCents = promo.discountCents;
  }
  const amount = Math.max(0, subtotal - discountCents);

  const orderId = randomUUID();
  const now = new Date().toISOString();

  db.prepare(
    `INSERT INTO orders
     (id, user_id, product_id, category_id, item_name, server_name, region, kind, specs,
      amount_cents, billing_months, status, gateway_id, promo_code, discount_cents, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?)`,
  ).run(
    orderId,
    user.id,
    productId,
    categoryId,
    itemName,
    serverName,
    region,
    kind === "custom" ? "custom" : "product",
    JSON.stringify(specs),
    amount,
    months,
    gateway.id,
    promoCode,
    discountCents,
    now,
  );

  revalidatePath("/dashboard");
  revalidatePath("/dashboard/billing");
  revalidatePath("/admin/orders");

  const config = parseJson<Record<string, unknown>>(gateway.config, {});

  if (gateway.type === "manual" || gateway.type === "discord") {
    const fallback =
      gateway.type === "discord"
        ? "Open a ticket in our Discord server and send your order number. Our billing team will reply with payment details."
        : "A member of our billing team will email payment instructions.";
    const instructions =
      typeof config.instructions === "string" && config.instructions.trim()
        ? config.instructions
        : fallback;

    const order = getOrderById(orderId);
    const customer = getUserById(user.id);
    if (order && customer) {
      await sendPaymentPendingEmail({ user: customer, order, instructions });
    }
    await notifyPendingOrder({
      orderId,
      customer: user.name,
      email: user.email,
      item: itemName,
      amount: `$${(amount / 100).toFixed(2)}`,
      method: gateway.name,
      instructions,
    }).catch(() => undefined);

    redirect(`/checkout/success?order=${orderId}`);
  }

  if (gateway.type === "stripe") {
    const secretKey = gatewaySecret(config, "secretKey");
    if (!secretKey) {
      db.prepare("UPDATE orders SET status = 'cancelled' WHERE id = ?").run(
        orderId,
      );
      return {
        error:
          "Card payments are not configured yet. Choose another payment method or contact support.",
      };
    }

    const site = getSite();
    const body = new URLSearchParams();
    body.set("mode", "payment");
    body.set("success_url", `${site.appUrl}/checkout/success?order=${orderId}`);
    body.set(
      "cancel_url",
      `${site.appUrl}/checkout?product=${encodeURIComponent(
        String(formData.get("product_slug") ?? ""),
      )}&cancelled=1`,
    );
    body.set("client_reference_id", orderId);
    body.set("customer_email", user.email);
    body.set("metadata[order_id]", orderId);
    body.set("line_items[0][quantity]", "1");
    body.set("line_items[0][price_data][currency]", payments.currency.toLowerCase());
    body.set("line_items[0][price_data][unit_amount]", String(amount));
    body.set("line_items[0][price_data][product_data][name]", itemName);
    body.set(
      "line_items[0][price_data][product_data][description]",
      `${months} month${months > 1 ? "s" : ""} · ${serverName}`,
    );

    let checkoutUrl = "";
    try {
      const response = await fetch("https://api.stripe.com/v1/checkout/sessions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${secretKey}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body,
        cache: "no-store",
      });
      const session = (await response.json()) as {
        id?: string;
        url?: string;
        error?: { message?: string };
      };
      if (!response.ok || !session.url) {
        throw new Error(
          session.error?.message || "Stripe could not start the checkout.",
        );
      }
      db.prepare("UPDATE orders SET gateway_ref = ? WHERE id = ?").run(
        session.id ?? null,
        orderId,
      );
      checkoutUrl = session.url;
    } catch (error) {
      db.prepare("UPDATE orders SET status = 'cancelled' WHERE id = ?").run(
        orderId,
      );
      return {
        error:
          error instanceof Error
            ? error.message
            : "Card checkout could not be started.",
      };
    }
    redirect(checkoutUrl);
  }

  return { error: "That payment method is not available." };
}
