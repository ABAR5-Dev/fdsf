import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowLeft, Clock3, MessageSquareText } from "lucide-react";
import { NewTicketForm } from "@/components/app/ticket-forms";
import { getCurrentUser } from "@/lib/auth";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "New ticket" };

type PageProps = { searchParams: Promise<{ server?: string }> };

export default async function NewTicketPage({ searchParams }: PageProps) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/support/new");

  const { server } = await searchParams;
  const serverName = server ? server.slice(0, 70) : undefined;

  return (
    <div className="mx-auto max-w-[960px]">
      <Link
        href="/dashboard/support"
        className="inline-flex items-center gap-1.5 text-[0.74rem] font-medium text-mutedblue transition hover:text-ink"
      >
        <ArrowLeft className="size-3.5" />
        Support
      </Link>

      <div className="mt-3">
        <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">Open a ticket</h1>
        <p className="mt-1.5 max-w-[56ch] text-[0.84rem] leading-relaxed text-ink-soft/80">
          Write it once, clearly, and we can usually fix it in the first reply.
          Everything stays attached to your account.
        </p>
      </div>

      <div className="mt-5 grid items-start gap-4 lg:grid-cols-[1.35fr_0.65fr]">
        <section className="glass rounded-2xl p-5">
          <NewTicketForm serverName={serverName} />
        </section>

        <aside className="space-y-3">
          <div className="glass-quiet rounded-2xl p-4">
            <h2 className="flex items-center gap-1.5 text-[0.84rem] font-semibold text-ink">
              <MessageSquareText className="size-4 text-[#0a63ff]" />
              What helps us help you
            </h2>
            <ul className="mt-2.5 space-y-2 text-[0.76rem] leading-relaxed text-ink-soft/85">
              <li>Server name or panel username, not just your email.</li>
              <li>The exact error text from the console, if there is one.</li>
              <li>When it started — after an update, restart or plugin change.</li>
              <li>What you already tried, so we don’t repeat it.</li>
            </ul>
          </div>

          <div className="glass-quiet rounded-2xl p-4">
            <h2 className="flex items-center gap-1.5 text-[0.84rem] font-semibold text-ink">
              <Clock3 className="size-4 text-[#0a63ff]" />
              Response times
            </h2>
            <dl className="mt-2.5 space-y-1.5 text-[0.76rem]">
              <div className="flex justify-between gap-3">
                <dt className="text-mutedblue">Server down</dt>
                <dd className="text-ink">Under 15 min</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-mutedblue">General</dt>
                <dd className="text-ink">Under 2 hours</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-mutedblue">Billing</dt>
                <dd className="text-ink">Same day</dd>
              </div>
            </dl>
          </div>

          <p className="px-1 text-[0.7rem] leading-relaxed text-mutedblue">
            Replies also go to {user.email}. Check spam once if a ticket looks
            quiet.
          </p>
        </aside>
      </div>
    </div>
  );
}
