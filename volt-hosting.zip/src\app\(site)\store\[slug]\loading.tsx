export default function StoreCategoryLoading() {
  return (
    <section className="relative overflow-hidden pb-10 pt-8 sm:pt-10">
      <div className="container-x">
        <div className="h-3 w-40 animate-pulse rounded-full bg-white/60" />
        <div className="mt-6 grid items-center gap-8 lg:grid-cols-[1.08fr_0.92fr]">
          <div>
            <div className="h-6 w-36 animate-pulse rounded-full bg-white/70" />
            <div className="mt-4 h-11 w-4/5 animate-pulse rounded-xl bg-white/70" />
            <div className="mt-3 h-11 w-3/5 animate-pulse rounded-xl bg-white/60" />
            <div className="mt-5 h-4 w-full max-w-xl animate-pulse rounded-full bg-white/55" />
            <div className="mt-2 h-4 w-4/5 max-w-md animate-pulse rounded-full bg-white/45" />
            <div className="mt-7 flex gap-3">
              <div className="h-10 w-32 animate-pulse rounded-xl bg-white/70" />
              <div className="h-10 w-28 animate-pulse rounded-xl bg-white/55" />
            </div>
          </div>
          <div className="glass h-72 rounded-3xl" aria-hidden="true" />
        </div>
      </div>
    </section>
  );
}
