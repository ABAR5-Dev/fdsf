"use client";

import Link from "next/link";
import { useActionState, useState } from "react";
import { CheckCircle2, Loader2, Save } from "lucide-react";
import {
  saveGatewayAction,
  savePaymentsAction,
} from "@/lib/actions/admin";
import type { ActionState, GatewayRow, GatewayType, PaymentSettings } from "@/lib/types";

function Feedback({ state, success }: { state: ActionState; success?: string }) {
  if (state?.error) {
    return (
      <p
        role="alert"
        className="rounded-lg border border-[#f3c6c6] bg-[#fff5f5] px-3 py-2 text-[0.78rem] text-[#a13b3b]"
      >
        {state.error}
      </p>
    );
  }
  if (state?.success) {
    return (
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-[#c4e8d5] bg-[#f2fbf6] px-3 py-2 text-[0.78rem] text-[#0a7a4e]">
        <span className="flex items-center gap-1.5">
          <CheckCircle2 className="size-3.5" />
          {state.success}
        </span>
        {success && (
          <Link href={success} className="font-semibold hover:underline">
            Back to payments
          </Link>
        )}
      </div>
    );
  }
  return null;
}

export function PaymentsSettingsForm({ settings }: { settings: PaymentSettings }) {
  const [state, action, pending] = useActionState(savePaymentsAction, null);

  return (
    <form action={action} className="space-y-3">
      <Feedback state={state} />

      <label className="flex items-center justify-between gap-3 rounded-xl border border-white/90 bg-white/55 px-3 py-2.5">
        <span>
          <span className="block text-[0.8rem] font-semibold text-ink">
            Checkout is open
          </span>
          <span className="block text-[0.68rem] text-mutedblue">
            Turning this off hides checkout and returns “order paused” on every
            plan.
          </span>
        </span>
        <input
          type="checkbox"
          name="enabled"
          defaultChecked={settings.enabled}
          className="size-4 shrink-0 rounded border-[#c3d6e6] accent-[#0a63ff]"
        />
      </label>

      <div className="grid gap-3 sm:grid-cols-[120px_1fr]">
        <div>
          <label htmlFor="currency" className="field-label">
            Currency
          </label>
          <input
            id="currency"
            name="currency"
            maxLength={3}
            defaultValue={settings.currency}
            className="input mono uppercase"
          />
        </div>
        <div>
          <label htmlFor="note" className="field-label">
            Checkout note
          </label>
          <input
            id="note"
            name="note"
            maxLength={200}
            defaultValue={settings.note}
            placeholder="All prices in USD. Taxes added at checkout where required."
            className="input"
          />
        </div>
      </div>

      <button type="submit" disabled={pending} className="btn btn-primary btn-sm">
        {pending ? (
          <>
            <Loader2 className="size-3.5 animate-spin" />
            Saving
          </>
        ) : (
          <>
            <Save className="size-3.5" />
            Save checkout settings
          </>
        )}
      </button>
    </form>
  );
}

const TYPE_COPY: Record<GatewayType, string> = {
  discord:
    "For UPI, Google Pay and other transfers. The customer opens a Discord ticket with their order number, you confirm the transfer, then mark the order paid.",
  stripe: "Hosted Stripe Checkout. Needs a publishable key, secret key and webhook secret.",
  manual: "Shows instructions at checkout, then you mark the order paid from the order page.",
};

export function GatewayForm({
  gateway,
  initial,
}: {
  gateway?: GatewayRow;
  initial?: {
    instructions?: string;
    discordUrl?: string;
    publishableKey?: string;
    hasSecret?: boolean;
  };
}) {
  const [state, action, pending] = useActionState(saveGatewayAction, null);
  const [type, setType] = useState<GatewayType>(gateway?.type ?? "discord");

  return (
    <form action={action} className="space-y-4">
      {gateway && <input type="hidden" name="id" value={gateway.id} />}
      <Feedback state={state} success="/admin/payments" />

      <section className="glass rounded-2xl p-4 sm:p-5">
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label htmlFor="name" className="field-label">
              Display name
            </label>
            <input
              id="name"
              name="name"
              required
              minLength={2}
              maxLength={60}
              defaultValue={gateway?.name ?? ""}
              placeholder="Card via Stripe"
              className="input"
            />
          </div>
          <div>
            <label htmlFor="type" className="field-label">
              Type
            </label>
            <select
              id="type"
              name="type"
              value={type}
              onChange={(event) => setType(event.target.value as GatewayType)}
              className="select"
            >
              <option value="discord">UPI / GPay via Discord ticket</option>
              <option value="manual">Manual / bank transfer</option>
              <option value="stripe">Stripe Checkout</option>
            </select>
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="description" className="field-label">
              Checkout description
            </label>
            <input
              id="description"
              name="description"
              maxLength={160}
              defaultValue={gateway?.description ?? ""}
              placeholder="Visa, Mastercard, Amex. Instant activation."
              className="input"
            />
            <p className="field-hint">{TYPE_COPY[type]}</p>
          </div>
          <div>
            <label htmlFor="sort_order" className="field-label">
              Sort order
            </label>
            <input
              id="sort_order"
              name="sort_order"
              type="number"
              min={0}
              step={1}
              defaultValue={gateway?.sort_order ?? 0}
              className="input"
            />
          </div>
          <label className="flex items-end gap-2 pb-1 text-[0.78rem] text-ink-soft">
            <input
              type="checkbox"
              name="enabled"
              defaultChecked={gateway ? gateway.enabled === 1 : true}
              className="size-4 rounded border-[#c3d6e6] accent-[#0a63ff]"
            />
            Offer this at checkout
          </label>
        </div>
      </section>

      {(type === "manual" || type === "discord") && (
        <section className="glass rounded-2xl p-4 sm:p-5">
          <h2 className="text-[0.9rem] font-semibold text-ink">
            {type === "discord" ? "Discord ticket instructions" : "Payment instructions"}
          </h2>
          <p className="mt-0.5 text-[0.72rem] text-mutedblue">
            Shown on the order confirmation page and emailed to the customer
            right after they place the order.
          </p>

          {type === "discord" && (
            <div className="mt-3">
              <label htmlFor="discord_url" className="field-label">
                Discord invite link
              </label>
              <input
                id="discord_url"
                name="discord_url"
                type="url"
                defaultValue={initial?.discordUrl ?? ""}
                placeholder="https://discord.gg/your-server"
                className="input mono text-[0.76rem]"
              />
              <p className="field-hint">
                Leave blank to use the invite from Site identity instead.
              </p>
            </div>
          )}

          <textarea
            name="instructions"
            rows={5}
            defaultValue={initial?.instructions ?? ""}
            placeholder={
              type === "discord"
                ? "Open a ticket in our Discord and send your order number. We reply with the UPI ID or QR code."
                : "Bank: ...\nAccount: ...\nReference: your order id"
            }
            className="textarea mt-2"
          />
        </section>
      )}

      {type === "stripe" && (
        <section className="glass rounded-2xl p-4 sm:p-5">
          <h2 className="text-[0.9rem] font-semibold text-ink">Stripe keys</h2>
          <p className="mt-0.5 text-[0.72rem] text-mutedblue">
            Secrets are encrypted before they reach the database and never leave
            the server again.
          </p>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label htmlFor="publishable_key" className="field-label">
                Publishable key
              </label>
              <input
                id="publishable_key"
                name="publishable_key"
                defaultValue={initial?.publishableKey ?? ""}
                placeholder="pk_live_..."
                className="input mono text-[0.76rem]"
              />
            </div>
            <div>
              <label htmlFor="secret_key" className="field-label">
                Secret key
              </label>
              <input
                id="secret_key"
                name="secret_key"
                type="password"
                autoComplete="off"
                placeholder={initial?.hasSecret ? "•••••••• saved — leave blank" : "sk_live_..."}
                className="input mono text-[0.76rem]"
              />
            </div>
            <div>
              <label htmlFor="webhook_secret" className="field-label">
                Webhook secret
              </label>
              <input
                id="webhook_secret"
                name="webhook_secret"
                type="password"
                autoComplete="off"
                placeholder={initial?.hasSecret ? "•••••••• saved — leave blank" : "whsec_..."}
                className="input mono text-[0.76rem]"
              />
            </div>
          </div>
          <p className="field-hint mt-2">
            Webhook endpoint: <span className="mono">/api/webhooks/stripe</span>
          </p>
        </section>
      )}

      <div className="flex flex-wrap gap-2">
        <button type="submit" disabled={pending} className="btn btn-primary">
          {pending ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Saving
            </>
          ) : (
            <>
              <Save className="size-4" />
              {gateway ? "Save method" : "Add payment method"}
            </>
          )}
        </button>
        <Link href="/admin/payments" className="btn btn-secondary">
          Cancel
        </Link>
      </div>
    </form>
  );
}
