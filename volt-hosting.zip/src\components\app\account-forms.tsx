"use client";

import { useActionState, useRef, useState } from "react";
import { AtSign, CheckCircle2, ImagePlus, Loader2, Save } from "lucide-react";
import {
  changePasswordAction,
  updateProfileAction,
} from "@/lib/actions/auth";
import type { ActionState } from "@/lib/types";

function initials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}

// Phone cameras hand over 3–8 MB photos, which the 2 MB upload cap would
// reject. Downscale anything large in the browser first; the server cap stays
// as the guard for requests that skip this path.
const AVATAR_MAX_EDGE = 512;

async function shrinkAvatar(file: File): Promise<File> {
  if (file.type === "image/gif" || file.size <= 400 * 1024) return file;
  try {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(
      1,
      AVATAR_MAX_EDGE / Math.max(bitmap.width, bitmap.height),
    );
    const width = Math.max(1, Math.round(bitmap.width * scale));
    const height = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext("2d");
    if (!context) return file;
    context.drawImage(bitmap, 0, 0, width, height);
    bitmap.close();

    const blob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob(resolve, "image/webp", 0.86),
    );
    if (!blob) return file;
    const name = `${file.name.replace(/\.[^.]+$/, "") || "avatar"}.webp`;
    return new File([blob], name, { type: "image/webp" });
  } catch {
    // Older browsers without createImageBitmap keep the original file.
    return file;
  }
}

function Feedback({ state }: { state: ActionState }) {
  if (!state) return null;
  if (state.error) {
    return (
      <p
        role="alert"
        className="rounded-lg border border-[#f3c6c6] bg-[#fff5f5] px-3 py-2 text-[0.76rem] text-[#a13b3b]"
      >
        {state.error}
      </p>
    );
  }
  if (state.success) {
    return (
      <p className="flex items-center gap-1.5 rounded-lg border border-[#c4e8d5] bg-[#f2fbf6] px-3 py-2 text-[0.76rem] text-[#0a7a4e]">
        <CheckCircle2 className="size-3.5" />
        {state.success}
      </p>
    );
  }
  return null;
}

export function ProfileForm({
  name,
  email,
  avatarUrl,
  bio,
  discordHandle,
}: {
  name: string;
  email: string;
  avatarUrl: string;
  bio: string;
  discordHandle: string;
}) {
  const [state, action, pending] = useActionState(updateProfileAction, null);
  const [preview, setPreview] = useState(avatarUrl);
  const [removePhoto, setRemovePhoto] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  const shownPhoto = removePhoto ? "" : preview;

  function toggleRemove(checked: boolean) {
    setRemovePhoto(checked);
    // Choosing "Remove" wins over a freshly picked file, so clear that pick.
    if (checked && fileInput.current) fileInput.current.value = "";
    setPreview(avatarUrl);
  }

  return (
    <form action={action} className="space-y-4">
      <Feedback state={state} />

      <div className="flex flex-wrap items-center gap-4 rounded-xl border border-white/90 bg-white/45 p-3">
        <span className="grid size-16 shrink-0 place-items-center overflow-hidden rounded-2xl border border-white bg-gradient-to-br from-[#e6f2ff] to-white text-[1.05rem] font-semibold text-[#0a63ff]">
          {shownPhoto ? (
            // Local upload or an admin-set URL; next/image would not help for
            // a per-user file under /public.
            // eslint-disable-next-line @next/next/no-img-element
            <img src={shownPhoto} alt="" className="size-16 object-cover" />
          ) : (
            initials(name) || "VH"
          )}
        </span>
        <div className="min-w-0 flex-1">
          <label htmlFor="avatar" className="field-label">
            Profile photo
          </label>
          <input
            ref={fileInput}
            id="avatar"
            name="avatar"
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif"
            onChange={async (event) => {
              const input = event.currentTarget;
              const picked = input.files?.[0];
              if (!picked) return;
              setPreview(URL.createObjectURL(picked));
              setRemovePhoto(false);

              // Submit the downscaled copy, not the original camera file.
              const file = await shrinkAvatar(picked);
              if (file === picked) return;
              const transfer = new DataTransfer();
              transfer.items.add(file);
              input.files = transfer.files;
            }}
            className="mt-1 block w-full cursor-pointer text-[0.74rem] text-mutedblue file:mr-2 file:cursor-pointer file:rounded-lg file:border-0 file:bg-[#e6f2ff] file:px-2.5 file:py-1.5 file:text-[0.72rem] file:font-medium file:text-[#0a63ff] hover:file:bg-[#d8ebff]"
          />
          <p className="field-hint flex items-center gap-1">
            <ImagePlus className="size-3" />
            PNG, JPG, WebP or GIF. Large photos are resized before upload.
            Shown in your header and on tickets.
          </p>
        </div>
        {avatarUrl && !removePhoto && (
          <label className="flex shrink-0 cursor-pointer items-center gap-1.5 text-[0.7rem] text-mutedblue">
            <input
              type="checkbox"
              name="remove_avatar"
              checked={removePhoto}
              onChange={(event) => toggleRemove(event.target.checked)}
              className="accent-[#0a63ff]"
            />
            Remove
          </label>
        )}
        {removePhoto && (
          <label className="flex shrink-0 cursor-pointer items-center gap-1.5 text-[0.7rem] text-[#a13b3b]">
            <input
              type="checkbox"
              name="remove_avatar"
              checked={removePhoto}
              onChange={(event) => toggleRemove(event.target.checked)}
              className="accent-[#a13b3b]"
            />
            Removing photo
          </label>
        )}
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className="field-label">
            Full name
          </label>
          <input
            id="name"
            name="name"
            defaultValue={name}
            required
            minLength={2}
            autoComplete="name"
            className="input"
          />
        </div>
        <div>
          <label htmlFor="email" className="field-label">
            Email
          </label>
          <input
            id="email"
            name="email"
            type="email"
            defaultValue={email}
            required
            autoComplete="email"
            className="input"
          />
        </div>
      </div>
      <p className="field-hint">
        Invoices and server credentials are sent to this address.
      </p>

      <div>
        <label htmlFor="bio" className="field-label">
          Short bio
        </label>
        <textarea
          id="bio"
          name="bio"
          rows={3}
          maxLength={240}
          defaultValue={bio}
          placeholder="What you run, who you play with, anything support should know."
          className="textarea"
        />
        <p className="field-hint">Up to 240 characters. Only your own team sees it.</p>
      </div>

      <div>
        <label htmlFor="discord_handle" className="field-label">
          Discord username
        </label>
        <div className="relative">
          <AtSign className="pointer-events-none absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-[#7fa5c2]" />
          <input
            id="discord_handle"
            name="discord_handle"
            defaultValue={discordHandle}
            maxLength={32}
            autoComplete="off"
            spellCheck={false}
            placeholder="yourname"
            className="input pl-8"
          />
        </div>
        <p className="field-hint">
          Optional. Makes it faster to match you to a ticket or an order in Discord.
        </p>
      </div>

      <button type="submit" disabled={pending} className="btn btn-primary btn-sm">
        {pending ? (
          <>
            <Loader2 className="size-3.5 animate-spin" />
            Saving
          </>
        ) : (
          <>
            <Save className="size-3.5" />
            Save profile
          </>
        )}
      </button>
    </form>
  );
}

export function PasswordForm() {
  const [state, action, pending] = useActionState(changePasswordAction, null);

  return (
    <form action={action} className="space-y-3">
      <Feedback state={state} />
      <div>
        <label htmlFor="current" className="field-label">
          Current password
        </label>
        <input
          id="current"
          name="current"
          type="password"
          required
          autoComplete="current-password"
          className="input"
        />
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label htmlFor="password" className="field-label">
            New password
          </label>
          <input
            id="password"
            name="password"
            type="password"
            required
            minLength={8}
            autoComplete="new-password"
            className="input"
          />
        </div>
        <div>
          <label htmlFor="confirm" className="field-label">
            Repeat new password
          </label>
          <input
            id="confirm"
            name="confirm"
            type="password"
            required
            minLength={8}
            autoComplete="new-password"
            className="input"
          />
        </div>
      </div>
      <p className="field-hint">
        Eight characters or more, with at least one letter and one number.
      </p>
      <button type="submit" disabled={pending} className="btn btn-secondary btn-sm">
        {pending ? (
          <>
            <Loader2 className="size-3.5 animate-spin" />
            Updating
          </>
        ) : (
          "Update password"
        )}
      </button>
    </form>
  );
}
