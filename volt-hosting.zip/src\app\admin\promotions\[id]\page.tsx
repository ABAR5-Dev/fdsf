import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, TicketPercent } from "lucide-react";
import { PromoForm } from "@/components/app/promo-form";
import { StatusPill } from "@/components/status-pill";
import { dateLabel, money } from "@/lib/format";
import { getPromoCodeById } from "@/lib/queries";

type PageProps = { params: Promise<{ id: string }> };

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const promo = getPromoCodeById(id);
  return { title: promo ? `Promo · ${promo.code}` : "Promo code" };
}

export default async function EditPromoPage({ params }: PageProps) {
  const { id } = await params;
  await requireAdmin(`/admin/promotions/${id}`);
  const promo = getPromoCodeById(id);
  if (!promo) notFound();

  return (
    <div className="mx-auto max-w-[860px]">
      <Link
        href="/admin/promotions"
        className="inline-flex items-center gap-1.5 text-[0.74rem] font-medium text-mutedblue transition hover:text-ink"
      >
        <ArrowLeft className="size-3.5" />
        Promo codes
      </Link>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">
          {promo.code}
        </h1>
        <StatusPill
          label={promo.active === 1 ? "Available" : "Paused"}
          tone={promo.active === 1 ? "mint" : "slate"}
          dot
        />
      </div>
      <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
        {promo.kind === "percent"
          ? `${promo.value}% off every order`
          : `${money(promo.value)} off every order`}
        {promo.min_cents > 0 ? ` over ${money(promo.min_cents)}` : ""}.
      </p>

      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        {[
          {
            label: "Redeemed",
            value:
              promo.max_uses > 0
                ? `${promo.used_count} of ${promo.max_uses}`
                : `${promo.used_count}`,
          },
          { label: "Created", value: dateLabel(promo.created_at) },
          {
            label: "Expires",
            value: promo.expires_at ? dateLabel(promo.expires_at) : "Never",
          },
        ].map((stat) => (
          <div
            key={stat.label}
            className="rounded-xl border border-white/90 bg-white/55 px-3 py-2.5"
          >
            <p className="text-[0.64rem] text-mutedblue">{stat.label}</p>
            <p className="mono mt-0.5 text-[0.82rem] font-semibold text-ink">
              {stat.value}
            </p>
          </div>
        ))}
      </div>

      <div className="glass mt-4 rounded-2xl p-4 sm:p-5">
        <h2 className="mb-3 flex items-center gap-1.5 text-[0.9rem] font-semibold text-ink">
          <TicketPercent className="size-4 text-[#0a63ff]" />
          Edit code
        </h2>
        <PromoForm promo={promo} />
      </div>
    </div>
  );
}
