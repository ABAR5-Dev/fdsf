import { cache } from "react";
import { cookies } from "next/headers";
import { connection } from "next/server";
import { redirect } from "next/navigation";
import { randomUUID } from "node:crypto";
import { db } from "./db";
import { newSessionToken, sha256 } from "./crypto";
import type { SessionUser, UserRow } from "./types";

export const SESSION_COOKIE = "volt_session";
const SESSION_DAYS = 30;

function toSessionUser(user: UserRow): SessionUser {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    panelUsername: user.panel_username,
    avatarUrl: user.avatar_url ?? "",
    bio: user.bio ?? "",
    discordHandle: user.discord_handle ?? "",
    createdAt: user.created_at,
  };
}

export async function createSession(userId: string) {
  const token = newSessionToken();
  const now = new Date();
  const expires = new Date(now.getTime() + SESSION_DAYS * 86_400_000);

  db.prepare(
    "INSERT INTO sessions (id, user_id, token_hash, expires_at, created_at) VALUES (?, ?, ?, ?, ?)",
  ).run(
    randomUUID(),
    userId,
    sha256(token),
    expires.toISOString(),
    now.toISOString(),
  );

  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires,
    maxAge: SESSION_DAYS * 86_400,
  });

  return token;
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) {
    db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(sha256(token));
  }
  jar.delete(SESSION_COOKIE);
}

export const getCurrentUser = cache(async (): Promise<SessionUser | null> => {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;

  // The session lookup is a synchronous node:sqlite query and its expiry check
  // reads the clock, both of which Cache Components would otherwise evaluate
  // while prerendering a static shell. Defer the whole check to request time.
  await connection();

  const row = db
    .prepare(
      `SELECT u.*, s.expires_at AS session_expires
       FROM sessions s JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = ?`,
    )
    .get(sha256(token)) as (UserRow & { session_expires: string }) | undefined;

  if (!row) return null;
  if (new Date(row.session_expires).getTime() < Date.now()) {
    db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(sha256(token));
    return null;
  }

  return toSessionUser(row);
});

export async function requireUser(nextPath?: string): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) {
    const next = nextPath ? `?next=${encodeURIComponent(nextPath)}` : "";
    redirect(`/login${next}`);
  }
  return user;
}

export async function requireAdmin(nextPath = "/admin"): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) {
    redirect(`/login?next=${encodeURIComponent(nextPath)}`);
  }
  if (user.role !== "admin") {
    redirect("/dashboard");
  }
  return user;
}

export function dashboardPathFor(user: SessionUser) {
  return user.role === "admin" ? "/admin" : "/dashboard";
}
