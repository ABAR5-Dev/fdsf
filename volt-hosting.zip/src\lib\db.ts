import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { randomUUID } from "node:crypto";
import { hashPassword } from "./crypto";
import {
  DISCORD_DEFAULTS,
  PAYMENT_DEFAULTS,
  PRICING_DEFAULTS,
  PTERODACTYL_DEFAULTS,
  SITE_DEFAULTS,
  SMTP_DEFAULTS,
} from "./defaults";

const dataDir = path.join(process.cwd(), "data");
fs.mkdirSync(dataDir, { recursive: true });

const DB_PATH = process.env.VOLT_DB_PATH || path.join(dataDir, "volt.db");

const globalDb = globalThis as unknown as {
  __voltDb?: DatabaseSync;
  __voltSeeded?: boolean;
};

// node:sqlite returns rows with a null prototype. React refuses to serialize
// those from a Server Component to a Client Component, so every row read from
// the database is copied onto a plain object at the driver boundary.
function plainRow(row: unknown): unknown {
  if (row && typeof row === "object" && Object.getPrototypeOf(row) !== Object.prototype) {
    return { ...(row as Record<string, unknown>) };
  }
  return row;
}

function wrapStatement(statement: ReturnType<DatabaseSync["prepare"]>) {
  return new Proxy(statement, {
    get(target, property, receiver) {
      const value = Reflect.get(target, property, receiver);
      if (property === "get" || property === "all") {
        return (...args: unknown[]) => {
          const result = (target[property] as (...a: unknown[]) => unknown)(...args);
          return Array.isArray(result) ? result.map(plainRow) : plainRow(result);
        };
      }
      return typeof value === "function" ? value.bind(target) : value;
    },
  });
}

const rawDb = globalDb.__voltDb ?? (globalDb.__voltDb = new DatabaseSync(DB_PATH));

export const db: DatabaseSync = new Proxy(rawDb, {
  get(target, property, receiver) {
    if (property === "prepare") {
      return (sql: string) => wrapStatement(target.prepare(sql));
    }
    const value = Reflect.get(target, property, receiver);
    return typeof value === "function" ? value.bind(target) : value;
  },
});

if (!globalDb.__voltSeeded) {
  initSchema();
  seed();
  globalDb.__voltSeeded = true;
}

function initSchema() {
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    PRAGMA busy_timeout = 5000;

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL UNIQUE COLLATE NOCASE,
      name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'customer',
      panel_user_id INTEGER,
      panel_username TEXT,
      panel_password_enc TEXT,
      avatar_url TEXT NOT NULL DEFAULT '',
      bio TEXT NOT NULL DEFAULT '',
      discord_handle TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token_hash TEXT NOT NULL UNIQUE,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS categories (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      tagline TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '',
      icon TEXT NOT NULL DEFAULT 'Boxes',
      accent TEXT NOT NULL DEFAULT 'blue',
      sort_order INTEGER NOT NULL DEFAULT 0,
      active INTEGER NOT NULL DEFAULT 1,
      nest_id TEXT NOT NULL DEFAULT '',
      egg_id TEXT NOT NULL DEFAULT '',
      docker_image TEXT NOT NULL DEFAULT '',
      startup TEXT NOT NULL DEFAULT '',
      environment TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      category_id TEXT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      description TEXT NOT NULL DEFAULT '',
      price_cents INTEGER NOT NULL,
      ram_mb INTEGER NOT NULL DEFAULT 2048,
      cpu_pct INTEGER NOT NULL DEFAULT 100,
      disk_mb INTEGER NOT NULL DEFAULT 10240,
      backups INTEGER NOT NULL DEFAULT 0,
      databases INTEGER NOT NULL DEFAULT 0,
      allocations INTEGER NOT NULL DEFAULT 1,
      players INTEGER NOT NULL DEFAULT 0,
      popular INTEGER NOT NULL DEFAULT 0,
      active INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 0,
      features TEXT NOT NULL DEFAULT '[]',
      nest_id TEXT NOT NULL DEFAULT '',
      egg_id TEXT NOT NULL DEFAULT '',
      docker_image TEXT NOT NULL DEFAULT '',
      startup TEXT NOT NULL DEFAULT '',
      environment TEXT NOT NULL DEFAULT '',
      allocation_id TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      product_id TEXT,
      category_id TEXT,
      item_name TEXT NOT NULL,
      server_name TEXT NOT NULL DEFAULT '',
      region TEXT NOT NULL DEFAULT 'Frankfurt',
      kind TEXT NOT NULL DEFAULT 'product',
      specs TEXT NOT NULL DEFAULT '{}',
      amount_cents INTEGER NOT NULL,
      billing_months INTEGER NOT NULL DEFAULT 1,
      status TEXT NOT NULL DEFAULT 'pending',
      gateway_id TEXT,
      gateway_ref TEXT,
      provision_error TEXT,
      promo_code TEXT,
      discount_cents INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      paid_at TEXT
    );

    CREATE TABLE IF NOT EXISTS promo_codes (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL UNIQUE COLLATE NOCASE,
      description TEXT NOT NULL DEFAULT '',
      kind TEXT NOT NULL DEFAULT 'percent',
      value INTEGER NOT NULL DEFAULT 0,
      min_cents INTEGER NOT NULL DEFAULT 0,
      max_uses INTEGER NOT NULL DEFAULT 0,
      used_count INTEGER NOT NULL DEFAULT 0,
      expires_at TEXT,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS servers (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      order_id TEXT,
      product_id TEXT,
      name TEXT NOT NULL,
      identifier TEXT NOT NULL,
      panel_server_id INTEGER,
      panel_user_id INTEGER,
      ram_mb INTEGER NOT NULL,
      cpu_pct INTEGER NOT NULL,
      disk_mb INTEGER NOT NULL,
      backups INTEGER NOT NULL DEFAULT 0,
      databases INTEGER NOT NULL DEFAULT 0,
      allocations INTEGER NOT NULL DEFAULT 1,
      nest_id TEXT NOT NULL DEFAULT '',
      egg_id TEXT NOT NULL DEFAULT '',
      docker_image TEXT NOT NULL DEFAULT '',
      startup TEXT NOT NULL DEFAULT '',
      environment TEXT NOT NULL DEFAULT '{}',
      status TEXT NOT NULL DEFAULT 'provisioning',
      ip TEXT NOT NULL DEFAULT '',
      port INTEGER,
      region TEXT NOT NULL DEFAULT 'Frankfurt',
      panel_username TEXT NOT NULL DEFAULT '',
      panel_password_enc TEXT,
      created_at TEXT NOT NULL,
      renewal_at TEXT,
      last_synced_at TEXT,
      notes TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS tickets (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      subject TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'general',
      priority TEXT NOT NULL DEFAULT 'normal',
      status TEXT NOT NULL DEFAULT 'open',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ticket_messages (
      id TEXT PRIMARY KEY,
      ticket_id TEXT NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
      user_id TEXT,
      author_name TEXT NOT NULL,
      is_staff INTEGER NOT NULL DEFAULT 0,
      body TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS gateways (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'manual',
      description TEXT NOT NULL DEFAULT '',
      enabled INTEGER NOT NULL DEFAULT 1,
      config TEXT NOT NULL DEFAULT '{}',
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS email_log (
      id TEXT PRIMARY KEY,
      to_email TEXT NOT NULL,
      subject TEXT NOT NULL,
      status TEXT NOT NULL,
      error TEXT,
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
    CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
    CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
    CREATE INDEX IF NOT EXISTS idx_servers_user ON servers(user_id);
    CREATE INDEX IF NOT EXISTS idx_tickets_user ON tickets(user_id);
    CREATE INDEX IF NOT EXISTS idx_ticket_messages_ticket ON ticket_messages(ticket_id);
  `);

  migrate();
}

/**
 * `CREATE TABLE IF NOT EXISTS` never touches an existing table, so columns
 * added after the first release are rolled forward here.
 */
function ensureColumn(table: string, column: string, definition: string) {
  const columns = db.prepare(`PRAGMA table_info(${table})`).all() as {
    name: string;
  }[];
  if (!columns.some((item) => item.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${definition}`);
  }
}

function migrate() {
  ensureColumn("users", "avatar_url", "avatar_url TEXT NOT NULL DEFAULT ''");
  ensureColumn("users", "bio", "bio TEXT NOT NULL DEFAULT ''");
  ensureColumn(
    "users",
    "discord_handle",
    "discord_handle TEXT NOT NULL DEFAULT ''",
  );
  ensureColumn("orders", "promo_code", "promo_code TEXT");
  ensureColumn(
    "orders",
    "discount_cents",
    "discount_cents INTEGER NOT NULL DEFAULT 0",
  );
}

function insertSettingIfMissing(key: string, value: unknown) {
  db.prepare("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)").run(
    key,
    JSON.stringify(value),
  );
}

function seed() {
  // `next build` evaluates this module in several workers at once. BEGIN
  // IMMEDIATE takes SQLite's write lock up front (waiting on busy_timeout), so
  // only one process runs the checks-and-inserts below; the rest then see a
  // fully seeded database instead of racing into UNIQUE constraint errors.
  db.exec("BEGIN IMMEDIATE");
  try {
    insertSettingIfMissing("site", SITE_DEFAULTS);
    insertSettingIfMissing("pricing", PRICING_DEFAULTS);
    insertSettingIfMissing("pterodactyl", PTERODACTYL_DEFAULTS);
    insertSettingIfMissing("smtp", SMTP_DEFAULTS);
    insertSettingIfMissing("discord", DISCORD_DEFAULTS);
    insertSettingIfMissing("payments", PAYMENT_DEFAULTS);

    const categoryCount = (
      db.prepare("SELECT COUNT(*) AS n FROM categories").get() as { n: number }
    ).n;

    if (categoryCount === 0) {
      seedCatalog();
    }

    // One-time default gateways. A marker keeps this from re-adding a method
    // an admin later deleted, while still upgrading databases created before
    // the Discord / UPI gateway existed.
    const gatewaysSeeded = db
      .prepare("SELECT value FROM settings WHERE key = 'gateway_defaults_v2'")
      .get() as { value: string } | undefined;

    if (!gatewaysSeeded) {
      seedGateways();
      db.prepare(
        `INSERT INTO settings (key, value) VALUES ('gateway_defaults_v2', ?)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
      ).run(new Date().toISOString());
    }

    // Earlier builds shipped a sandbox method that settled orders without
    // payment. It is removed from the codebase, so drop any row still carrying
    // the retired type.
    db.prepare("DELETE FROM gateways WHERE type = 'demo'").run();

    const adminEmail = process.env.ADMIN_EMAIL || "admin@volthosting.gg";
    const existingAdmin = db
      .prepare("SELECT id FROM users WHERE role = 'admin' LIMIT 1")
      .get();

    if (!existingAdmin) {
      const emailOwner = db
        .prepare("SELECT id FROM users WHERE email = ? COLLATE NOCASE LIMIT 1")
        .get(adminEmail);

      // Never promote or overwrite an existing customer account just because
      // it happens to use the configured admin address.
      if (!emailOwner) {
        const now = new Date().toISOString();
        db.prepare(
          `INSERT INTO users (id, email, name, password_hash, role, created_at)
           VALUES (?, ?, ?, ?, 'admin', ?)`,
        ).run(
          randomUUID(),
          adminEmail,
          process.env.ADMIN_NAME || "Volt Admin",
          hashPassword(process.env.ADMIN_PASSWORD || "VoltAdmin!2026"),
          now,
        );
      } else {
        console.warn(
          `[volt] No admin account was created: ${adminEmail} already belongs to a customer. Set ADMIN_EMAIL to a free address.`,
        );
      }
    }

    db.exec("COMMIT");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}

function seedCatalog() {
  const now = new Date().toISOString();

  const categories = [
    {
      name: "Minecraft",
      slug: "minecraft",
      tagline: "Java & Bedrock worlds",
      description:
        "Paper, Fabric, Forge and modpack hosting built for redstone, render distance and everything in between.",
      icon: "Boxes",
      accent: "cyan",
      nest: "1",
      egg: "1",
      docker: "ghcr.io/pterodactyl/yolks:java_21",
      startup:
        "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}",
      environment:
        '{"SERVER_JARFILE":"server.jar","MC_VERSION":"latest"}',
    },
    {
      name: "FiveM",
      slug: "fivem",
      tagline: "Roleplay cities & racing",
      description:
        "txAdmin, artifact updates and the single-thread speed a busy city needs.",
      icon: "Car",
      accent: "blue",
      nest: "",
      egg: "",
      docker: "",
      startup: "",
      environment: "{}",
    },
    {
      name: "Rust",
      slug: "rust",
      tagline: "Survival at full tickrate",
      description:
        "High-clock nodes, Oxide support and wipe automation for servers that cannot afford a stutter.",
      icon: "Flame",
      accent: "amber",
      nest: "",
      egg: "",
      docker: "",
      startup: "",
      environment: "{}",
    },
    {
      name: "SA-MP",
      slug: "samp",
      tagline: "San Andreas multiplayer",
      description:
        "SA-MP and open.mp hosting with fast restarts and a clean, low-latency network.",
      icon: "Gamepad2",
      accent: "mint",
      nest: "",
      egg: "",
      docker: "",
      startup: "",
      environment: "{}",
    },
    {
      name: "Discord bots",
      slug: "discord-bots",
      tagline: "Always-on automation",
      description:
        "Node, Python and Java bots with keep-alive monitoring and easy environment variables.",
      icon: "Bot",
      accent: "indigo",
      nest: "",
      egg: "",
      docker: "",
      startup: "",
      environment: "{}",
    },
    {
      name: "Cloud VPS",
      slug: "vps",
      tagline: "Root access, fixed resources",
      description:
        "Linux virtual machines with dedicated threads, NVMe storage and a 10 Gbps uplink.",
      icon: "Server",
      accent: "navy",
      nest: "",
      egg: "",
      docker: "",
      startup: "",
      environment: "{}",
    },
  ];

  const catIds = new Map<string, string>();
  categories.forEach((category, index) => {
    const id = randomUUID();
    catIds.set(category.slug, id);
    db.prepare(
      `INSERT INTO categories
       (id, name, slug, tagline, description, icon, accent, sort_order, active, nest_id, egg_id, docker_image, startup, environment, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?)`,
    ).run(
      id,
      category.name,
      category.slug,
      category.tagline,
      category.description,
      category.icon,
      category.accent,
      index,
      category.nest,
      category.egg,
      category.docker,
      category.startup,
      category.environment,
      now,
    );
  });

  const products = [
    {
      cat: "minecraft",
      name: "Snowcap",
      slug: "snowcap",
      desc: "A tidy vanilla world for friends who just want to build.",
      price: 399,
      ram: 2048,
      cpu: 100,
      disk: 10240,
      backups: 1,
      db: 1,
      alloc: 1,
      players: 20,
      popular: 0,
      features: [
        "2 GB RAM / 1 vCPU thread",
        "10 GB NVMe storage",
        "1 automatic backup",
        "Unlimited player slots",
      ],
    },
    {
      cat: "minecraft",
      name: "Icefall",
      slug: "icefall",
      desc: "The sweet spot for modded servers and busy SMPs.",
      price: 799,
      ram: 4096,
      cpu: 200,
      disk: 20480,
      backups: 2,
      db: 2,
      alloc: 2,
      players: 60,
      popular: 1,
      features: [
        "4 GB RAM / 2 vCPU threads",
        "20 GB NVMe storage",
        "2 automatic backups",
        "One-click modpack installer",
      ],
    },
    {
      cat: "minecraft",
      name: "Glacier",
      slug: "glacier",
      desc: "Render distance for days, headroom for a full network.",
      price: 1499,
      ram: 8192,
      cpu: 300,
      disk: 40960,
      backups: 3,
      db: 3,
      alloc: 3,
      players: 120,
      popular: 1,
      features: [
        "8 GB RAM / 3 vCPU threads",
        "40 GB NVMe storage",
        "3 automatic backups",
        "Priority support queue",
      ],
    },
    {
      cat: "minecraft",
      name: "Summit",
      slug: "summit",
      desc: "A flagship world for large communities and networks.",
      price: 2799,
      ram: 16384,
      cpu: 400,
      disk: 81920,
      backups: 5,
      db: 5,
      alloc: 5,
      players: 250,
      popular: 0,
      features: [
        "16 GB RAM / 4 vCPU threads",
        "80 GB NVMe storage",
        "5 automatic backups",
        "Dedicated onboarding call",
      ],
    },
    {
      cat: "fivem",
      name: "City Start",
      slug: "city-start",
      desc: "A first city with room for a few hundred citizens.",
      price: 1199,
      ram: 8192,
      cpu: 300,
      disk: 40960,
      backups: 2,
      db: 2,
      alloc: 2,
      players: 32,
      popular: 0,
      features: [
        "8 GB RAM / 3 vCPU threads",
        "40 GB NVMe storage",
        "txAdmin pre-installed",
        "Artifact auto-updates",
      ],
    },
    {
      cat: "fivem",
      name: "Metro",
      slug: "metro",
      desc: "Built for active roleplay with scripts, MLOs and traffic.",
      price: 2199,
      ram: 16384,
      cpu: 400,
      disk: 81920,
      backups: 3,
      db: 3,
      alloc: 3,
      players: 64,
      popular: 1,
      features: [
        "16 GB RAM / 4 vCPU threads",
        "80 GB NVMe storage",
        "3 automatic backups",
        "One-click resource deploys",
      ],
    },
    {
      cat: "fivem",
      name: "Megacity",
      slug: "megacity",
      desc: "Full-population roleplay without the stutter.",
      price: 3999,
      ram: 32768,
      cpu: 600,
      disk: 163840,
      backups: 5,
      db: 5,
      alloc: 5,
      players: 128,
      popular: 0,
      features: [
        "32 GB RAM / 6 vCPU threads",
        "160 GB NVMe storage",
        "5 automatic backups",
        "Priority support queue",
      ],
    },
    {
      cat: "rust",
      name: "Wipe Ready",
      slug: "wipe-ready",
      desc: "A clean, high-tickrate home for your next wipe.",
      price: 1399,
      ram: 8192,
      cpu: 300,
      disk: 40960,
      backups: 2,
      db: 1,
      alloc: 1,
      players: 100,
      popular: 0,
      features: [
        "8 GB RAM / 3 vCPU threads",
        "40 GB NVMe storage",
        "Oxide / uMod support",
        "Scheduled wipe automation",
      ],
    },
    {
      cat: "rust",
      name: "Battlefield",
      slug: "battlefield",
      desc: "Headroom for large maps and crowded monuments.",
      price: 2599,
      ram: 16384,
      cpu: 400,
      disk: 81920,
      backups: 3,
      db: 2,
      alloc: 2,
      players: 200,
      popular: 1,
      features: [
        "16 GB RAM / 4 vCPU threads",
        "80 GB NVMe storage",
        "3 automatic backups",
        "Priority support queue",
      ],
    },
    {
      cat: "samp",
      name: "Grove",
      slug: "grove",
      desc: "A small, fast SA-MP server with no fuss.",
      price: 299,
      ram: 2048,
      cpu: 200,
      disk: 10240,
      backups: 1,
      db: 1,
      alloc: 1,
      players: 100,
      popular: 0,
      features: [
        "2 GB RAM / 2 vCPU threads",
        "10 GB NVMe storage",
        "1 automatic backup",
        "DDoS-protected network",
      ],
    },
    {
      cat: "samp",
      name: "Los Santos",
      slug: "los-santos",
      desc: "More scripts, more players, same low ping.",
      price: 599,
      ram: 4096,
      cpu: 300,
      disk: 20480,
      backups: 2,
      db: 2,
      alloc: 2,
      players: 200,
      popular: 0,
      features: [
        "4 GB RAM / 3 vCPU threads",
        "20 GB NVMe storage",
        "2 automatic backups",
        "open.mp ready",
      ],
    },
    {
      cat: "discord-bots",
      name: "Pocket Bot",
      slug: "pocket-bot",
      desc: "Keep a small bot online without a spare laptop.",
      price: 199,
      ram: 1024,
      cpu: 100,
      disk: 5120,
      backups: 1,
      db: 1,
      alloc: 0,
      players: 0,
      popular: 0,
      features: [
        "1 GB RAM / 1 vCPU thread",
        "5 GB NVMe storage",
        "24/7 keep-alive",
        "Node, Python, Java & Go",
      ],
    },
    {
      cat: "discord-bots",
      name: "Guild",
      slug: "guild",
      desc: "For bots that serve more than one community.",
      price: 349,
      ram: 2048,
      cpu: 200,
      disk: 10240,
      backups: 1,
      db: 1,
      alloc: 0,
      players: 0,
      popular: 1,
      features: [
        "2 GB RAM / 2 vCPU threads",
        "10 GB NVMe storage",
        "24/7 keep-alive",
        "Environment variables built in",
      ],
    },
    {
      cat: "vps",
      name: "Droplet",
      slug: "droplet",
      desc: "A compact Linux box with root access.",
      price: 999,
      ram: 4096,
      cpu: 200,
      disk: 40960,
      backups: 1,
      db: 0,
      alloc: 0,
      players: 0,
      popular: 0,
      features: [
        "4 GB RAM / 2 dedicated threads",
        "40 GB NVMe storage",
        "Full root access",
        "1 snapshot",
      ],
    },
    {
      cat: "vps",
      name: "Current",
      slug: "current",
      desc: "Double the room for services that keep growing.",
      price: 1899,
      ram: 8192,
      cpu: 400,
      disk: 81920,
      backups: 2,
      db: 0,
      alloc: 0,
      players: 0,
      popular: 1,
      features: [
        "8 GB RAM / 4 dedicated threads",
        "80 GB NVMe storage",
        "Full root access",
        "2 snapshots",
      ],
    },
  ];

  products.forEach((product, index) => {
    const categoryId = catIds.get(product.cat);
    if (!categoryId) return;
    db.prepare(
      `INSERT INTO products
       (id, category_id, name, slug, description, price_cents, ram_mb, cpu_pct, disk_mb, backups, databases, allocations, players, popular, active, sort_order, features, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)`,
    ).run(
      randomUUID(),
      categoryId,
      product.name,
      product.slug,
      product.desc,
      product.price,
      product.ram,
      product.cpu,
      product.disk,
      product.backups,
      product.db,
      product.alloc,
      product.players,
      product.popular,
      index,
      JSON.stringify(product.features),
      now,
    );
  });
}

function seedGateways() {
  const now = new Date().toISOString();
  const gateways = [
    {
      name: "UPI, GPay & more",
      type: "discord",
      description:
        "Pay with UPI, Google Pay or another method through a Discord ticket. Your server goes live as soon as we confirm the transfer.",
      enabled: 1,
      config: {
        instructions:
          "Open a ticket in our Discord server and send your order number. Our billing team will reply with the UPI ID, QR code or other payment details within minutes.\n\nOnce the transfer is confirmed, your server is provisioned automatically and the credentials arrive by email.",
        discordUrl: "",
      },
      sort: 0,
    },
    {
      name: "Bank transfer",
      type: "manual",
      description:
        "Pay by bank transfer. Your server is provisioned after the payment is confirmed.",
      enabled: 1,
      config: {
        instructions:
          "Transfer the invoice total to the account shown on your order page. Include your order ID as the reference. Most transfers clear within one business day.",
      },
      sort: 1,
    },
    {
      name: "Card via Stripe",
      type: "stripe",
      description: "Secure card checkout hosted by Stripe.",
      enabled: 0,
      config: { mode: "test", publishableKey: "", secretKey: "", webhookSecret: "" },
      sort: 2,
    },
  ];

  gateways.forEach((gateway) => {
    // Types are the stable identity here; never duplicate a method that a
    // previous seed (or the shop owner) already has.
    const exists = db
      .prepare("SELECT 1 FROM gateways WHERE type = ? LIMIT 1")
      .get(gateway.type);
    if (exists) return;

    db.prepare(
      `INSERT INTO gateways (id, name, type, description, enabled, config, sort_order, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    ).run(
      randomUUID(),
      gateway.name,
      gateway.type,
      gateway.description,
      gateway.enabled,
      JSON.stringify(gateway.config),
      gateway.sort,
      now,
    );
  });
}
