"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Check, Circle, Loader2, X } from "lucide-react";
import type { OrderStatus, ServerStatus } from "@/lib/types";

type Progress = {
  orderStatus: OrderStatus;
  serverStatus: ServerStatus | null;
};

const STEPS = [
  { key: "placed", label: "Order placed" },
  { key: "paid", label: "Payment confirmed" },
  { key: "provisioned", label: "Server provisioned" },
  { key: "ready", label: "Ready to join" },
];

function stageOf({ orderStatus, serverStatus }: Progress): number {
  if (orderStatus === "failed") return 2;
  if (orderStatus === "cancelled" || orderStatus === "refunded") return 1;
  if (orderStatus === "pending") return 1;
  if (orderStatus === "paid") return 2;
  if (orderStatus === "provisioning") return 2;
  if (orderStatus === "active") {
    if (serverStatus === "running") return 4;
    if (serverStatus === "failed") return 2;
    return 3;
  }
  return 1;
}

export function OrderProgress({
  orderId,
  initialOrderStatus,
  initialServerStatus,
}: {
  orderId: string;
  initialOrderStatus: OrderStatus;
  initialServerStatus: ServerStatus | null;
}) {
  const router = useRouter();
  const [progress, setProgress] = useState<Progress>({
    orderStatus: initialOrderStatus,
    serverStatus: initialServerStatus,
  });

  useEffect(() => {
    let cancelled = false;
    let timer: ReturnType<typeof setTimeout> | null = null;

    const poll = async () => {
      try {
        const response = await fetch(`/api/orders/${orderId}`, {
          cache: "no-store",
        });
        if (!response.ok) return;
        const data = (await response.json()) as Progress;
        if (cancelled) return;
        setProgress((current) => {
          if (
            current.orderStatus !== data.orderStatus ||
            current.serverStatus !== data.serverStatus
          ) {
            router.refresh();
            return data;
          }
          return current;
        });
        const done =
          data.orderStatus === "active" &&
          (data.serverStatus === "running" || data.serverStatus === "failed");
        if (
          !done &&
          data.orderStatus !== "failed" &&
          data.orderStatus !== "cancelled" &&
          data.orderStatus !== "refunded"
        ) {
          timer = setTimeout(poll, 4000);
        }
      } catch {
        if (!cancelled) timer = setTimeout(poll, 6000);
      }
    };

    const terminal =
      initialOrderStatus === "active" ||
      initialOrderStatus === "failed" ||
      initialOrderStatus === "cancelled" ||
      initialOrderStatus === "refunded";
    if (!terminal || initialServerStatus === "installing") {
      timer = setTimeout(poll, 2500);
    }

    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
  }, [orderId, initialOrderStatus, initialServerStatus, router]);

  const stage = stageOf(progress);
  const failed = progress.orderStatus === "failed" || progress.serverStatus === "failed";

  return (
    <ol className="mt-5 space-y-0">
      {STEPS.map((step, index) => {
        const number = index + 1;
        const done = stage > number || (stage === 4 && number === 4);
        const active = stage === number && !failed;
        const error = failed && number === stage;
        return (
          <li key={step.key} className="relative flex gap-3 pb-5 last:pb-0">
            {index < STEPS.length - 1 && (
              <span
                aria-hidden="true"
                className={[
                  "absolute left-[11px] top-6 h-[calc(100%-1rem)] w-px",
                  done ? "bg-[#9fd9b9]" : "bg-[#d8eaf8]",
                ].join(" ")}
              />
            )}
            <span
              className={[
                "relative z-10 grid size-6 shrink-0 place-items-center rounded-full border text-[0.6rem] font-bold",
                error
                  ? "border-[#f3c6c6] bg-[#fff1f1] text-[#b03b3b]"
                  : done
                    ? "border-[#bfe8d2] bg-[#e9f9f0] text-[#0a8f5b]"
                    : active
                      ? "border-[#9bd2ff] bg-white text-[#0a63ff]"
                      : "border-[#dcecfa] bg-white/60 text-[#9ab7cc]",
              ].join(" ")}
            >
              {error ? (
                <X className="size-3" strokeWidth={3} />
              ) : done ? (
                <Check className="size-3" strokeWidth={3} />
              ) : active ? (
                <Loader2 className="size-3 animate-spin" />
              ) : (
                <Circle className="size-2 fill-current" />
              )}
            </span>
            <div className="min-w-0 pt-0.5">
              <p
                className={[
                  "text-[0.8rem] font-semibold",
                  error
                    ? "text-[#a13b3b]"
                    : done || active
                      ? "text-ink"
                      : "text-mutedblue",
                ].join(" ")}
              >
                {step.label}
              </p>
              {active && (
                <p className="mt-0.5 text-[0.72rem] text-mutedblue">
                  {number === 2
                    ? progress.orderStatus === "pending"
                      ? "Waiting for payment confirmation."
                      : "Provisioning is queued."
                    : "Usually takes under 90 seconds."}
                </p>
              )}
              {error && (
                <p className="mt-0.5 text-[0.72rem] leading-relaxed text-[#a13b3b]">
                  Something went wrong. Our team has been notified — open a
                  ticket and we will recover this order.
                </p>
              )}
            </div>
          </li>
        );
      })}
    </ol>
  );
}
