import { createHmac, timingSafeEqual } from "node:crypto";
import { revalidatePath } from "next/cache";
import { NextResponse } from "next/server";
import { getGatewayById, getOrderById } from "@/lib/queries";
import { gatewaySecret, parseGatewayConfig } from "@/lib/gateways";
import { markOrderPaid } from "@/lib/provision";

const TOLERANCE_SECONDS = 300;

type StripeEvent = {
  id?: string;
  type?: string;
  data?: {
    object?: {
      id?: string;
      client_reference_id?: string | null;
      metadata?: { order_id?: string } | null;
      payment_status?: string;
    };
  };
};

function verifySignature(input: {
  rawBody: string;
  header: string;
  secret: string;
}): { ok: true } | { ok: false; error: string } {
  const parts = input.header.split(",").map((part) => part.trim());
  const timestamp = parts
    .find((part) => part.startsWith("t="))
    ?.slice(2);
  const signatures = parts
    .filter((part) => part.startsWith("v1="))
    .map((part) => part.slice(3));

  if (!timestamp || signatures.length === 0) {
    return { ok: false, error: "Missing signature components." };
  }

  const age = Math.abs(Date.now() / 1000 - Number(timestamp));
  if (!Number.isFinite(age) || age > TOLERANCE_SECONDS) {
    return { ok: false, error: "Signature timestamp is outside tolerance." };
  }

  const expected = createHmac("sha256", input.secret)
    .update(`${timestamp}.${input.rawBody}`)
    .digest("hex");
  const expectedBuffer = Buffer.from(expected, "utf8");

  for (const signature of signatures) {
    const candidate = Buffer.from(signature, "utf8");
    if (
      candidate.length === expectedBuffer.length &&
      timingSafeEqual(candidate, expectedBuffer)
    ) {
      return { ok: true };
    }
  }

  return { ok: false, error: "Signature does not match." };
}

export async function POST(request: Request) {
  const signature = request.headers.get("stripe-signature");
  if (!signature) {
    return NextResponse.json(
      { error: "Missing Stripe-Signature header." },
      { status: 400 },
    );
  }

  const rawBody = await request.text();

  let event: StripeEvent;
  try {
    event = JSON.parse(rawBody) as StripeEvent;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  if (
    event.type !== "checkout.session.completed" &&
    event.type !== "checkout.session.async_payment_succeeded"
  ) {
    return NextResponse.json({ received: true, ignored: event.type ?? null });
  }

  const session = event.data?.object;
  const orderId =
    session?.metadata?.order_id || session?.client_reference_id || "";
  if (!orderId) {
    return NextResponse.json(
      { error: "Checkout session has no order reference." },
      { status: 400 },
    );
  }

  const order = getOrderById(orderId);
  if (!order) {
    return NextResponse.json({ error: "Order not found." }, { status: 404 });
  }

  const gateway = order.gateway_id
    ? getGatewayById(order.gateway_id)
    : undefined;
  const config = gateway ? parseGatewayConfig(gateway.config) : {};
  const webhookSecret = gatewaySecret(config, "webhookSecret");
  if (!webhookSecret) {
    return NextResponse.json(
      { error: "This payment method has no webhook secret configured." },
      { status: 400 },
    );
  }

  const verified = verifySignature({
    rawBody,
    header: signature,
    secret: webhookSecret,
  });
  if (!verified.ok) {
    return NextResponse.json({ error: verified.error }, { status: 400 });
  }

  if (session?.payment_status && session.payment_status !== "paid") {
    return NextResponse.json({ received: true, awaitingPayment: true });
  }

  if (order.status === "active") {
    return NextResponse.json({ received: true, alreadyActive: true });
  }

  const result = await markOrderPaid(order.id, session?.id ?? undefined);
  revalidatePath("/dashboard");
  revalidatePath("/dashboard/billing");
  revalidatePath("/dashboard/servers");
  revalidatePath("/admin/orders");
  revalidatePath(`/admin/orders/${order.id}`);

  if (!result.ok) {
    // A 500 keeps the event in Stripe's retry queue; provisioning can also be
    // retried by hand from the order page.
    return NextResponse.json(
      { received: true, provisioned: false, error: result.error },
      { status: 500 },
    );
  }

  return NextResponse.json({
    received: true,
    provisioned: true,
    serverId: result.serverId ?? null,
  });
}
