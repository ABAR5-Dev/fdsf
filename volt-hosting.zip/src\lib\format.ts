import type { PricingSettings, Specs } from "./types";

export function money(cents: number, currency = "USD"): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: cents % 100 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(cents / 100);
}

export function dateLabel(value: string | null | undefined): string {
  if (!value) return "—";
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC",
  }).format(new Date(value));
}

export function dateTimeLabel(value: string | null | undefined): string {
  if (!value) return "—";
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    timeZone: "UTC",
  }).format(new Date(value));
}

export function relativeTime(value: string | null | undefined): string {
  if (!value) return "—";
  const diff = Date.now() - new Date(value).getTime();
  const minutes = Math.round(diff / 60_000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  if (days < 30) return `${days}d ago`;
  return dateLabel(value);
}

export function ramLabel(mb: number): string {
  if (mb >= 1024) {
    const gb = mb / 1024;
    return `${Number.isInteger(gb) ? gb : gb.toFixed(1)} GB`;
  }
  return `${mb} MB`;
}

export function diskLabel(mb: number): string {
  if (mb >= 1024) {
    const gb = mb / 1024;
    return `${Number.isInteger(gb) ? gb : gb.toFixed(1)} GB`;
  }
  return `${mb} MB`;
}

export function cpuLabel(pct: number): string {
  const cores = pct / 100;
  return `${Number.isInteger(cores) ? cores : cores.toFixed(1)} vCPU`;
}

export function slugify(value: string): string {
  return value
    .toLowerCase()
    .trim()
    .replace(/['"]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 64);
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}

export function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

export const ORDER_STATUS_META: Record<
  string,
  { label: string; tone: string; dot: string }
> = {
  pending: { label: "Awaiting payment", tone: "amber", dot: "bg-amber-400" },
  paid: { label: "Paid", tone: "blue", dot: "bg-sky-400" },
  provisioning: {
    label: "Provisioning",
    tone: "blue",
    dot: "bg-blue-400",
  },
  active: { label: "Active", tone: "mint", dot: "bg-emerald-400" },
  failed: { label: "Needs attention", tone: "rose", dot: "bg-rose-400" },
  cancelled: { label: "Cancelled", tone: "slate", dot: "bg-slate-400" },
  refunded: { label: "Refunded", tone: "slate", dot: "bg-slate-400" },
};

export const SERVER_STATUS_META: Record<
  string,
  { label: string; tone: string; dot: string }
> = {
  provisioning: {
    label: "Provisioning",
    tone: "blue",
    dot: "bg-blue-400",
  },
  installing: { label: "Installing", tone: "amber", dot: "bg-amber-400" },
  running: { label: "Running", tone: "mint", dot: "bg-emerald-400" },
  offline: { label: "Offline", tone: "slate", dot: "bg-slate-400" },
  suspended: { label: "Suspended", tone: "rose", dot: "bg-rose-400" },
  failed: { label: "Failed", tone: "rose", dot: "bg-rose-400" },
};

export const TICKET_STATUS_META: Record<
  string,
  { label: string; tone: string; dot: string }
> = {
  open: { label: "Open", tone: "blue", dot: "bg-sky-400" },
  answered: { label: "Answered", tone: "mint", dot: "bg-emerald-400" },
  closed: { label: "Closed", tone: "slate", dot: "bg-slate-400" },
};

export const PRIORITY_META: Record<string, { label: string; tone: string }> = {
  low: { label: "Low", tone: "slate" },
  normal: { label: "Normal", tone: "blue" },
  high: { label: "High", tone: "amber" },
  urgent: { label: "Urgent", tone: "rose" },
};

export function termPrice(
  monthlyCents: number,
  months: number,
  pricing: PricingSettings,
): number {
  const discount =
    months >= 12
      ? pricing.yearlyDiscount
      : months >= 3
        ? pricing.quarterlyDiscount
        : 0;
  return Math.round(monthlyCents * months * (1 - discount / 100));
}

export function termDiscount(months: number, pricing: PricingSettings): number {
  if (months >= 12) return pricing.yearlyDiscount;
  if (months >= 3) return pricing.quarterlyDiscount;
  return 0;
}

export function calculateCustomCents(
  specs: Specs,
  pricing: PricingSettings,
): number {
  const ramGb = specs.ramMb / 1024;
  const diskGb = specs.diskMb / 1024;
  const cpuCores = specs.cpuPct / 100;
  return Math.round(
    pricing.baseCents +
      ramGb * pricing.ramPerGbCents +
      cpuCores * pricing.cpuPerCoreCents +
      diskGb * pricing.diskPerGbCents +
      specs.backups * pricing.backupCents,
  );
}

export function billingLabel(months: number): string {
  if (months >= 12) return "Yearly";
  if (months >= 3) return "Quarterly";
  return "Monthly";
}

export function specsFromProduct(product: {
  ram_mb: number;
  cpu_pct: number;
  disk_mb: number;
  backups: number;
  databases: number;
  allocations: number;
  players: number;
}): Specs {
  return {
    ramMb: product.ram_mb,
    cpuPct: product.cpu_pct,
    diskMb: product.disk_mb,
    backups: product.backups,
    databases: product.databases,
    allocations: product.allocations,
    players: product.players,
  };
}
