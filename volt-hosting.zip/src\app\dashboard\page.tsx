import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import {
  ArrowRight,
  CalendarClock,
  LifeBuoy,
  MessageSquarePlus,
  ReceiptText,
  Server,
  Ticket,
} from "lucide-react";
import { ServerCard } from "@/components/app/server-card";
import { StatusPill } from "@/components/status-pill";
import { getCurrentUser } from "@/lib/auth";
import {
  ORDER_STATUS_META,
  dateLabel,
  money,
  relativeTime,
} from "@/lib/format";
import {
  getOrdersForUser,
  getTicketsForUser,
} from "@/lib/queries";
import { syncUserServers } from "@/lib/provision";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Dashboard" };

export default async function DashboardPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard");

  const servers = await syncUserServers(user.id);
  const orders = getOrdersForUser(user.id);
  const tickets = getTicketsForUser(user.id);
  const openTickets = tickets.filter((ticket) => ticket.status !== "closed");

  const running = servers.filter((server) => server.status === "running").length;
  const monthlyValue = servers.reduce((sum, server) => {
    const order = orders.find((item) => item.id === server.order_id);
    return sum + (order ? Math.round(order.amount_cents / order.billing_months) : 0);
  }, 0);
  const nextRenewal = servers
    .map((server) => server.renewal_at)
    .filter((value): value is string => Boolean(value))
    .sort()[0];

  const firstName = user.name.split(" ")[0] || user.name;

  return (
    <div className="mx-auto max-w-[1120px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">
            Welcome back, {firstName}.
          </h1>
          <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
            {servers.length === 0
              ? "Your first server is a checkout away — provisioning is automatic."
              : `${running} of ${servers.length} ${
                  servers.length === 1 ? "server is" : "servers are"
                } running. Everything else is in the list below.`}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link href="/dashboard/support/new" className="btn btn-secondary btn-sm">
            <MessageSquarePlus className="size-4" />
            New ticket
          </Link>
          <Link href="/store" className="btn btn-primary btn-sm">
            <Server className="size-4" />
            Deploy server
          </Link>
        </div>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {[
          {
            label: "Active servers",
            value: String(servers.length),
            hint: `${running} running now`,
            icon: Server,
          },
          {
            label: "Monthly value",
            value: money(monthlyValue),
            hint: "Across active services",
            icon: ReceiptText,
          },
          {
            label: "Open tickets",
            value: String(openTickets.length),
            hint: openTickets.length ? "Support is on it" : "Nothing waiting",
            icon: Ticket,
          },
          {
            label: "Next renewal",
            value: nextRenewal ? dateLabel(nextRenewal) : "—",
            hint: nextRenewal ? "Automatic invoice" : "No renewals yet",
            icon: CalendarClock,
          },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="glass-quiet rounded-2xl p-4">
              <div className="flex items-center justify-between">
                <span className="text-[0.7rem] font-medium text-mutedblue">
                  {stat.label}
                </span>
                <Icon className="size-3.5 text-[#7fa5c2]" />
              </div>
              <p className="mono tabular mt-2 text-[1.4rem] font-semibold leading-none tracking-[-0.03em] text-ink">
                {stat.value}
              </p>
              <p className="mt-1 text-[0.66rem] text-mutedblue">{stat.hint}</p>
            </div>
          );
        })}
      </div>

      <section className="mt-6">
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="text-[0.92rem] font-semibold text-ink">Your servers</h2>
          {servers.length > 0 && (
            <Link
              href="/dashboard/servers"
              className="inline-flex items-center gap-1 text-[0.76rem] font-semibold text-[#0a63ff] hover:underline"
            >
              View all
              <ArrowRight className="size-3.5" />
            </Link>
          )}
        </div>

        {servers.length === 0 ? (
          <div className="glass rounded-2xl p-8 text-center">
            <span className="mx-auto grid size-12 place-items-center rounded-2xl bg-white/80 text-[#0a63ff] shadow-sm">
              <Server className="size-6" />
            </span>
            <h3 className="display-soft mt-4 text-[1.2rem] text-ink">
              No servers yet.
            </h3>
            <p className="mx-auto mt-1.5 max-w-[44ch] text-[0.82rem] leading-relaxed text-ink-soft/80">
              Pick a game, choose your memory and pay. The panel login lands in
              your inbox within 90 seconds.
            </p>
            <Link href="/store" className="btn btn-primary btn-sm mt-5">
              Browse game servers
              <ArrowRight className="size-3.5" />
            </Link>
          </div>
        ) : (
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {servers.slice(0, 3).map((server) => (
              <ServerCard key={server.id} server={server} />
            ))}
          </div>
        )}
      </section>

      <div className="mt-6 grid gap-4 lg:grid-cols-[1.4fr_0.6fr]">
        <section className="glass rounded-2xl p-4">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-[0.92rem] font-semibold text-ink">Recent orders</h2>
            <Link
              href="/dashboard/billing"
              className="inline-flex items-center gap-1 text-[0.74rem] font-semibold text-[#0a63ff] hover:underline"
            >
              Billing
              <ArrowRight className="size-3" />
            </Link>
          </div>

          {orders.length === 0 ? (
            <p className="mt-6 pb-4 text-center text-[0.8rem] text-mutedblue">
              No orders yet. Your first one will show up here.
            </p>
          ) : (
            <div className="table-scroll mt-2">
              <table className="data-table">
                <thead>
                  <tr>
                    <th scope="col">Order</th>
                    <th scope="col">Placed</th>
                    <th scope="col">Total</th>
                    <th scope="col">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.slice(0, 5).map((order) => {
                    const meta =
                      ORDER_STATUS_META[order.status] ?? ORDER_STATUS_META.pending;
                    return (
                      <tr key={order.id}>
                        <td>
                          <span className="block text-[0.8rem] font-medium text-ink">
                            {order.item_name}
                          </span>
                          <span className="text-[0.66rem] text-mutedblue">
                            {order.server_name}
                          </span>
                        </td>
                        <td className="whitespace-nowrap text-[0.74rem] text-mutedblue">
                          {relativeTime(order.created_at)}
                        </td>
                        <td className="mono whitespace-nowrap text-[0.76rem]">
                          {money(order.amount_cents)}
                        </td>
                        <td>
                          <StatusPill label={meta.label} tone={meta.tone} dot />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <aside className="space-y-4">
          <div className="glass rounded-2xl p-4">
            <span className="grid size-9 place-items-center rounded-xl bg-white/80 text-[#0a63ff]">
              <LifeBuoy className="size-4" />
            </span>
            <h2 className="display-soft mt-3 text-[1rem] text-ink">
              Support, by humans.
            </h2>
            <p className="mt-1 text-[0.76rem] leading-relaxed text-ink-soft/80">
              {openTickets.length > 0
                ? `${openTickets.length} ${
                    openTickets.length === 1 ? "ticket is" : "tickets are"
                  } being looked at.`
                : "Median first reply is eleven minutes. No macro loops."}
            </p>
            <Link href="/dashboard/support" className="btn btn-secondary btn-sm mt-3 w-full">
              Open support
            </Link>
          </div>

          <div className="glass rounded-2xl p-4">
            <h2 className="text-[0.8rem] font-semibold text-ink">Need more room?</h2>
            <p className="mt-1 text-[0.74rem] leading-relaxed text-ink-soft/80">
              Add RAM, CPU or storage to an existing server, or launch a second
              world.
            </p>
            <Link
              href="/store"
              className="mt-3 inline-flex items-center gap-1 text-[0.74rem] font-semibold text-[#0a63ff] hover:underline"
            >
              Browse upgrades
              <ArrowRight className="size-3" />
            </Link>
          </div>
        </aside>
      </div>
    </div>
  );
}
