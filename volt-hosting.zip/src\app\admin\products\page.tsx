import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import {
  Archive,
  ArrowUpRight,
  PackagePlus,
  Power,
  Trash2,
} from "lucide-react";
import { ConfirmSubmitButton } from "@/components/app/confirm-submit-button";
import { StatusPill } from "@/components/status-pill";
import { diskLabel, money, ramLabel } from "@/lib/format";
import { getProducts } from "@/lib/queries";
import {
  deleteProductAction,
  toggleProductAction,
} from "@/lib/actions/admin";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Products" };

type PageProps = {
  searchParams: Promise<{ archived?: string; deleted?: string }>;
};

export default async function AdminProductsPage({ searchParams }: PageProps) {
  await requireAdmin("/admin/products");
  const { archived, deleted } = await searchParams;
  const products = getProducts();
  const active = products.filter((product) => product.active === 1).length;

  return (
    <div className="mx-auto max-w-[1240px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">Products</h1>
          <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
            Every plan in the store. Price and resources here are what checkout
            charges and provisions.
          </p>
        </div>
        <Link href="/admin/products/new" className="btn btn-primary btn-sm">
          <PackagePlus className="size-4" />
          New product
        </Link>
      </div>

      {(archived || deleted) && (
        <p
          className={`mt-4 flex items-center gap-2 rounded-xl border px-3.5 py-2.5 text-[0.78rem] ${
            archived
              ? "border-[#f5e2c0] bg-[#fff8eb] text-[#7d5410]"
              : "border-[#c4e8d5] bg-[#f2fbf6] text-[#0a7a4e]"
          }`}
        >
          <Archive className="size-3.5 shrink-0" />
          {archived
            ? "This product has orders, so it was hidden from the store instead of deleted."
            : "Product deleted."}
        </p>
      )}

      <div className="mt-4 flex flex-wrap gap-2 text-[0.72rem] text-mutedblue">
        <span className="rounded-full border border-white/90 bg-white/55 px-2.5 py-1">
          {products.length} total
        </span>
        <span className="rounded-full border border-white/90 bg-white/55 px-2.5 py-1">
          {active} live
        </span>
        <span className="rounded-full border border-white/90 bg-white/55 px-2.5 py-1">
          {products.length - active} hidden
        </span>
      </div>

      <section className="glass mt-3 rounded-2xl p-2 sm:p-3">
        {products.length === 0 ? (
          <div className="py-14 text-center">
            <p className="text-[0.86rem] font-semibold text-ink">No products yet.</p>
            <p className="mt-1 text-[0.76rem] text-mutedblue">
              Create one plan to open the store.
            </p>
            <Link href="/admin/products/new" className="btn btn-primary btn-sm mt-4">
              Add the first product
            </Link>
          </div>
        ) : (
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th scope="col">Product</th>
                  <th scope="col">Category</th>
                  <th scope="col">Monthly</th>
                  <th scope="col">Resources</th>
                  <th scope="col">Store</th>
                  <th scope="col" aria-label="Actions" />
                </tr>
              </thead>
              <tbody>
                {products.map((product) => (
                  <tr key={product.id}>
                    <td>
                      <Link
                        href={`/admin/products/${product.id}`}
                        className="block text-[0.8rem] font-medium text-ink hover:text-[#0a63ff]"
                      >
                        {product.name}
                      </Link>
                      <span className="mono text-[0.64rem] text-mutedblue">
                        {product.slug}
                        {product.popular === 1 ? " · popular" : ""}
                      </span>
                    </td>
                    <td className="whitespace-nowrap text-[0.74rem] text-ink-soft">
                      {product.category_name}
                    </td>
                    <td className="mono whitespace-nowrap text-[0.76rem]">
                      {money(product.price_cents)}
                    </td>
                    <td className="whitespace-nowrap text-[0.72rem] text-ink-soft">
                      {ramLabel(product.ram_mb)} / {diskLabel(product.disk_mb)} /{" "}
                      {product.cpu_pct}% CPU
                    </td>
                    <td>
                      <StatusPill
                        label={product.active === 1 ? "Live" : "Hidden"}
                        tone={product.active === 1 ? "mint" : "slate"}
                        dot
                      />
                    </td>
                    <td>
                      <div className="flex items-center justify-end gap-1">
                        <Link
                          href={`/admin/products/${product.id}`}
                          aria-label={`Edit ${product.name}`}
                          className="grid size-7 place-items-center rounded-lg text-[#7fa5c2] transition hover:bg-white/70 hover:text-[#0a63ff]"
                        >
                          <ArrowUpRight className="size-3.5" />
                        </Link>
                        <form action={toggleProductAction}>
                          <input type="hidden" name="id" value={product.id} />
                          <button
                            type="submit"
                            aria-label={
                              product.active === 1
                                ? `Hide ${product.name}`
                                : `Publish ${product.name}`
                            }
                            className="grid size-7 place-items-center rounded-lg text-[#7fa5c2] transition hover:bg-white/70 hover:text-[#0a63ff]"
                          >
                            <Power className="size-3.5" />
                          </button>
                        </form>
                        <form action={deleteProductAction}>
                          <input type="hidden" name="id" value={product.id} />
                          <ConfirmSubmitButton
                            message={`Delete ${product.name}? This removes the plan from the store.`}
                            aria-label={`Delete ${product.name}`}
                            className="grid size-7 place-items-center rounded-lg text-[#b58c8c] transition hover:bg-[#fff1f1] hover:text-[#a13b3b]"
                          >
                            <Trash2 className="size-3.5" />
                          </ConfirmSubmitButton>
                        </form>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
