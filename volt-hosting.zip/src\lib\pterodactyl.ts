import { decryptSecret } from "./crypto";
import { getPterodactyl } from "./queries";
import type { ServerStatus, UserRow } from "./types";

export class PterodactylError extends Error {
  status: number;
  constructor(message: string, status = 0) {
    super(message);
    this.name = "PterodactylError";
    this.status = status;
  }
}

type PteroUser = {
  id: number;
  username: string;
  email: string;
  first_name?: string;
  last_name?: string;
};

type PteroServer = {
  id: number;
  identifier: string;
  uuid?: string;
  name: string;
  status: string | null;
  suspended: boolean;
  limits?: Record<string, unknown>;
  feature_limits?: Record<string, unknown>;
  allocation?: { id: number; ip: string; port: number };
  container?: { installed?: boolean };
  relationships?: {
    allocations?: { data?: { attributes: { id: number; ip: string; port: number } }[] };
    variables?: { data?: { attributes: { env_variable: string } }[] };
  };
};

function panelBase(): string {
  const config = getPterodactyl();
  if (!config.panelUrl) {
    throw new PterodactylError("Panel URL is not configured.");
  }
  return config.panelUrl.replace(/\/+$/, "");
}

async function pteroRequest<T>(
  path: string,
  init?: RequestInit,
): Promise<T> {
  const config = getPterodactyl();
  if (!config.apiKey) {
    throw new PterodactylError("Application API key is not configured.");
  }

  const response = await fetch(`${panelBase()}/api/application${path}`, {
    ...init,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${config.apiKey}`,
      ...(init?.headers ?? {}),
    },
    cache: "no-store",
  });

  if (!response.ok) {
    let detail = `Pterodactyl returned ${response.status}.`;
    try {
      const data = (await response.json()) as {
        errors?: { detail?: string; code?: string }[];
      };
      if (data.errors?.[0]?.detail) {
        detail = data.errors[0].detail;
      }
    } catch {
      // keep the status message
    }
    throw new PterodactylError(detail, response.status);
  }

  if (response.status === 204) return undefined as T;
  return (await response.json()) as T;
}

export type PteroTestResult =
  | { ok: true; nodes: number; version?: string }
  | { ok: false; error: string };

export async function testPterodactyl(): Promise<PteroTestResult> {
  try {
    const data = await pteroRequest<{
      object?: string;
      data?: unknown[];
      meta?: { pagination?: { total?: number } };
    }>("/nodes?per_page=1");
    return {
      ok: true,
      nodes: data.meta?.pagination?.total ?? data.data?.length ?? 0,
    };
  } catch (error) {
    return {
      ok: false,
      error: error instanceof Error ? error.message : "Connection failed",
    };
  }
}

export async function listNodes(): Promise<
  { id: number; name: string; fqdn: string }[]
> {
  const data = await pteroRequest<{
    data: {
      attributes: { id: number; name: string; fqdn: string };
    }[];
  }>("/nodes?per_page=100");
  return data.data.map((row) => row.attributes);
}

export async function listAllocations(nodeId: string): Promise<
  { id: number; ip: string; port: number; assigned: boolean; notes: string }[]
> {
  if (!nodeId) throw new PterodactylError("Choose a node first.");
  const data = await pteroRequest<{
    data: {
      attributes: {
        id: number;
        ip: string;
        port: number;
        assigned: boolean;
        notes?: string | null;
      };
    }[];
  }>(`/nodes/${nodeId}/allocations?per_page=100`);
  return data.data
    .map((row) => ({
      id: row.attributes.id,
      ip: row.attributes.ip,
      port: row.attributes.port,
      assigned: row.attributes.assigned,
      notes: row.attributes.notes ?? "",
    }))
    .sort((a, b) => a.id - b.id);
}

export async function findPanelUserByEmail(
  email: string,
): Promise<PteroUser | null> {
  const data = await pteroRequest<{
    data: { attributes: PteroUser }[];
  }>(`/users?filter[email]=${encodeURIComponent(email)}&per_page=50`);
  const match = data.data.find(
    (row) => row.attributes.email.toLowerCase() === email.toLowerCase(),
  );
  return match?.attributes ?? null;
}

export async function createPanelUser(input: {
  email: string;
  username: string;
  name: string;
  password: string;
}): Promise<PteroUser> {
  const parts = input.name.trim().split(/\s+/);
  const body = {
    email: input.email,
    username: input.username,
    first_name: parts[0] || "Server",
    last_name: parts.slice(1).join(" ") || "Owner",
    password: input.password,
  };

  try {
    const data = await pteroRequest<{
      attributes: PteroUser;
    }>("/users", {
      method: "POST",
      body: JSON.stringify(body),
    });
    return data.attributes;
  } catch (error) {
    if (error instanceof PterodactylError && error.status === 422) {
      const fallbackUsername = `${input.username.slice(0, 12)}${Math.floor(
        1000 + Math.random() * 9000,
      )}`;
      const retry = await pteroRequest<{ attributes: PteroUser }>("/users", {
        method: "POST",
        body: JSON.stringify({ ...body, username: fallbackUsername }),
      });
      return retry.attributes;
    }
    throw error;
  }
}

export async function updatePanelUserPassword(
  panelUserId: number,
  password: string,
): Promise<void> {
  await pteroRequest(`/users/${panelUserId}`, {
    method: "PATCH",
    body: JSON.stringify({ password }),
  });
}

export type PanelAccountResult = {
  id: number;
  username: string;
  password: string;
  passwordChanged: boolean;
  created: boolean;
};

export async function ensurePanelAccount(input: {
  user: UserRow;
  newPassword: string;
}): Promise<PanelAccountResult> {
  const { user, newPassword } = input;

  if (user.panel_user_id) {
    const stored = decryptSecret(user.panel_password_enc);
    if (stored) {
      return {
        id: user.panel_user_id,
        username: user.panel_username || `user${user.panel_user_id}`,
        password: stored,
        passwordChanged: false,
        created: false,
      };
    }
    await updatePanelUserPassword(user.panel_user_id, newPassword);
    return {
      id: user.panel_user_id,
      username: user.panel_username || `user${user.panel_user_id}`,
      password: newPassword,
      passwordChanged: true,
      created: false,
    };
  }

  const existing = await findPanelUserByEmail(user.email);
  if (existing) {
    await updatePanelUserPassword(existing.id, newPassword);
    return {
      id: existing.id,
      username: existing.username,
      password: newPassword,
      passwordChanged: true,
      created: false,
    };
  }

  const baseUsername =
    user.panel_username ||
    user.email
      .split("@")[0]
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "")
      .slice(0, 16) ||
    `player${Math.floor(1000 + Math.random() * 9000)}`;

  const created = await createPanelUser({
    email: user.email,
    username: baseUsername,
    name: user.name,
    password: newPassword,
  });

  return {
    id: created.id,
    username: created.username,
    password: newPassword,
    passwordChanged: true,
    created: true,
  };
}

export type CreateServerInput = {
  name: string;
  panelUserId: number;
  nestId: number;
  eggId: number;
  dockerImage: string;
  startup: string;
  environment: Record<string, string>;
  memoryMb: number;
  diskMb: number;
  cpuPct: number;
  databases: number;
  backups: number;
  allocations: number;
  allocationId: number;
};

export async function createPanelServer(
  input: CreateServerInput,
): Promise<PteroServer> {
  const body = {
    name: input.name,
    user: input.panelUserId,
    egg: input.eggId,
    docker_image: input.dockerImage,
    startup: input.startup,
    environment: input.environment,
    limits: {
      memory: input.memoryMb,
      swap: 0,
      disk: input.diskMb,
      io: 500,
      cpu: input.cpuPct,
      oom_disabled: false,
    },
    feature_limits: {
      databases: input.databases,
      allocations: input.allocations,
      backups: input.backups,
    },
    allocation: {
      default: input.allocationId,
    },
  };

  const data = await pteroRequest<{
    attributes: PteroServer;
  }>("/servers", {
    method: "POST",
    body: JSON.stringify(body),
  });
  return data.attributes;
}

export async function getPanelServer(
  panelServerId: number,
): Promise<PteroServer> {
  const data = await pteroRequest<{
    attributes: PteroServer;
  }>(`/servers/${panelServerId}?include=allocations`);
  return data.attributes;
}

export function panelServerStatus(server: PteroServer): ServerStatus {
  if (server.suspended) return "suspended";
  if (server.status === "install_failed") return "failed";
  if (server.status === "installing") return "installing";
  if (server.container?.installed === false) return "installing";
  return "running";
}

export function serverAddress(server: PteroServer): {
  ip: string;
  port: number | null;
} {
  const allocation =
    server.allocation ??
    server.relationships?.allocations?.data?.[0]?.attributes;
  if (!allocation) return { ip: "", port: null };
  return { ip: allocation.ip, port: allocation.port };
}

export async function suspendPanelServer(
  panelServerId: number,
): Promise<void> {
  await pteroRequest(`/servers/${panelServerId}/suspend`, {
    method: "POST",
  });
}

export async function unsuspendPanelServer(
  panelServerId: number,
): Promise<void> {
  await pteroRequest(`/servers/${panelServerId}/unsuspend`, {
    method: "POST",
  });
}
