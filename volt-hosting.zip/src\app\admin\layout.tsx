import { Suspense } from "react";
import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { AppChrome, type NavItem } from "@/components/app/app-chrome";
import { getCurrentUser } from "@/lib/auth";
import { getAllTickets } from "@/lib/queries";

export const metadata: Metadata = {
  title: { default: "Admin", template: "%s · Volt admin" },
};

// Every admin screen checks the session before it can render, so navigation
// has to wait for that check rather than showing an instant static shell.
export const instant = false;

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <Suspense fallback={<ChromeSkeleton />}>
      <AdminShell>{children}</AdminShell>
    </Suspense>
  );
}

async function AdminShell({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/admin");
  if (user.role !== "admin") redirect("/dashboard");

  const openTickets = getAllTickets().filter(
    (ticket) => ticket.status !== "closed",
  ).length;

  const items: NavItem[] = [
    { href: "/admin", label: "Overview", icon: "Gauge", exact: true },
    { href: "/admin/orders", label: "Orders", icon: "ReceiptText" },
    { href: "/admin/servers", label: "Servers", icon: "Server" },
    { href: "/admin/products", label: "Products", icon: "Package" },
    { href: "/admin/categories", label: "Categories", icon: "Tags" },
    { href: "/admin/users", label: "Customers", icon: "Users" },
    {
      href: "/admin/tickets",
      label: "Tickets",
      icon: "Ticket",
      badge: openTickets,
    },
    { href: "/admin/payments", label: "Payments", icon: "CreditCard" },
    { href: "/admin/promotions", label: "Promo codes", icon: "TicketPercent" },
    { href: "/admin/settings", label: "Settings", icon: "Settings" },
    { href: "/admin/email", label: "Email log", icon: "Mail" },
  ];

  return (
    <AppChrome
      items={items}
      user={{
        name: user.name,
        email: user.email,
        role: user.role,
        avatarUrl: user.avatarUrl,
      }}
      area="admin"
    >
      {children}
    </AppChrome>
  );
}

function ChromeSkeleton() {
  return (
    <div className="app-shell">
      <aside className="app-sidebar">
        <div className="px-2">
          <div className="size-9 animate-pulse rounded-[11px] bg-white/70" />
        </div>
        <div className="mt-8 space-y-2 px-2">
          {[0, 1, 2, 3, 4, 5, 6, 7].map((item) => (
            <div key={item} className="h-9 animate-pulse rounded-lg bg-white/55" />
          ))}
        </div>
      </aside>
      <div className="min-w-0">
        <div className="h-14 border-b border-white/60 bg-white/40" />
        <div className="space-y-4 px-4 py-6 sm:px-6 lg:px-8">
          <div className="h-8 w-64 animate-pulse rounded-lg bg-white/70" />
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {[0, 1, 2, 3].map((item) => (
              <div key={item} className="h-24 animate-pulse rounded-2xl bg-white/55" />
            ))}
          </div>
          <div className="h-64 animate-pulse rounded-2xl bg-white/55" />
        </div>
      </div>
    </div>
  );
}
