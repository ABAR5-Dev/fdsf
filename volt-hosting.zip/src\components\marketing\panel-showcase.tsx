import {
  Archive,
  CalendarClock,
  Check,
  FolderClosed,
  Gauge,
  KeyRound,
  Play,
  TerminalSquare,
  Users,
} from "lucide-react";

const FEATURES = [
  {
    icon: TerminalSquare,
    title: "A console that keeps up",
    body: "Full Pterodactyl console, live output and command history on every plan.",
  },
  {
    icon: FolderClosed,
    title: "Files without FTP clients",
    body: "Drag files in the browser, or connect over SFTP when you want a real editor.",
  },
  {
    icon: CalendarClock,
    title: "Schedules and backups",
    body: "Restart on a cron, snapshot before every update, restore in a couple of clicks.",
  },
  {
    icon: Users,
    title: "Subusers with limits",
    body: "Invite moderators and scope exactly which controls they can touch.",
  },
];

export function PanelShowcase() {
  return (
    <div className="grid items-center gap-10 lg:grid-cols-[0.9fr_1.1fr]">
      <div>
        <span className="chip chip-accent">
          <Gauge className="size-3.5" />
          Pterodactyl, tuned
        </span>
        <h2 className="display mt-4 max-w-[14ch] text-[2rem] text-ink sm:text-[2.7rem]">
          The panel your mods already know.
        </h2>
        <p className="lede mt-4">
          We run a current Pterodactyl panel with sensible defaults and a
          shorter path to the things people actually do: restart, upload, invite,
          restore.
        </p>

        <div className="mt-7 space-y-4">
          {FEATURES.map((feature) => {
            const Icon = feature.icon;
            return (
              <div key={feature.title} className="flex gap-3">
                <span className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-lg border border-white bg-white/70 text-[#0a63ff] shadow-sm">
                  <Icon className="size-4" />
                </span>
                <div>
                  <h3 className="text-[0.88rem] font-semibold text-ink">
                    {feature.title}
                  </h3>
                  <p className="mt-0.5 text-[0.8rem] leading-relaxed text-ink-soft/80">
                    {feature.body}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 inline-flex items-center gap-2 rounded-xl border border-white/90 bg-white/55 px-3 py-2 text-[0.76rem] text-ink-soft">
          <KeyRound className="size-4 text-[#0a63ff]" />
          Your credentials are emailed at provisioning — never posted in chat.
        </div>
      </div>

      {/* Static panel preview */}
      <div className="relative">
        <div
          aria-hidden="true"
          className="absolute -inset-4 -z-10 rounded-[32px] bg-[radial-gradient(60%_60%_at_60%_10%,rgba(76,186,255,0.25),transparent_70%)] blur-xl"
        />
        <div className="glass rounded-2xl p-2">
          <div className="overflow-hidden rounded-[14px] border border-[#dcecfa] bg-[#fbfdff]">
            {/* browser chrome */}
            <div className="flex items-center gap-2 border-b border-[#e3f0fb] bg-white/80 px-3 py-2">
              <span className="size-1.5 rounded-full bg-[#ffb3b3]" />
              <span className="size-1.5 rounded-full bg-[#ffd79b]" />
              <span className="size-1.5 rounded-full bg-[#a8e6c6]" />
              <span className="mono ml-2 flex-1 truncate rounded-md border border-[#e5f1fb] bg-[#f5fbff] px-2 py-1 text-[0.56rem] text-[#6f8ea4]">
                panel.volthosting.gg/server/8f2c91
              </span>
            </div>

            <div className="grid grid-cols-[104px_minmax(0,1fr)] sm:grid-cols-[132px_minmax(0,1fr)]">
              {/* sidebar */}
              <div className="border-r border-[#e8f3fc] bg-[#f6fbff] p-2">
                <div className="mb-3 flex items-center gap-1.5 px-1">
                  <span className="grid size-5 place-items-center rounded-md bg-gradient-to-br from-[#1272ff] to-[#0a4fd8] text-[0.5rem] font-bold text-white">
                    V
                  </span>
                  <span className="truncate text-[0.6rem] font-semibold text-ink">
                    SMP · S6
                  </span>
                </div>
                {[
                  { icon: TerminalSquare, label: "Console", active: true },
                  { icon: FolderClosed, label: "Files" },
                  { icon: Archive, label: "Backups" },
                  { icon: CalendarClock, label: "Schedules" },
                  { icon: Users, label: "Users" },
                  { icon: KeyRound, label: "Settings" },
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <div
                      key={item.label}
                      className={[
                        "mb-0.5 flex items-center gap-1.5 rounded-md px-1.5 py-1 text-[0.58rem] font-medium",
                        item.active
                          ? "bg-white text-[#0a4bb0] shadow-sm ring-1 ring-[#e2effa]"
                          : "text-[#6f8ea4]",
                      ].join(" ")}
                    >
                      <Icon className="size-3" />
                      {item.label}
                    </div>
                  );
                })}
                <div className="mt-4 rounded-md border border-[#dcecfa] bg-white/70 p-1.5">
                  <p className="text-[0.5rem] text-[#89a5b8]">Renews in 21 days</p>
                  <p className="mt-0.5 text-[0.55rem] font-semibold text-ink">
                    Glacier plan
                  </p>
                </div>
              </div>

              {/* main */}
              <div className="min-w-0 p-2.5 sm:p-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="live-dot size-1.5 rounded-full bg-[#20b878]" />
                      <span className="text-[0.68rem] font-semibold text-ink">
                        Running
                      </span>
                      <span className="mono truncate text-[0.55rem] text-[#7b98ad]">
                        fra-03
                      </span>
                    </div>
                    <p className="mono mt-1 truncate text-[0.6rem] text-[#3d6f93]">
                      smp-six.fra.volt.gg:25565
                    </p>
                  </div>
                  <button
                    type="button"
                    tabIndex={-1}
                    className="inline-flex items-center gap-1 rounded-md bg-gradient-to-b from-[#1a8cff] to-[#0a63ff] px-2 py-1 text-[0.55rem] font-semibold text-white shadow-sm"
                  >
                    <Play className="size-2.5 fill-current" />
                    Restart
                  </button>
                </div>

                <div className="mt-2.5 grid grid-cols-3 gap-1.5">
                  {[
                    { label: "Memory", value: "2.4 / 4 GB", fill: "58%" },
                    { label: "CPU", value: "38%", fill: "38%" },
                    { label: "NVMe", value: "9.1 / 20 GB", fill: "45%" },
                  ].map((meter) => (
                    <div
                      key={meter.label}
                      className="rounded-md border border-[#e4f0fa] bg-white px-1.5 py-1.5"
                    >
                      <p className="text-[0.48rem] text-[#89a5b8]">{meter.label}</p>
                      <p className="mono mt-0.5 text-[0.54rem] font-semibold text-ink">
                        {meter.value}
                      </p>
                      <div className="mt-1 h-1 overflow-hidden rounded-full bg-[#e8f3fb]">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-[#24a6ff] to-[#0a63ff]"
                          style={{ width: meter.fill }}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-2.5 overflow-hidden rounded-lg border border-[#0a2740]/20 bg-[#061c2e]">
                  <div className="flex items-center justify-between border-b border-white/5 px-2 py-1">
                    <span className="text-[0.5rem] font-medium text-[#7fa9c4]">
                      Live console
                    </span>
                    <span className="mono text-[0.46rem] text-[#4f7f9d]">tailing</span>
                  </div>
                  <div className="space-y-0.5 px-2 py-1.5">
                    {[
                      "[12:04:02] [Server thread/INFO]: Preparing spawn area: 92%",
                      "[12:04:03] [Server thread/INFO]: Done (9.214s)!",
                      "[12:04:09] [Server thread/INFO]: Alex_R joined the game",
                      "[12:04:11] [Server thread/INFO]: Maya joined the game",
                    ].map((line, index) => (
                      <p
                        key={line}
                        className={[
                          "mono truncate text-[0.48rem] leading-[1.5]",
                          index === 1 ? "text-[#7fdcc8]" : "text-[#8fb9d6]",
                        ].join(" ")}
                      >
                        {line}
                      </p>
                    ))}
                    <p className="mono text-[0.48rem] leading-[1.5] text-[#8fb9d6]">
                      &gt; <span className="caret" />
                    </p>
                  </div>
                </div>

                <div className="mt-2 flex flex-wrap gap-1">
                  {["Files", "Backups", "Schedules", "Databases"].map((tab) => (
                    <span
                      key={tab}
                      className="rounded-md border border-[#e4f0fa] bg-white px-1.5 py-0.5 text-[0.5rem] font-medium text-[#5b7f99]"
                    >
                      {tab}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="glass absolute -bottom-4 -left-3 hidden items-center gap-2 rounded-xl px-3 py-2 sm:flex">
          <span className="grid size-6 place-items-center rounded-full bg-[#dff5ea] text-[#177a52]">
            <Check className="size-3.5" strokeWidth={3} />
          </span>
          <div>
            <p className="text-[0.64rem] font-semibold text-ink">Backup complete</p>
            <p className="mono text-[0.54rem] text-mutedblue">04:12 · off-site copy</p>
          </div>
        </div>
      </div>
    </div>
  );
}
