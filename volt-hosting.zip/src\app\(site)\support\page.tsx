import type { Metadata } from "next";
import Link from "next/link";
import {
  ArrowRight,
  ArrowUpRight,
  Clock3,
  CreditCard,
  Gauge,
  LifeBuoy,
  Mail,
  MessagesSquare,
  Server,
  ShieldCheck,
} from "lucide-react";
import { CopyButton } from "@/components/copy-button";
import { getSite } from "@/lib/queries";

export const metadata: Metadata = {
  title: "Support",
  description:
    "Reach the Volt Hosting team by ticket, email or Discord. Real replies, clear response targets, and a status page for the whole network.",
};

const QUEUES = [
  {
    priority: "Urgent",
    example: "Server offline, data unavailable",
    target: "Within 15 minutes",
    tone: "text-[#a13b3b]",
  },
  {
    priority: "High",
    example: "Panel broken, install stuck",
    target: "Within 1 hour",
    tone: "text-[#8a5a12]",
  },
  {
    priority: "Normal",
    example: "Plugin help, billing question",
    target: "Within 4 hours",
    tone: "text-[#0a5fbe]",
  },
  {
    priority: "Low",
    example: "Feature request, pre-sales",
    target: "Next business day",
    tone: "text-mutedblue",
  },
];

const CHECKS = [
  {
    icon: Gauge,
    title: "Check the status board",
    body: "If an entire region is having a moment, the answer is already there — no ticket needed.",
    href: "/status",
    label: "Open status",
  },
  {
    icon: Server,
    title: "Try a panel restart",
    body: "Most stuck installs and unresponsive worlds clear with one stop and start from the panel.",
    href: "/dashboard/servers",
    label: "Your servers",
  },
  {
    icon: CreditCard,
    title: "Review the invoice",
    body: "Declines, renewals and receipts are all visible under billing before you write in.",
    href: "/dashboard/billing",
    label: "Billing",
  },
];

export default function SupportPage() {
  const site = getSite();
  const email = site.supportEmail || "support@volthosting.gg";

  return (
    <>
      <section className="relative overflow-hidden pb-4 pt-8 sm:pt-10">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-32 -top-10 -z-10 size-[30rem] rounded-full bg-[radial-gradient(circle,rgba(86,197,255,0.26),transparent_68%)] blur-2xl"
        />
        <div className="container-x">
          <nav aria-label="Breadcrumb" className="text-[0.72rem] text-mutedblue">
            <Link href="/" className="hover:text-ink">
              Home
            </Link>
            <span className="mx-1.5">/</span>
            <span className="text-ink">Support</span>
          </nav>

          <div className="mt-5 grid items-end gap-8 lg:grid-cols-[1fr_auto]">
            <div>
              <span className="chip">Support</span>
              <h1 className="display mt-3 max-w-[18ch] text-[2.3rem] text-ink sm:text-[3rem]">
                A person reads every ticket.
              </h1>
              <p className="lede mt-4 max-w-[54ch]">
                No phone tree, no copy-pasted articles. Tell us what broke and
                you will get an answer from someone who can actually fix it —
                usually inside the hour.
              </p>
            </div>
            <dl className="grid grid-cols-3 gap-5 lg:gap-7">
              {[
                { value: "8 min", label: "median first reply" },
                { value: "24/7", label: "urgent coverage" },
                { value: "4.9/5", label: "support rating" },
              ].map((stat) => (
                <div key={stat.label}>
                  <dd className="display tabular text-[1.5rem] text-ink">
                    {stat.value}
                  </dd>
                  <dt className="mt-0.5 max-w-[12ch] text-[0.68rem] leading-snug text-mutedblue">
                    {stat.label}
                  </dt>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>

      <section className="section pt-8">
        <div className="container-x grid items-start gap-4 lg:grid-cols-[1.15fr_0.85fr]">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="glass relative overflow-hidden rounded-2xl p-5 sm:col-span-2">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <span className="grid size-10 place-items-center rounded-xl bg-[#e7f2ff] text-[#0a63ff]">
                    <LifeBuoy className="size-5" />
                  </span>
                  <h2 className="display-soft mt-3 text-[1.15rem] text-ink">
                    Open a support ticket
                  </h2>
                  <p className="mt-1 max-w-[48ch] text-[0.8rem] leading-relaxed text-ink-soft/80">
                    The fastest route for anything tied to your account or a
                    server. Attach the server, choose a priority, and the thread
                    stays in your dashboard.
                  </p>
                </div>
                <span className="pill border border-[#dfeaf3] bg-[#f0f5f9] text-[#557289]">
                  Sign-in required
                </span>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <Link href="/dashboard/support/new" className="btn btn-primary btn-sm">
                  New ticket
                  <ArrowRight className="size-4" />
                </Link>
                <Link href="/dashboard/support" className="btn btn-secondary btn-sm">
                  Your tickets
                </Link>
              </div>
            </div>

            <div className="glass rounded-2xl p-5">
              <span className="grid size-10 place-items-center rounded-xl bg-[#e7f2ff] text-[#0a63ff]">
                <Mail className="size-5" />
              </span>
              <h2 className="display-soft mt-3 text-[1.05rem] text-ink">Email us</h2>
              <p className="mt-1 text-[0.78rem] leading-relaxed text-ink-soft/80">
                Best for pre-sales, partnership and migration questions. Include
                your account email if you already have one.
              </p>
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <a
                  href={`mailto:${email}`}
                  className="mono truncate text-[0.76rem] font-medium text-[#0a63ff] hover:underline"
                >
                  {email}
                </a>
                <CopyButton value={email} label="Copy" />
              </div>
            </div>

            <div className="glass rounded-2xl p-5">
              <span className="grid size-10 place-items-center rounded-xl bg-[#eef0ff] text-[#5865f2]">
                <MessagesSquare className="size-5" />
              </span>
              <h2 className="display-soft mt-3 text-[1.05rem] text-ink">
                Community Discord
              </h2>
              <p className="mt-1 text-[0.78rem] leading-relaxed text-ink-soft/80">
                Config help from other owners, announcements, and staff in
                #support. The fastest place to ask “is the panel down for you
                too?”
              </p>
              <a
                href={site.discordInvite || "#"}
                target="_blank"
                rel="noreferrer"
                className="btn btn-secondary btn-sm mt-3"
              >
                Join Discord
                <ArrowUpRight className="size-3.5" />
              </a>
            </div>

            <div className="glass rounded-2xl p-5 sm:col-span-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h2 className="flex items-center gap-1.5 text-[0.9rem] font-semibold text-ink">
                  <Clock3 className="size-4 text-[#0a63ff]" />
                  Response targets
                </h2>
                <span className="text-[0.7rem] text-mutedblue">
                  Targets, not auto-replies
                </span>
              </div>
              <ul className="mt-3 divide-y divide-[#e4f0fa]">
                {QUEUES.map((queue) => (
                  <li
                    key={queue.priority}
                    className="grid gap-1 py-2.5 text-[0.78rem] sm:grid-cols-[7rem_1fr_auto] sm:items-center sm:gap-3"
                  >
                    <span className={`font-semibold ${queue.tone}`}>
                      {queue.priority}
                    </span>
                    <span className="text-ink-soft/80">{queue.example}</span>
                    <span className="tabular text-[0.74rem] text-mutedblue">
                      {queue.target}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <aside className="space-y-3">
            <div className="glass rounded-2xl p-5">
              <h2 className="flex items-center gap-1.5 text-[0.9rem] font-semibold text-ink">
                <ShieldCheck className="size-4 text-[#0a63ff]" />
                Before you write in
              </h2>
              <p className="mt-1 text-[0.74rem] text-mutedblue">
                Three checks that resolve most tickets in under a minute.
              </p>
              <ul className="mt-3 space-y-2.5">
                {CHECKS.map((check) => (
                  <li key={check.title} className="rounded-xl border border-white/90 bg-white/55 p-3">
                    <div className="flex items-center gap-2">
                      <check.icon className="size-3.5 text-[#0a63ff]" />
                      <p className="text-[0.78rem] font-semibold text-ink">
                        {check.title}
                      </p>
                    </div>
                    <p className="mt-1 text-[0.72rem] leading-relaxed text-ink-soft/80">
                      {check.body}
                    </p>
                    <Link
                      href={check.href}
                      className="mt-1.5 inline-flex items-center gap-1 text-[0.7rem] font-medium text-[#0a63ff] hover:underline"
                    >
                      {check.label}
                      <ArrowRight className="size-3" />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl border border-[#cfe6ff] bg-[#eef7ff] p-5">
              <p className="text-[0.8rem] font-semibold text-[#083f72]">
                What to include in a ticket
              </p>
              <ul className="mt-2 space-y-1.5 text-[0.74rem] leading-relaxed text-[#3c6c92]">
                <li>· The server name and region</li>
                <li>· What you expected, and what happened instead</li>
                <li>· The exact error or a screenshot of the panel</li>
                <li>· When it started, and anything you changed just before</li>
              </ul>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}
