import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  AlertTriangle,
  ArrowLeft,
  ArrowUpRight,
  CheckCircle2,
  CreditCard,
  Globe2,
  RotateCcw,
  Server,
  ShieldAlert,
  UserRound,
  XCircle,
} from "lucide-react";
import { StatusPill } from "@/components/status-pill";
import {
  ORDER_STATUS_META,
  SERVER_STATUS_META,
  billingLabel,
  dateTimeLabel,
  money,
  ramLabel,
  diskLabel,
  cpuLabel,
} from "@/lib/format";
import {
  getOrderWithUser,
  getServerByOrderId,
} from "@/lib/queries";
import {
  cancelOrderAction,
  markOrderPaidAction,
  refundOrderAction,
  retryProvisionAction,
} from "@/lib/actions/admin";
import type { Specs } from "@/lib/types";

type PageProps = { params: Promise<{ id: string }> };

const STAGES = ["pending", "paid", "provisioning", "active"] as const;

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const order = getOrderWithUser(id);
  return { title: order ? `Order · ${order.item_name}` : "Order" };
}

function parseSpecs(raw: string): Partial<Specs> {
  try {
    const value = JSON.parse(raw) as Partial<Specs>;
    return value && typeof value === "object" ? value : {};
  } catch {
    return {};
  }
}

export default async function AdminOrderPage({ params }: PageProps) {
  await requireAdmin("/admin/orders");
  const { id } = await params;
  const order = getOrderWithUser(id);
  if (!order) notFound();

  const server = getServerByOrderId(order.id);
  const meta = ORDER_STATUS_META[order.status] ?? ORDER_STATUS_META.pending;
  const specs = parseSpecs(order.specs);
  const stageIndex = STAGES.indexOf(order.status as (typeof STAGES)[number]);
  const settled = Boolean(order.paid_at);

  return (
    <div className="mx-auto max-w-[1120px]">
      <Link
        href="/admin/orders"
        className="inline-flex items-center gap-1.5 text-[0.74rem] font-medium text-mutedblue transition hover:text-ink"
      >
        <ArrowLeft className="size-3.5" />
        Orders
      </Link>

      <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="display text-[1.7rem] leading-tight text-ink sm:text-[2rem]">
              {order.item_name}
            </h1>
            <StatusPill label={meta.label} tone={meta.tone} dot />
          </div>
          <p className="mt-1.5 text-[0.74rem] text-mutedblue">
            {order.server_name} · {order.region} · placed{" "}
            {dateTimeLabel(order.created_at)}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {order.status === "pending" && (
            <form action={markOrderPaidAction}>
              <input type="hidden" name="order_id" value={order.id} />
              <button type="submit" className="btn btn-primary btn-sm">
                <CheckCircle2 className="size-3.5" />
                Mark paid & provision
              </button>
            </form>
          )}
          {order.status === "failed" && (
            <form action={retryProvisionAction}>
              <input type="hidden" name="order_id" value={order.id} />
              <button type="submit" className="btn btn-primary btn-sm">
                <RotateCcw className="size-3.5" />
                Retry provisioning
              </button>
            </form>
          )}
          {["pending", "failed"].includes(order.status) && (
            <form action={cancelOrderAction}>
              <input type="hidden" name="order_id" value={order.id} />
              <button type="submit" className="btn btn-secondary btn-sm">
                <XCircle className="size-3.5" />
                Cancel
              </button>
            </form>
          )}
          {settled && order.status !== "refunded" && (
            <form action={refundOrderAction}>
              <input type="hidden" name="order_id" value={order.id} />
              <button type="submit" className="btn btn-secondary btn-sm">
                <ShieldAlert className="size-3.5" />
                Mark refunded
              </button>
            </form>
          )}
        </div>
      </div>

      {order.provision_error && (
        <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-[#f3c6c6] bg-[#fff5f5] px-3.5 py-3 text-[0.78rem] leading-relaxed text-[#a13b3b]">
          <AlertTriangle className="mt-0.5 size-4 shrink-0" />
          <div>
            <p className="font-semibold">Provisioning failed</p>
            <p className="mt-0.5 whitespace-pre-wrap">{order.provision_error}</p>
          </div>
        </div>
      )}

      <section className="glass mt-4 rounded-2xl p-4">
        <h2 className="text-[0.88rem] font-semibold text-ink">Provisioning state</h2>
        <ol className="mt-3 grid gap-2 sm:grid-cols-4">
          {STAGES.map((stage, index) => {
            const done = stageIndex >= index && stageIndex !== -1;
            const failed = order.status === "failed";
            const current = stageIndex === index;
            return (
              <li
                key={stage}
                className={`rounded-xl border px-3 py-2.5 ${
                  failed && current
                    ? "border-[#f3c6c6] bg-[#fff7f7]"
                    : done
                      ? "border-[#c7e7ff] bg-[#f2f9ff]"
                      : "border-white/90 bg-white/45"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[0.62rem] font-medium uppercase tracking-[0.1em] text-mutedblue">
                    Step {index + 1}
                  </span>
                  {failed && current ? (
                    <XCircle className="size-3.5 text-[#c05a5a]" />
                  ) : done ? (
                    <CheckCircle2 className="size-3.5 text-[#0a63ff]" />
                  ) : (
                    <span className="size-3.5 rounded-full border border-[#c3d6e6]" />
                  )}
                </div>
                <p className="mt-1 text-[0.78rem] font-semibold capitalize text-ink">
                  {stage}
                </p>
              </li>
            );
          })}
        </ol>
        {order.status === "cancelled" && (
          <p className="mt-2 text-[0.72rem] text-mutedblue">
            This order was cancelled before activation.
          </p>
        )}
        {order.status === "refunded" && (
          <p className="mt-2 text-[0.72rem] text-mutedblue">
            Marked refunded. Server suspension is not automatic — suspend it from
            the server page if needed.
          </p>
        )}
      </section>

      <div className="mt-4 grid items-start gap-4 lg:grid-cols-[1.1fr_0.9fr]">
        <div className="space-y-4">
          <section className="glass rounded-2xl p-4">
            <h2 className="text-[0.88rem] font-semibold text-ink">Order details</h2>
            <dl className="mt-3 grid gap-2.5 text-[0.76rem] sm:grid-cols-2">
              {[
                { label: "Order id", value: order.id, mono: true },
                { label: "Customer", value: order.user_name },
                { label: "Email", value: order.user_email },
                {
                  label: "Type",
                  value: order.kind === "custom" ? "Custom build" : "Catalog plan",
                },
                { label: "Term", value: billingLabel(order.billing_months) },
                { label: "Total", value: money(order.amount_cents) },
                ...(order.promo_code
                  ? [
                      {
                        label: "Promo",
                        value: `${order.promo_code} (−${money(order.discount_cents)})`,
                      },
                    ]
                  : []),
                { label: "Method", value: order.gateway_name ?? "—" },
                {
                  label: "Reference",
                  value: order.gateway_ref ?? "—",
                  mono: true,
                },
                { label: "Created", value: dateTimeLabel(order.created_at) },
                {
                  label: "Paid",
                  value: order.paid_at ? dateTimeLabel(order.paid_at) : "Not paid",
                },
              ].map((row) => (
                <div
                  key={row.label}
                  className="rounded-lg border border-white/90 bg-white/50 px-2.5 py-2"
                >
                  <dt className="text-[0.64rem] text-mutedblue">{row.label}</dt>
                  <dd
                    className={`mt-0.5 truncate text-[0.76rem] text-ink ${
                      row.mono ? "mono" : ""
                    }`}
                    title={row.value}
                  >
                    {row.value}
                  </dd>
                </div>
              ))}
            </dl>
          </section>

          <section className="glass rounded-2xl p-4">
            <h2 className="text-[0.88rem] font-semibold text-ink">Allocated specs</h2>
            {order.kind === "custom" ? (
              <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
                {[
                  { label: "Memory", value: specs.ramMb ? ramLabel(specs.ramMb) : "—" },
                  { label: "CPU", value: specs.cpuPct ? cpuLabel(specs.cpuPct) : "—" },
                  { label: "Disk", value: specs.diskMb ? diskLabel(specs.diskMb) : "—" },
                  { label: "Backups", value: specs.backups != null ? `${specs.backups}` : "—" },
                ].map((item) => (
                  <div
                    key={item.label}
                    className="rounded-xl border border-white/90 bg-white/55 px-3 py-2.5"
                  >
                    <p className="text-[0.62rem] text-mutedblue">{item.label}</p>
                    <p className="mono mt-1 text-[0.8rem] font-semibold text-ink">
                      {item.value}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-1.5 text-[0.76rem] leading-relaxed text-ink-soft/80">
                Catalog plan resources are copied from{" "}
                {order.product_id ? (
                  <Link
                    href={`/admin/products/${order.product_id}`}
                    className="font-medium text-[#0a63ff] hover:underline"
                  >
                    the product
                  </Link>
                ) : (
                  "the product"
                )}{" "}
                at provisioning time.
              </p>
            )}
          </section>
        </div>

        <div className="space-y-4">
          <section className="glass rounded-2xl p-4">
            <h2 className="flex items-center gap-1.5 text-[0.88rem] font-semibold text-ink">
              <Server className="size-4 text-[#0a63ff]" />
              Server
            </h2>
            {server ? (
              <div className="mt-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <Link
                    href={`/admin/servers/${server.id}`}
                    className="text-[0.82rem] font-semibold text-ink hover:text-[#0a63ff]"
                  >
                    {server.name}
                  </Link>
                  <StatusPill
                    label={
                      (SERVER_STATUS_META[server.status] ?? SERVER_STATUS_META.offline).label
                    }
                    tone={
                      (SERVER_STATUS_META[server.status] ?? SERVER_STATUS_META.offline).tone
                    }
                    dot
                  />
                </div>
                <p className="mono mt-1 text-[0.74rem] text-mutedblue">
                  {server.ip ? `${server.ip}:${server.port ?? ""}` : "No address"}
                </p>
                <Link
                  href={`/admin/servers/${server.id}`}
                  className="mt-3 inline-flex items-center gap-1 text-[0.74rem] font-semibold text-[#0a63ff] hover:underline"
                >
                  Manage server
                  <ArrowUpRight className="size-3" />
                </Link>
              </div>
            ) : (
              <p className="mt-1.5 text-[0.76rem] leading-relaxed text-ink-soft/80">
                No server row yet. Provisioning creates one when the order is paid.
              </p>
            )}
          </section>

          <section className="glass rounded-2xl p-4">
            <h2 className="flex items-center gap-1.5 text-[0.88rem] font-semibold text-ink">
              <UserRound className="size-4 text-[#0a63ff]" />
              Customer
            </h2>
            <p className="mt-2 text-[0.82rem] font-semibold text-ink">
              {order.user_name}
            </p>
            <p className="text-[0.74rem] text-mutedblue">{order.user_email}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Link href="/admin/users" className="btn btn-secondary btn-sm">
                All customers
              </Link>
              <a
                href={`mailto:${order.user_email}?subject=${encodeURIComponent(
                  `Your Volt order: ${order.server_name}`,
                )}`}
                className="btn btn-secondary btn-sm"
              >
                Email
              </a>
            </div>
          </section>

          <section className="glass-quiet rounded-2xl p-4 text-[0.72rem] leading-relaxed text-ink-soft/85">
            <p className="flex items-center gap-1.5 font-semibold text-ink">
              <Globe2 className="size-3.5 text-[#0a63ff]" />
              Region
            </p>
            <p className="mt-1">{order.region}</p>
            <p className="mt-3 flex items-center gap-1.5 font-semibold text-ink">
              <CreditCard className="size-3.5 text-[#0a63ff]" />
              Settlement
            </p>
            <p className="mt-1">
              {settled
                ? `Paid via ${order.gateway_name ?? "manual entry"}.`
                : "Not settled. Marking paid starts provisioning and emails the customer."}
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
