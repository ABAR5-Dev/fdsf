import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import {
  CircleDollarSign,
  Globe2,
  Mail,
  MessagesSquare,
  ServerCog,
} from "lucide-react";
import {
  DiscordForm,
  PricingForm,
  PterodactylForm,
  SiteSettingsForm,
  SmtpForm,
} from "@/components/app/settings-forms";
import {
  getDiscord,
  getPricing,
  getPterodactyl,
  getSite,
  getSmtp,
} from "@/lib/queries";
import { StatusPill } from "@/components/status-pill";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Settings" };

function Section({
  id,
  icon: Icon,
  title,
  blurb,
  status,
  children,
}: {
  id: string;
  icon: typeof Globe2;
  title: string;
  blurb: string;
  status?: { label: string; tone: "mint" | "slate" | "amber" };
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="glass scroll-mt-24 rounded-2xl p-4 sm:p-5">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <h2 className="flex items-center gap-2 text-[0.95rem] font-semibold text-ink">
            <span className="grid size-7 place-items-center rounded-lg bg-[#e7f2ff] text-[#0a63ff]">
              <Icon className="size-4" />
            </span>
            {title}
          </h2>
          <p className="mt-1.5 max-w-[62ch] text-[0.78rem] leading-relaxed text-ink-soft/80">
            {blurb}
          </p>
        </div>
        {status && <StatusPill label={status.label} tone={status.tone} dot />}
      </div>
      <div className="mt-4">{children}</div>
    </section>
  );
}

export default async function AdminSettingsPage() {
  await requireAdmin("/admin/settings");
  const site = getSite();
  const pricing = getPricing();
  const ptero = getPterodactyl();
  const smtp = getSmtp();
  const discord = getDiscord();

  const panelReady = Boolean(ptero.panelUrl && ptero.apiKey);
  const pteroStatus = ptero.enabled
    ? panelReady
      ? { label: "Live", tone: "mint" as const }
      : { label: "Needs API key", tone: "amber" as const }
    : { label: "Off", tone: "slate" as const };

  return (
    <div className="mx-auto max-w-[1100px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">Settings</h1>
          <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
            Brand, pricing, provisioning, email and community integrations.
          </p>
        </div>
        <nav className="flex flex-wrap gap-1.5">
          {[
            { href: "#site", label: "Site" },
            { href: "#pricing", label: "Pricing" },
            { href: "#pterodactyl", label: "Pterodactyl" },
            { href: "#smtp", label: "Email" },
            { href: "#discord", label: "Discord" },
          ].map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="rounded-full border border-white/90 bg-white/60 px-2.5 py-1 text-[0.7rem] font-medium text-mutedblue transition hover:bg-white hover:text-ink"
            >
              {item.label}
            </a>
          ))}
        </nav>
      </div>

      <div className="mt-5 space-y-4">
        <Section
          id="site"
          icon={Globe2}
          title="Site identity"
          blurb="The name, tagline and links used across the storefront, emails and Discord embeds. The app URL is used to build every link we send."
        >
          <SiteSettingsForm settings={site} />
        </Section>

        <Section
          id="pricing"
          icon={CircleDollarSign}
          title="Custom server pricing"
          blurb="How the build-your-own configurator prices CPU, RAM, NVMe and backup slots. Catalog plans keep their own fixed price."
        >
          <PricingForm settings={pricing} />
        </Section>

        <Section
          id="pterodactyl"
          icon={ServerCog}
          title="Pterodactyl panel"
          blurb="The panel that runs customer servers. Connect it with an application API key and every paid order is created there automatically, with the credentials emailed to the customer."
          status={pteroStatus}
        >
          <PterodactylForm
            settings={{ ...ptero, apiKey: "" }}
            hasApiKey={Boolean(ptero.apiKey)}
          />
        </Section>

        <Section
          id="smtp"
          icon={Mail}
          title="Outgoing email"
          blurb="Server credentials, order receipts and ticket replies go out through this mailbox. When off, messages are recorded as simulated in the email log."
          status={
            smtp.enabled
              ? { label: "Sending", tone: "mint" }
              : { label: "Simulated", tone: "slate" }
          }
        >
          <SmtpForm settings={{ ...smtp, pass: "" }} hasPassword={Boolean(smtp.pass)} />
        </Section>

        <Section
          id="discord"
          icon={MessagesSquare}
          title="Discord webhooks"
          blurb="Post signups, paid orders, pending UPI/GPay orders and new tickets to your community channels with branded embeds. Each event type can target its own webhook, and you can send a test message without waiting for a real customer."
          status={
            discord.enabled
              ? { label: "Posting", tone: "mint" }
              : { label: "Off", tone: "slate" }
          }
        >
          <DiscordForm settings={discord} />
        </Section>
      </div>

      <p className="mt-4 px-1 text-[0.72rem] leading-relaxed text-mutedblue">
        Secrets you save here are stored in the local database and never sent
        back to the browser — leave a masked field blank to keep the saved value.
        Check what was delivered in the{" "}
        <Link href="/admin/email" className="font-medium text-[#0a63ff] hover:underline">
          email log
        </Link>
        .
      </p>
    </div>
  );
}
