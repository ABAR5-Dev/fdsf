"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowRight, Check, Database, Gauge, HardDrive, ShieldCheck } from "lucide-react";
import { BillingTerms } from "@/components/billing-terms";
import { cpuLabel, money, termDiscount, termPrice } from "@/lib/format";
import type { PricingSettings } from "@/lib/types";

type GameOption = { slug: string; name: string; startingAt: string };
export type FeaturedPlan = {
  slug: string;
  name: string;
  price_cents: number;
  ram_mb: number;
  cpu_pct: number;
  disk_mb: number;
  backups: number;
  popular: number;
  category_name: string;
  category_slug: string;
};

export function PlanConfigurator({
  games,
  pricing,
  featured,
}: {
  games: GameOption[];
  pricing: PricingSettings;
  featured: FeaturedPlan[];
}) {
  const [slug, setSlug] = useState(games[0]?.slug ?? "minecraft");
  const [ram, setRam] = useState(4);
  const [cpu, setCpu] = useState(2);
  const [disk, setDisk] = useState(20);
  const [backups, setBackups] = useState(1);
  const [months, setMonths] = useState(1);

  const monthly = Math.round(
    pricing.baseCents +
      ram * pricing.ramPerGbCents +
      cpu * pricing.cpuPerCoreCents +
      disk * pricing.diskPerGbCents +
      backups * pricing.backupCents,
  );
  const total = termPrice(monthly, months, pricing);
  const discount = termDiscount(months, pricing);
  const monthlyOnce = Math.round(total / months);
  const gameName = games.find((game) => game.slug === slug)?.name ?? "Minecraft";

  const href = `/checkout?custom=${slug}&ram=${ram}&cpu=${cpu}&disk=${disk}&backups=${backups}&months=${months}`;

  return (
    <div className="glass rounded-[28px] p-2">
      <div className="grid overflow-hidden rounded-[22px] lg:grid-cols-[1.12fr_0.88fr]">
        <div className="p-5 sm:p-7">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-[0.78rem] font-semibold text-[#0a63ff]">
                Build your own
              </p>
              <h3 className="display-soft mt-1 text-[1.5rem] text-ink sm:text-[1.8rem]">
                Size it to your world.
              </h3>
            </div>
            <span className="chip chip-accent">
              <Gauge className="size-3.5" />
              Live price
            </span>
          </div>

          <div className="mt-5">
            <span className="field-label">Game</span>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {games.map((game) => (
                <button
                  key={game.slug}
                  type="button"
                  onClick={() => setSlug(game.slug)}
                  aria-pressed={slug === game.slug}
                  className={[
                    "rounded-lg border px-2.5 py-1.5 text-[0.76rem] font-semibold transition",
                    slug === game.slug
                      ? "border-[#0a63ff]/25 bg-[#0a63ff] text-white shadow-[0_8px_18px_-12px_rgba(10,99,255,0.9)]"
                      : "border-white/90 bg-white/55 text-ink-soft hover:bg-white/85",
                  ].join(" ")}
                >
                  {game.name}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-5 grid gap-x-6 gap-y-5 sm:grid-cols-2">
            <Slider
              label="Memory"
              value={`${ram} GB`}
              min={2}
              max={32}
              step={1}
              current={ram}
              onChange={setRam}
              hint={`Room for a ${ram > 12 ? "busy network" : "steady community"}`}
            />
            <Slider
              label="vCPU threads"
              value={cpuLabel(cpu * 100)}
              min={1}
              max={8}
              step={1}
              current={cpu}
              onChange={setCpu}
              hint="Pinned, never shared"
            />
            <Slider
              label="NVMe storage"
              value={`${disk} GB`}
              min={10}
              max={200}
              step={5}
              current={disk}
              onChange={setDisk}
              hint="Worlds, plugins, backups"
            />
            <Slider
              label="Backup slots"
              value={`${backups} slot${backups === 1 ? "" : "s"}`}
              min={0}
              max={10}
              step={1}
              current={backups}
              onChange={setBackups}
              hint={backups === 0 ? "Add one before a big update" : "Rolling, off-server"}
            />
          </div>

          <div className="mt-5">
            <span className="field-label">Billing term</span>
            <div className="mt-1.5">
              <BillingTerms
                value={months}
                onChange={setMonths}
                pricing={pricing}
              />
            </div>
          </div>

          <div className="mt-5 flex flex-wrap items-end justify-between gap-3 border-t border-[#d8ebfa]/80 pt-4">
            <div>
              <p className="text-[0.72rem] font-medium text-mutedblue">
                {gameName} · {ram} GB · {cpuLabel(cpu * 100)} · {disk} GB NVMe
              </p>
              <p className="mt-1 flex items-baseline gap-1.5">
                <span className="mono tabular text-[2rem] font-semibold leading-none tracking-[-0.04em] text-ink">
                  {money(monthlyOnce)}
                </span>
                <span className="text-[0.78rem] text-mutedblue">/mo</span>
                {discount > 0 && (
                  <span className="ml-1 rounded-full bg-[#dff5ea] px-1.5 py-0.5 text-[0.65rem] font-bold text-[#177a52]">
                    −{discount}%
                  </span>
                )}
              </p>
              <p className="mono mt-1 text-[0.68rem] text-mutedblue">
                {months === 1
                  ? "billed monthly, cancel anytime"
                  : `${money(total)} every ${months} months`}
              </p>
            </div>
            <Link href={href} className="btn btn-primary">
              Deploy this build
              <ArrowRight className="size-4" />
            </Link>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[0.7rem] text-mutedblue">
            <span className="inline-flex items-center gap-1">
              <ShieldCheck className="size-3.5 text-[#20a06a]" /> 72-hour guarantee
            </span>
            <span className="inline-flex items-center gap-1">
              <Check className="size-3.5 text-[#0a63ff]" /> No setup fee
            </span>
            <span className="inline-flex items-center gap-1">
              <Database className="size-3.5 text-[#0a63ff]" /> Free world migration
            </span>
          </div>
        </div>

        <div className="border-t border-white/80 bg-[rgba(255,255,255,0.5)] p-5 sm:p-6 lg:border-l lg:border-t-0">
          <div className="flex items-center justify-between">
            <h4 className="text-[0.92rem] font-semibold text-ink">Ready-made plans</h4>
            <span className="text-[0.7rem] text-mutedblue">most deployed</span>
          </div>
          <div className="mt-3 divide-y divide-[#dcecfa]">
            {featured.map((plan) => (
              <Link
                key={plan.slug}
                href={`/checkout?product=${encodeURIComponent(plan.slug)}`}
                className="group flex items-center gap-3 py-3 transition first:pt-1"
              >
                <span className="grid size-9 shrink-0 place-items-center rounded-[10px] bg-white/80 text-[#0a63ff] ring-1 ring-white/90">
                  <HardDrive className="size-4" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-1.5">
                    <span className="truncate text-[0.84rem] font-semibold text-ink">
                      {plan.name}
                    </span>
                    {plan.popular === 1 && (
                      <span className="rounded-full bg-[#dff1ff] px-1.5 py-0.5 text-[0.58rem] font-bold text-[#0a4bb0]">
                        popular
                      </span>
                    )}
                  </span>
                  <span className="mt-0.5 block truncate text-[0.7rem] text-mutedblue">
                    {plan.category_name} · {plan.ram_mb / 1024} GB · {cpuLabel(plan.cpu_pct)} ·{" "}
                    {plan.disk_mb / 1024} GB NVMe
                  </span>
                </span>
                <span className="shrink-0 text-right">
                  <span className="mono block text-[0.82rem] font-semibold text-ink">
                    {money(plan.price_cents)}
                  </span>
                  <span className="text-[0.6rem] text-mutedblue">per month</span>
                </span>
                <ArrowRight className="size-3.5 shrink-0 text-[#9fbed4] transition group-hover:translate-x-0.5 group-hover:text-[#0a63ff]" />
              </Link>
            ))}
            {featured.length === 0 && (
              <p className="py-6 text-sm text-mutedblue">
                Plans are being restocked. Build a custom server in the meantime.
              </p>
            )}
          </div>

          <div className="mt-4 rounded-xl border border-white/90 bg-white/60 p-3">
            <p className="flex items-center gap-2 text-[0.75rem] font-semibold text-ink">
              <span className="live-dot size-1.5 rounded-full bg-[#20b878]" />
              Instant provisioning
            </p>
            <p className="mt-1 text-[0.72rem] leading-relaxed text-mutedblue">
              Your panel login and server address arrive by email, usually inside
              90 seconds of payment.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step,
  current,
  onChange,
  hint,
}: {
  label: string;
  value: string;
  min: number;
  max: number;
  step: number;
  current: number;
  onChange: (value: number) => void;
  hint: string;
}) {
  const fill = `${((current - min) / (max - min)) * 100}%`;
  return (
    <label className="block">
      <span className="flex items-baseline justify-between gap-2">
        <span className="field-label">{label}</span>
        <span className="mono text-[0.78rem] font-semibold text-ink">{value}</span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={current}
        onChange={(event) => onChange(Number(event.target.value))}
        className="range mt-2.5"
        style={{ "--range-fill": fill } as React.CSSProperties}
        aria-label={label}
      />
      <span className="mt-1 block text-[0.66rem] text-mutedblue">{hint}</span>
    </label>
  );
}
