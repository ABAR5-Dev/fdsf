import { getDiscord, getSite } from "./queries";

type EventKind = "signup" | "purchase" | "pending" | "ticket" | "test";

export type DiscordPayload = {
  title: string;
  description?: string;
  color?: number;
  url?: string;
  fields?: { name: string; value: string; inline?: boolean }[];
  thumbnail?: string;
  image?: string;
  footer?: string;
};

export type DiscordResult = {
  ok: boolean;
  skipped?: boolean;
  error?: string;
};

const COLORS = {
  signup: 0x1bb7ff,
  purchase: 0x10b981,
  pending: 0xf59e0b,
  ticket: 0x6366f1,
  test: 0x0a63ff,
} as const;

const EVENT_LABEL: Record<EventKind, string> = {
  signup: "New account",
  purchase: "Order paid",
  pending: "Awaiting payment",
  ticket: "Support ticket",
  test: "Webhook test",
};

function webhookFor(kind: EventKind): string {
  const discord = getDiscord();
  if (kind === "signup") return discord.signupWebhook;
  if (kind === "purchase" || kind === "pending") return discord.purchaseWebhook;
  return discord.ticketWebhook;
}

function clip(value: string, max = 1000): string {
  const text = value.trim();
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function buildEmbed(kind: EventKind, payload: DiscordPayload) {
  const site = getSite();
  const discord = getDiscord();
  const icon = discord.iconUrl.trim();

  return {
    author: {
      name: site.siteName,
      ...(icon ? { icon_url: icon } : {}),
      ...(site.appUrl.startsWith("http") ? { url: site.appUrl } : {}),
    },
    title: payload.title,
    ...(payload.description ? { description: clip(payload.description, 1800) } : {}),
    ...(payload.url ? { url: payload.url } : {}),
    color: payload.color ?? COLORS[kind],
    ...(payload.thumbnail ? { thumbnail: { url: payload.thumbnail } } : {}),
    ...(payload.image ? { image: { url: payload.image } } : {}),
    fields: (payload.fields ?? [])
      .filter((field) => field.value && field.value.trim().length > 0)
      .slice(0, 25)
      .map((field) => ({
        name: clip(field.name, 256),
        value: clip(field.value, 1024),
        inline: Boolean(field.inline),
      })),
    footer: {
      text: `${site.siteName} · ${payload.footer ?? EVENT_LABEL[kind]}`,
      ...(icon ? { icon_url: icon } : {}),
    },
    timestamp: new Date().toISOString(),
  };
}

async function post(
  url: string,
  kind: EventKind,
  embed: Record<string, unknown>,
): Promise<DiscordResult> {
  const discord = getDiscord();
  const site = getSite();

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: discord.username || site.siteName,
        ...(discord.iconUrl.trim() ? { avatar_url: discord.iconUrl.trim() } : {}),
        embeds: [embed],
        allowed_mentions: { parse: [] },
      }),
      cache: "no-store",
    });
    if (!response.ok) {
      let detail = "";
      try {
        const body = (await response.json()) as {
          message?: string;
          embeds?: string[];
        };
        detail = body.message ?? body.embeds?.[0] ?? "";
      } catch {
        // Discord sometimes returns an empty body.
      }
      return {
        ok: false,
        error: detail || `Discord returned ${response.status}`,
      };
    }
    return { ok: true };
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Unknown Discord error";
    console.error("[discord] webhook failed:", kind, message);
    return { ok: false, error: message };
  }
}

export async function sendDiscordEvent(
  kind: EventKind,
  payload: DiscordPayload,
  options?: { url?: string; force?: boolean },
): Promise<DiscordResult> {
  const discord = getDiscord();
  if (!discord.enabled && !options?.force) return { ok: true, skipped: true };

  const url = options?.url ?? webhookFor(kind);
  if (!url) return { ok: true, skipped: true };

  return post(url, kind, buildEmbed(kind, payload));
}

export function notifySignup(input: { name: string; email: string }) {
  const site = getSite();
  return sendDiscordEvent("signup", {
    title: "A new account just landed",
    description: `**${input.name}** joined ${site.siteName}.`,
    fields: [
      { name: "Customer", value: input.name, inline: true },
      { name: "Email", value: input.email, inline: true },
      { name: "Next step", value: "Browse the store", inline: true },
    ],
  });
}

export function notifyPurchase(input: {
  orderId: string;
  customer: string;
  email: string;
  item: string;
  amount: string;
  gateway?: string;
  server?: string;
  location?: string;
  discount?: string;
}) {
  const site = getSite();
  const fields = [
    { name: "Order", value: `#${input.orderId.slice(0, 8).toUpperCase()}`, inline: true },
    { name: "Total", value: input.amount, inline: true },
    { name: "Payment", value: input.gateway || "—", inline: true },
    { name: "Server", value: input.server || "Provisioning", inline: true },
    { name: "Location", value: input.location || "—", inline: true },
    { name: "Email", value: input.email, inline: false },
  ];
  if (input.discount) {
    fields.splice(2, 0, { name: "Discount", value: input.discount, inline: true });
  }

  return sendDiscordEvent("purchase", {
    title: "Order paid",
    description: `**${input.item}** was purchased by **${input.customer}**.`,
    url: `${site.appUrl}/admin/orders/${input.orderId}`,
    fields,
    footer: "Order paid",
  });
}

export function notifyPendingOrder(input: {
  orderId: string;
  customer: string;
  email: string;
  item: string;
  amount: string;
  method: string;
  instructions?: string;
}) {
  const site = getSite();
  return sendDiscordEvent("pending", {
    title: "New order awaiting payment",
    description: `**${input.customer}** placed an order and needs **${input.method}** payment details.`,
    url: `${site.appUrl}/admin/orders/${input.orderId}`,
    fields: [
      { name: "Order", value: `#${input.orderId.slice(0, 8).toUpperCase()}`, inline: true },
      { name: "Total", value: input.amount, inline: true },
      { name: "Method", value: input.method, inline: true },
      { name: "Item", value: input.item, inline: false },
      { name: "Email", value: input.email, inline: true },
      ...(input.instructions
        ? [{ name: "What the customer was told", value: input.instructions }]
        : []),
    ],
    footer: "Awaiting payment",
  });
}

export function notifyTicket(input: {
  ticketId: string;
  subject: string;
  customer: string;
  priority: string;
  message: string;
}) {
  return sendDiscordEvent("ticket", {
    title: "New support ticket",
    description: `**${input.subject}**`,
    fields: [
      { name: "Customer", value: input.customer, inline: true },
      { name: "Priority", value: input.priority, inline: true },
      { name: "Ticket", value: `#${input.ticketId.slice(0, 8).toUpperCase()}`, inline: true },
      { name: "Message", value: input.message, inline: false },
    ],
  });
}

export async function sendDiscordTest(
  kind: "signup" | "purchase" | "ticket",
): Promise<DiscordResult> {
  const site = getSite();
  const url = webhookFor(kind);
  if (!url) {
    return { ok: false, error: "Add a webhook URL for this event first." };
  }

  const frames: Record<typeof kind, DiscordPayload> = {
    signup: {
      title: "A new account just landed",
      description: `**Alex Rivera** joined ${site.siteName}.`,
      fields: [
        { name: "Customer", value: "Alex Rivera", inline: true },
        { name: "Email", value: "alex@example.com", inline: true },
        { name: "Next step", value: "Browse the store", inline: true },
      ],
      footer: "Test notification — signups",
    },
    purchase: {
      title: "Order paid",
      description: "**Minecraft Obsidian — 8 GB** was purchased by **Alex Rivera**.",
      fields: [
        { name: "Order", value: "#A1B2C3D4", inline: true },
        { name: "Total", value: "$17.91", inline: true },
        { name: "Payment", value: "UPI, GPay & more", inline: true },
        { name: "Server", value: "obsidian-smp", inline: true },
        { name: "Location", value: "Frankfurt", inline: true },
      ],
      footer: "Test notification — purchases",
    },
    ticket: {
      title: "New support ticket",
      description: "**Server keeps restarting after 10 minutes**",
      fields: [
        { name: "Customer", value: "Alex Rivera", inline: true },
        { name: "Priority", value: "High", inline: true },
        { name: "Ticket", value: "#9F8E7D6C", inline: true },
        {
          name: "Message",
          value: "The console shows a watchdog timeout right before each restart.",
          inline: false,
        },
      ],
      footer: "Test notification — tickets",
    },
  };

  return sendDiscordEvent(kind, frames[kind], { url, force: true });
}
