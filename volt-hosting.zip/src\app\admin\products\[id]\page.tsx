import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ExternalLink } from "lucide-react";
import { ProductForm } from "@/components/app/product-form";
import { StatusPill } from "@/components/status-pill";
import { dateLabel } from "@/lib/format";
import { getCategories, getProductById } from "@/lib/queries";

type PageProps = { params: Promise<{ id: string }> };

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const product = getProductById(id);
  return { title: product?.name ?? "Product" };
}

export default async function EditProductPage({ params }: PageProps) {
  await requireAdmin("/admin/products");
  const { id } = await params;
  const product = getProductById(id);
  if (!product) notFound();

  const categories = getCategories();

  return (
    <div className="mx-auto max-w-[960px]">
      <Link
        href="/admin/products"
        className="inline-flex items-center gap-1.5 text-[0.74rem] font-medium text-mutedblue transition hover:text-ink"
      >
        <ArrowLeft className="size-3.5" />
        Products
      </Link>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <h1 className="display text-[1.8rem] text-ink sm:text-[2.1rem]">
            {product.name}
          </h1>
          <StatusPill
            label={product.active === 1 ? "Live" : "Hidden"}
            tone={product.active === 1 ? "mint" : "slate"}
            dot
          />
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[0.72rem] text-mutedblue">
            Created {dateLabel(product.created_at)}
          </span>
          {product.active === 1 && (
            <Link
              href={`/checkout?product=${product.slug}`}
              target="_blank"
              className="btn btn-secondary btn-sm"
            >
              Preview checkout
              <ExternalLink className="size-3.5" />
            </Link>
          )}
        </div>
      </div>

      <div className="mt-5">
        <ProductForm product={product} categories={categories} />
      </div>
    </div>
  );
}
