"use client";

import { useState } from "react";
import { Eye, EyeOff, ExternalLink, KeyRound } from "lucide-react";
import { CopyButton } from "@/components/copy-button";

export function CredentialCard({
  panelUrl,
  username,
  password,
}: {
  panelUrl: string;
  username: string;
  password: string | null | undefined;
}) {
  const [visible, setVisible] = useState(false);
  const masked = password ? "•".repeat(Math.min(16, Math.max(8, password.length))) : "Not set";

  return (
    <div className="glass rounded-2xl p-4">
      <div className="flex items-center justify-between gap-2">
        <h2 className="flex items-center gap-1.5 text-[0.9rem] font-semibold text-ink">
          <KeyRound className="size-4 text-[#0a63ff]" />
          Panel access
        </h2>
        <a
          href={panelUrl}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1 text-[0.74rem] font-semibold text-[#0a63ff] hover:underline"
        >
          Open panel
          <ExternalLink className="size-3" />
        </a>
      </div>

      <dl className="mt-3 space-y-2">
        <div>
          <dt className="text-[0.64rem] font-medium text-mutedblue">Panel URL</dt>
          <dd className="mt-0.5 flex items-center gap-1.5">
            <code className="mono min-w-0 flex-1 truncate rounded-md border border-white/90 bg-white/65 px-2 py-1.5 text-[0.72rem] text-[#2b5270]">
              {panelUrl}
            </code>
            <CopyButton value={panelUrl} />
          </dd>
        </div>

        <div>
          <dt className="text-[0.64rem] font-medium text-mutedblue">Username</dt>
          <dd className="mt-0.5 flex items-center gap-1.5">
            <code className="mono min-w-0 flex-1 truncate rounded-md border border-white/90 bg-white/65 px-2 py-1.5 text-[0.72rem] text-[#2b5270]">
              {username}
            </code>
            <CopyButton value={username} />
          </dd>
        </div>

        <div>
          <dt className="text-[0.64rem] font-medium text-mutedblue">Password</dt>
          <dd className="mt-0.5 flex items-center gap-1.5">
            <code className="mono min-w-0 flex-1 truncate rounded-md border border-white/90 bg-white/65 px-2 py-1.5 text-[0.72rem] text-[#2b5270]">
              {visible ? password || "Not set" : masked}
            </code>
            <button
              type="button"
              onClick={() => setVisible((current) => !current)}
              aria-label={visible ? "Hide password" : "Show password"}
              aria-pressed={visible}
              disabled={!password}
              className="inline-flex items-center gap-1 rounded-md border border-white/90 bg-white/70 px-1.5 py-1 text-[0.66rem] font-medium text-ink-soft transition hover:bg-white hover:text-ink disabled:opacity-50"
            >
              {visible ? <EyeOff className="size-3" /> : <Eye className="size-3" />}
              {visible ? "Hide" : "Show"}
            </button>
            {password && <CopyButton value={password} />}
          </dd>
        </div>
      </dl>

      <p className="mt-3 text-[0.68rem] leading-relaxed text-mutedblue">
        These are the same credentials that were emailed at provisioning. Change
        the password inside the panel if you share this screen.
      </p>
    </div>
  );
}
