import type { Metadata } from "next";
import { Suspense } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Lock, MessageSquare, ShieldCheck } from "lucide-react";
import {
  CheckoutForm,
  type CheckoutConfig,
  type CheckoutGateway,
} from "@/components/checkout/checkout-form";
import { getCurrentUser } from "@/lib/auth";
import {
  getCategoryBySlug,
  getGateways,
  getPayments,
  getPricing,
  getProductBySlug,
} from "@/lib/queries";
import { calculateCustomCents, specsFromProduct } from "@/lib/format";
import type { Specs } from "@/lib/types";

export const metadata: Metadata = {
  title: "Checkout",
  description: "Review your server and complete your order.",
  robots: { index: false },
};

type Params = Record<string, string | string[] | undefined>;
type PageProps = { searchParams: Promise<Params> };

function first(value: string | string[] | undefined): string | undefined {
  if (Array.isArray(value)) return value[0];
  return value;
}

function clamp(value: number, min: number, max: number) {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, Math.round(value)));
}

export default function CheckoutPage({ searchParams }: PageProps) {
  return (
    <Suspense fallback={<CheckoutSkeleton />}>
      <CheckoutGate searchParams={searchParams} />
    </Suspense>
  );
}

async function CheckoutGate({ searchParams }: PageProps) {
  const params = await searchParams;
  const productSlug = first(params.product);
  const customSlug = first(params.custom);

  if (!productSlug && !customSlug) redirect("/store");

  const rawQuery = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    const single = first(value);
    if (single) rawQuery.set(key, single);
  }
  const checkoutPath = `/checkout?${rawQuery.toString()}`;

  const user = await getCurrentUser();
  if (!user) {
    redirect(`/login?next=${encodeURIComponent(checkoutPath)}`);
  }

  const payments = getPayments();
  const pricing = getPricing();
  const monthsRaw = Number(first(params.months) ?? 1);
  const months = [1, 3, 12].includes(monthsRaw) ? monthsRaw : 1;
  const cancelled = first(params.cancelled) === "1";

  let config: CheckoutConfig | null = null;

  if (productSlug) {
    const product = getProductBySlug(productSlug);
    if (!product || product.active !== 1) redirect("/store");
    config = {
      kind: "product",
      productSlug: product.slug,
      categorySlug: product.category_slug,
      categoryName: product.category_name,
      itemName: `${product.name} — ${product.category_name}`,
      description: product.description,
      serverName: first(params.name)?.slice(0, 48) || product.slug,
      monthlyCents: product.price_cents,
      months,
      specs: specsFromProduct(product),
    };
  } else if (customSlug) {
    const category = getCategoryBySlug(customSlug);
    if (!category || category.active !== 1) redirect("/store");
    const specs: Specs = {
      ramMb: clamp(Number(first(params.ram) ?? 4), 1, 32) * 1024,
      cpuPct: clamp(Number(first(params.cpu) ?? 2), 1, 8) * 100,
      diskMb: clamp(Number(first(params.disk) ?? 20), 5, 200) * 1024,
      backups: clamp(Number(first(params.backups) ?? 1), 0, 10),
      databases: 1,
      allocations: 1,
      players: 0,
    };
    specs.databases = Math.max(1, Math.min(5, Math.ceil(specs.ramMb / 4096)));
    specs.allocations = Math.max(1, Math.min(5, Math.ceil(specs.ramMb / 8192)));
    config = {
      kind: "custom",
      productSlug: "",
      categorySlug: category.slug,
      categoryName: category.name,
      itemName: `${category.name} custom build`,
      description:
        "A build sized by you. Change the sliders here or from your dashboard later.",
      serverName: first(params.name)?.slice(0, 48) || `${category.slug}-custom`,
      monthlyCents: calculateCustomCents(specs, pricing),
      months,
      specs,
    };
  }

  if (!config) redirect("/store");

  const gateways: CheckoutGateway[] = getGateways({ enabledOnly: true }).map(
    (gateway) => ({
      id: gateway.id,
      name: gateway.name,
      type: gateway.type,
      description: gateway.description,
    }),
  );

  return (
    <div className="container-x py-8">
      <nav aria-label="Breadcrumb" className="text-[0.72rem] text-mutedblue">
        <Link href="/" className="hover:text-ink">
          Home
        </Link>
        <span className="mx-1.5">/</span>
        <Link href="/store" className="hover:text-ink">
          Store
        </Link>
        <span className="mx-1.5">/</span>
        <Link
          href={`/store/${config.categorySlug}`}
          className="hover:text-ink"
        >
          {config.categoryName}
        </Link>
        <span className="mx-1.5">/</span>
        <span className="text-ink">Checkout</span>
      </nav>

      <div className="mt-4 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[2rem] text-ink sm:text-[2.5rem]">
            Review and deploy.
          </h1>
          <p className="mt-2 max-w-[52ch] text-[0.86rem] leading-relaxed text-ink-soft/80">
            Signed in as <span className="font-medium text-ink">{user.email}</span>.
            Payment starts provisioning immediately — no manual step after this.
          </p>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-white/90 bg-white/60 px-3 py-1.5 text-[0.72rem] text-ink-soft">
          <ShieldCheck className="size-3.5 text-[#0a8f5b]" />
          Secure checkout
        </span>
      </div>

      <div className="mt-6">
        {!payments.enabled ? (
          <div className="glass rounded-2xl p-6">
            <span className="grid size-10 place-items-center rounded-xl bg-[#fff4e5] text-[#b26a12]">
              <Lock className="size-5" />
            </span>
            <h2 className="display-soft mt-4 text-[1.2rem] text-ink">
              Checkout is paused.
            </h2>
            <p className="mt-2 max-w-[56ch] text-[0.84rem] leading-relaxed text-ink-soft/85">
              We have temporarily stopped new orders while we work on the
              platform. Nothing in your cart is lost — come back in a little
              while, or open a ticket and we will hold a slot for you.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              <Link href="/support" className="btn btn-primary btn-sm">
                <MessageSquare className="size-4" />
                Open a ticket
              </Link>
              <Link href="/store" className="btn btn-secondary btn-sm">
                Back to store
              </Link>
            </div>
          </div>
        ) : gateways.length === 0 ? (
          <div className="glass rounded-2xl p-6">
            <h2 className="display-soft text-[1.2rem] text-ink">
              No payment methods are configured.
            </h2>
            <p className="mt-2 max-w-[56ch] text-[0.84rem] leading-relaxed text-ink-soft/85">
              An administrator still needs to enable a gateway. Open a ticket and
              we can take the order manually.
            </p>
            <Link href="/support" className="btn btn-secondary btn-sm mt-4">
              Contact support
            </Link>
          </div>
        ) : (
          <CheckoutForm
            config={config}
            pricing={pricing}
            gateways={gateways}
            note={payments.note}
            cancelled={cancelled}
          />
        )}
      </div>
    </div>
  );
}

function CheckoutSkeleton() {
  return (
    <div className="container-x py-8">
      <div className="h-3 w-48 animate-pulse rounded bg-white/60" />
      <div className="mt-5 h-9 w-72 animate-pulse rounded-lg bg-white/80" />
      <div className="mt-3 h-3.5 w-96 max-w-full animate-pulse rounded bg-white/60" />
      <div className="mt-7 grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
        <div className="space-y-4">
          <div className="h-56 animate-pulse rounded-2xl bg-white/60" />
          <div className="h-32 animate-pulse rounded-2xl bg-white/60" />
          <div className="h-48 animate-pulse rounded-2xl bg-white/60" />
        </div>
        <div className="h-80 animate-pulse rounded-2xl bg-white/60" />
      </div>
    </div>
  );
}
