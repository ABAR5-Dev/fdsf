import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import {
  ArrowLeft,
  CalendarClock,
  Cpu,
  Database,
  ExternalLink,
  Globe2,
  HardDrive,
  MemoryStick,
  MessageSquare,
  RefreshCw,
  Server,
  ShieldCheck,
  Timer,
} from "lucide-react";
import { CopyButton } from "@/components/copy-button";
import { CredentialCard } from "@/components/app/credential-card";
import { StatusPill } from "@/components/status-pill";
import { getCurrentUser } from "@/lib/auth";
import { decryptSecret } from "@/lib/crypto";
import {
  SERVER_STATUS_META,
  cpuLabel,
  dateLabel,
  diskLabel,
  relativeTime,
  ramLabel,
} from "@/lib/format";
import { getPterodactyl, getServerForUser } from "@/lib/queries";
import { syncServerStatus } from "@/lib/provision";
import { refreshServerAction } from "@/lib/actions/servers";

type PageProps = { params: Promise<{ id: string }> };

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const user = await getCurrentUser();
  if (!user) return { title: "Server" };
  const server = getServerForUser(id, user.id);
  return { title: server?.name ?? "Server" };
}

export default async function ServerDetailPage({ params }: PageProps) {
  const { id } = await params;
  const user = await getCurrentUser();
  if (!user) redirect(`/login?next=/dashboard/servers/${id}`);

  const server = getServerForUser(id, user.id);
  if (!server) notFound();

  await syncServerStatus(server.id);
  const fresh = getServerForUser(id, user.id) ?? server;
  const pterodactyl = getPterodactyl();
  const password = decryptSecret(fresh.panel_password_enc);
  const meta = SERVER_STATUS_META[fresh.status] ?? SERVER_STATUS_META.offline;
  const address = fresh.ip
    ? `${fresh.ip}${fresh.port ? `:${fresh.port}` : ""}`
    : "Assigning…";

  return (
    <div className="mx-auto max-w-[1120px]">
      <Link
        href="/dashboard/servers"
        className="inline-flex items-center gap-1.5 text-[0.74rem] font-medium text-mutedblue transition hover:text-ink"
      >
        <ArrowLeft className="size-3.5" />
        All servers
      </Link>

      <div className="mt-3 flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="display text-[1.8rem] text-ink sm:text-[2.1rem]">
              {fresh.name}
            </h1>
            <StatusPill label={meta.label} tone={meta.tone} dot />
          </div>
          <p className="mt-1 text-[0.78rem] text-mutedblue">
            {fresh.region} · created {relativeTime(fresh.created_at)}
            {fresh.last_synced_at
              ? ` · synced ${relativeTime(fresh.last_synced_at)}`
              : ""}
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <form action={refreshServerAction}>
            <input type="hidden" name="server_id" value={fresh.id} />
            <button type="submit" className="btn btn-secondary btn-sm">
              <RefreshCw className="size-3.5" />
              Refresh status
            </button>
          </form>
          <a
            href={pterodactyl.panelUrl}
            target="_blank"
            rel="noreferrer"
            className="btn btn-primary btn-sm"
          >
            Open control panel
            <ExternalLink className="size-3.5" />
          </a>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-2 rounded-2xl border border-white/90 bg-white/55 px-3 py-2.5">
        <Globe2 className="size-4 text-[#0a63ff]" />
        <span className="text-[0.7rem] font-medium text-mutedblue">
          Server address
        </span>
        <code className="mono min-w-0 flex-1 truncate text-[0.8rem] font-semibold text-ink">
          {address}
        </code>
        {fresh.ip && <CopyButton value={address} label="Copy address" />}
      </div>

      {fresh.status === "installing" && (
        <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-[#f5e2c0] bg-[#fff8eb] px-3.5 py-3 text-[0.78rem] leading-relaxed text-[#7d5410]">
          <Timer className="mt-0.5 size-4 shrink-0" />
          The container is installing. This usually takes 45–90 seconds; the
          address above is already reserved for you.
        </div>
      )}

      <div className="mt-5 grid items-start gap-4 lg:grid-cols-[1.15fr_0.85fr]">
        <div className="space-y-4">
          <section className="glass rounded-2xl p-4">
            <h2 className="text-[0.9rem] font-semibold text-ink">Allocated resources</h2>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
              {[
                { icon: MemoryStick, label: "Memory", value: ramLabel(fresh.ram_mb) },
                { icon: Cpu, label: "CPU", value: cpuLabel(fresh.cpu_pct) },
                { icon: HardDrive, label: "NVMe", value: diskLabel(fresh.disk_mb) },
                {
                  icon: Database,
                  label: "Backups",
                  value: `${fresh.backups} slot${fresh.backups === 1 ? "" : "s"}`,
                },
                { icon: Database, label: "Databases", value: String(fresh.databases) },
                {
                  icon: Globe2,
                  label: "Allocations",
                  value: String(fresh.allocations),
                },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.label}
                    className="rounded-xl border border-white/90 bg-white/55 px-3 py-2.5"
                  >
                    <dt className="flex items-center gap-1 text-[0.64rem] text-mutedblue">
                      <Icon className="size-3" />
                      {item.label}
                    </dt>
                    <dd className="mono mt-1 text-[0.82rem] font-semibold text-ink">
                      {item.value}
                    </dd>
                  </div>
                );
              })}
            </div>
          </section>

          <section className="glass rounded-2xl p-4">
            <h2 className="text-[0.9rem] font-semibold text-ink">What lives here</h2>
            <p className="mt-1 text-[0.78rem] leading-relaxed text-ink-soft/80">
              Files, backups and scheduled tasks are managed inside the panel.
              This page keeps the billing and provisioning view in one place.
            </p>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {[
                {
                  title: "File manager & SFTP",
                  body: "Upload plugins and modpacks without a desktop client.",
                },
                {
                  title: "Backups",
                  body: `${fresh.backups} slot${fresh.backups === 1 ? "" : "s"} included. Snapshot before updates.`,
                },
                {
                  title: "Schedules",
                  body: "Cron-style restarts and command runs.",
                },
                {
                  title: "Subusers",
                  body: "Invite moderators with scoped permissions.",
                },
              ].map((item) => (
                <div
                  key={item.title}
                  className="rounded-xl border border-white/90 bg-white/45 px-3 py-2.5"
                >
                  <p className="text-[0.76rem] font-semibold text-ink">
                    {item.title}
                  </p>
                  <p className="mt-0.5 text-[0.7rem] leading-relaxed text-ink-soft/80">
                    {item.body}
                  </p>
                </div>
              ))}
            </div>
            <a
              href={pterodactyl.panelUrl}
              target="_blank"
              rel="noreferrer"
              className="mt-3 inline-flex items-center gap-1 text-[0.76rem] font-semibold text-[#0a63ff] hover:underline"
            >
              Open these in the panel
              <ExternalLink className="size-3" />
            </a>
          </section>
        </div>

        <div className="space-y-4">
          <CredentialCard
            panelUrl={pterodactyl.panelUrl}
            username={fresh.panel_username || user.email}
            password={password || ""}
          />

          <section className="glass rounded-2xl p-4">
            <h2 className="text-[0.9rem] font-semibold text-ink">Service details</h2>
            <dl className="mt-3 space-y-2 text-[0.76rem]">
              <div className="flex items-center justify-between gap-3">
                <dt className="flex items-center gap-1.5 text-mutedblue">
                  <CalendarClock className="size-3.5" />
                  Renews
                </dt>
                <dd className="text-ink">
                  {fresh.renewal_at ? dateLabel(fresh.renewal_at) : "—"}
                </dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="flex items-center gap-1.5 text-mutedblue">
                  <ShieldCheck className="size-3.5" />
                  Protection
                </dt>
                <dd className="text-ink">Game-aware DDoS</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="flex items-center gap-1.5 text-mutedblue">
                  <Globe2 className="size-3.5" />
                  Location
                </dt>
                <dd className="text-ink">{fresh.region}</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="flex items-center gap-1.5 text-mutedblue">
                  <Server className="size-3.5" />
                  Identifier
                </dt>
                <dd className="mono text-ink">{fresh.identifier || "—"}</dd>
              </div>
            </dl>
            <Link
              href="/dashboard/billing"
              className="mt-3 inline-flex items-center gap-1 text-[0.74rem] font-semibold text-[#0a63ff] hover:underline"
            >
              View invoices
            </Link>
          </section>

          <div className="glass rounded-2xl p-4">
            <h2 className="display-soft text-[1rem] text-ink">Something not right?</h2>
            <p className="mt-1 text-[0.74rem] leading-relaxed text-ink-soft/80">
              Mention the server name and we can look at the node directly.
            </p>
            <Link
              href={`/dashboard/support/new?server=${encodeURIComponent(fresh.name)}`}
              className="btn btn-secondary btn-sm mt-3 w-full"
            >
              <MessageSquare className="size-3.5" />
              Open a ticket
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
