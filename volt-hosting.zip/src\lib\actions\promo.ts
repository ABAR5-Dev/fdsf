"use server";

import { getCurrentUser } from "../auth";
import { evaluatePromo } from "../promo";
import type { PromoKind } from "../types";

export type PromoPreview =
  | {
      ok: true;
      code: string;
      kind: PromoKind;
      value: number;
      minCents: number;
      discountCents: number;
      description: string;
    }
  | { ok: false; error: string };

export async function previewPromoAction(
  code: string,
  subtotalCents: number,
): Promise<PromoPreview> {
  const user = await getCurrentUser();
  if (!user) return { ok: false, error: "Sign in again to apply a promo code." };

  const amount = Math.max(0, Math.round(Number(subtotalCents) || 0));
  const result = evaluatePromo(String(code ?? ""), amount);
  if (!result.ok) return { ok: false, error: result.error };

  return {
    ok: true,
    code: result.promo.code,
    kind: result.promo.kind,
    value: result.promo.value,
    minCents: result.promo.min_cents,
    discountCents: result.discountCents,
    description: result.promo.description,
  };
}
