import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { ArrowUpRight, Layers, Plus, Power } from "lucide-react";
import { GameIcon } from "@/components/game-icon";
import { StatusPill } from "@/components/status-pill";
import { getCategories, getProducts } from "@/lib/queries";
import { toggleCategoryAction } from "@/lib/actions/admin";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Categories" };

export default async function AdminCategoriesPage() {
  await requireAdmin("/admin/categories");
  const categories = getCategories();
  const live = categories.filter((category) => category.active === 1).length;

  return (
    <div className="mx-auto max-w-[1240px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">Categories</h1>
          <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
            Groups on the store and the defaults their products inherit.
          </p>
        </div>
        <Link href="/admin/categories/new" className="btn btn-primary btn-sm">
          <Plus className="size-4" />
          New category
        </Link>
      </div>

      <p className="mt-4 text-[0.72rem] text-mutedblue">
        {live} live of {categories.length}
      </p>

      {categories.length === 0 ? (
        <div className="glass mt-3 rounded-2xl p-10 text-center">
          <span className="mx-auto grid size-12 place-items-center rounded-2xl bg-white/80 text-[#0a63ff]">
            <Layers className="size-6" />
          </span>
          <h2 className="display-soft mt-4 text-[1.2rem] text-ink">
            No categories yet.
          </h2>
          <p className="mx-auto mt-1.5 max-w-[44ch] text-[0.8rem] leading-relaxed text-ink-soft/80">
            Categories are what customers browse: Minecraft, FiveM, Rust and so
            on. Create one, then add plans.
          </p>
          <Link href="/admin/categories/new" className="btn btn-primary btn-sm mt-4">
            Create a category
          </Link>
        </div>
      ) : (
        <div className="mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {categories.map((category) => {
            const productCount = getProducts({ categoryId: category.id }).length;
            return (
              <article key={category.id} className="glass rounded-2xl p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <span
                      className="grid size-10 place-items-center rounded-xl bg-white/80 ring-1 ring-white"
                      style={{ color: category.accent }}
                    >
                      <GameIcon slug={category.slug} className="size-5" />
                    </span>
                    <div>
                      <h2 className="text-[0.86rem] font-semibold text-ink">
                        {category.name}
                      </h2>
                      <p className="mono text-[0.64rem] text-mutedblue">
                        {category.slug}
                      </p>
                    </div>
                  </div>
                  <StatusPill
                    label={category.active === 1 ? "Live" : "Hidden"}
                    tone={category.active === 1 ? "mint" : "slate"}
                    dot
                  />
                </div>

                <p className="mt-2.5 line-clamp-2 min-h-[2.2rem] text-[0.74rem] leading-relaxed text-ink-soft/80">
                  {category.tagline || category.description || "No tagline yet."}
                </p>

                <div className="mt-3 flex items-center justify-between gap-2 border-t border-white/80 pt-2.5">
                  <span className="text-[0.68rem] text-mutedblue">
                    {productCount} {productCount === 1 ? "product" : "products"} ·{" "}
                    order {category.sort_order}
                  </span>
                  <div className="flex items-center gap-1">
                    <form action={toggleCategoryAction}>
                      <input type="hidden" name="id" value={category.id} />
                      <button
                        type="submit"
                        aria-label={
                          category.active === 1
                            ? `Hide ${category.name}`
                            : `Publish ${category.name}`
                        }
                        className="grid size-7 place-items-center rounded-lg text-[#7fa5c2] transition hover:bg-white/70 hover:text-[#0a63ff]"
                      >
                        <Power className="size-3.5" />
                      </button>
                    </form>
                    <Link
                      href={`/admin/categories/${category.id}`}
                      aria-label={`Edit ${category.name}`}
                      className="grid size-7 place-items-center rounded-lg text-[#7fa5c2] transition hover:bg-white/70 hover:text-[#0a63ff]"
                    >
                      <ArrowUpRight className="size-3.5" />
                    </Link>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
