"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X } from "lucide-react";

const LINKS = [
  { href: "/store", label: "Game servers" },
  { href: "/#why-volt", label: "Why Volt" },
  { href: "/#network", label: "Network" },
  { href: "/#pricing", label: "Pricing" },
  { href: "/support", label: "Support" },
];

export function MobileMenu({
  signedIn,
  isAdmin,
}: {
  signedIn: boolean;
  isAdmin: boolean;
}) {
  // Remember which path the menu was opened on so a route change closes it
  // without a state-updating effect.
  const [openAt, setOpenAt] = useState<string | null>(null);
  const pathname = usePathname();
  const open = openAt === pathname;

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpenAt(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <div className="lg:hidden">
      <button
        type="button"
        onClick={() => setOpenAt(open ? null : pathname)}
        aria-expanded={open}
        aria-controls="mobile-navigation"
        aria-label={open ? "Close menu" : "Open menu"}
        className="grid size-10 place-items-center rounded-xl border border-white/80 bg-white/60 text-ink shadow-sm backdrop-blur-md"
      >
        {open ? <X className="size-[18px]" /> : <Menu className="size-[18px]" />}
      </button>

      {open && (
        <>
          <button
            type="button"
            aria-label="Close menu"
            onClick={() => setOpenAt(null)}
            className="fixed inset-0 top-[72px] z-40 bg-[#06233c]/20 backdrop-blur-[2px]"
          />
          <div
            id="mobile-navigation"
            className="glass absolute inset-x-3 top-[calc(100%+8px)] z-50 rounded-2xl p-3"
          >
            <nav className="flex flex-col">
              {LINKS.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpenAt(null)}
                  className="rounded-xl px-3 py-2.5 text-[0.95rem] font-medium text-ink-soft hover:bg-white/60"
                >
                  {link.label}
                </Link>
              ))}
            </nav>
            <div className="hairline my-2" />
            <div className="flex flex-col gap-2 p-1">
              {signedIn ? (
                <>
                  <Link href="/dashboard" className="btn btn-primary btn-block">
                    Open dashboard
                  </Link>
                  {isAdmin && (
                    <Link
                      href="/admin"
                      className="btn btn-secondary btn-block"
                    >
                      Admin panel
                    </Link>
                  )}
                </>
              ) : (
                <>
                  <Link href="/login" className="btn btn-secondary btn-block">
                    Sign in
                  </Link>
                  <Link href="/register" className="btn btn-primary btn-block">
                    Create account
                  </Link>
                </>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
