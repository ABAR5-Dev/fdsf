"use client";

import { useState } from "react";
import { Check, Copy } from "lucide-react";

export function CopyButton({
  value,
  label = "Copy",
  className = "",
}: {
  value: string;
  label?: string;
  className?: string;
}) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };

  return (
    <button
      type="button"
      onClick={copy}
      aria-label={copied ? "Copied" : label}
      className={[
        "inline-flex items-center gap-1 rounded-md border border-white/90 bg-white/70 px-1.5 py-1 text-[0.66rem] font-medium text-ink-soft transition hover:bg-white hover:text-ink",
        className,
      ].join(" ")}
    >
      {copied ? (
        <Check className="size-3 text-[#0a8f5b]" />
      ) : (
        <Copy className="size-3" />
      )}
      {copied ? "Copied" : label}
    </button>
  );
}
