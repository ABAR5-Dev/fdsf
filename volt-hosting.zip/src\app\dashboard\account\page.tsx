import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { KeyRound, Mail, UserRound, UserRoundCog } from "lucide-react";
import { PasswordForm, ProfileForm } from "@/components/app/account-forms";
import { getCurrentUser } from "@/lib/auth";
import { dateLabel } from "@/lib/format";
import { getPterodactyl } from "@/lib/queries";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Account" };

export default async function AccountPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/account");

  const pterodactyl = getPterodactyl();

  return (
    <div className="mx-auto max-w-[960px]">
      <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">Account</h1>
      <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
        Profile, sign-in and the panel identity attached to your services.
      </p>

      <div className="mt-5 grid items-start gap-4 lg:grid-cols-[1.25fr_0.75fr]">
        <div className="space-y-4">
          <section className="glass rounded-2xl p-4 sm:p-5">
            <h2 className="flex items-center gap-1.5 text-[0.9rem] font-semibold text-ink">
              <UserRound className="size-4 text-[#0a63ff]" />
              Profile
            </h2>
            <p className="mt-1 mb-3 text-[0.76rem] text-mutedblue">
              Member since {dateLabel(user.createdAt)}
            </p>
            <ProfileForm
              name={user.name}
              email={user.email}
              avatarUrl={user.avatarUrl}
              bio={user.bio}
              discordHandle={user.discordHandle}
            />
          </section>

          <section className="glass rounded-2xl p-4 sm:p-5">
            <h2 className="flex items-center gap-1.5 text-[0.9rem] font-semibold text-ink">
              <KeyRound className="size-4 text-[#0a63ff]" />
              Password
            </h2>
            <p className="mt-1 mb-3 text-[0.76rem] text-mutedblue">
              Changing this does not change your game panel password.
            </p>
            <PasswordForm />
          </section>
        </div>

        <aside className="space-y-4">
          <section className="glass rounded-2xl p-4">
            <h2 className="flex items-center gap-1.5 text-[0.9rem] font-semibold text-ink">
              <UserRoundCog className="size-4 text-[#0a63ff]" />
              Panel identity
            </h2>
            <dl className="mt-3 space-y-2 text-[0.76rem]">
              <div className="flex items-center justify-between gap-3">
                <dt className="text-mutedblue">Panel user</dt>
                <dd className="mono truncate text-ink">
                  {user.panelUsername || "Created with first order"}
                </dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="text-mutedblue">Panel</dt>
                <dd className="truncate text-ink">{pterodactyl.panelUrl}</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="text-mutedblue">Role</dt>
                <dd className="capitalize text-ink">{user.role}</dd>
              </div>
            </dl>
            <a
              href={pterodactyl.panelUrl}
              target="_blank"
              rel="noreferrer"
              className="btn btn-secondary btn-sm mt-3 w-full"
            >
              Open panel
            </a>
          </section>

          <section className="glass rounded-2xl p-4">
            <h2 className="flex items-center gap-1.5 text-[0.9rem] font-semibold text-ink">
              <Mail className="size-4 text-[#0a63ff]" />
              Email
            </h2>
            <p className="mt-1 text-[0.76rem] leading-relaxed text-ink-soft/80">
              Every server credential, invoice and ticket reply is sent to{" "}
              <span className="font-medium text-ink">{user.email}</span>.
            </p>
            <Link
              href="/dashboard/support/new"
              className="mt-3 inline-flex items-center gap-1 text-[0.74rem] font-semibold text-[#0a63ff] hover:underline"
            >
              Email not arriving? Ask support
            </Link>
          </section>
        </aside>
      </div>
    </div>
  );
}
