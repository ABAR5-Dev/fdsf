import { NextResponse, type NextRequest } from "next/server";

const SESSION_COOKIE = "volt_session";

/**
 * Optimistic only: the cookie's presence decides whether to bounce a visitor
 * to sign-in before a protected page renders. Real authorisation still happens
 * in the layouts and server actions, which validate the session row.
 */
export function proxy(request: NextRequest) {
  const { pathname, search } = request.nextUrl;

  if (request.cookies.has(SESSION_COOKIE)) {
    return NextResponse.next();
  }

  const url = new URL("/login", request.url);
  const next = `${pathname}${search}`;
  url.searchParams.set("next", next.length > 1 ? next.slice(0, 200) : "/dashboard");
  return NextResponse.redirect(url);
}

export const config = {
  matcher: ["/dashboard/:path*", "/admin/:path*"],
};
