import { cacheLife } from "next/cache";

// Cache Components blocks `new Date()` during prerendering, so the copyright
// year is cached and refreshed daily rather than read on every request.
export async function CopyrightYear() {
  "use cache";
  cacheLife("days");
  return <>{new Date().getFullYear()}</>;
}
