"use client";

import { useActionState, useEffect, useRef } from "react";
import { CheckCircle2, Loader2, Send } from "lucide-react";
import { adminReplyTicketAction } from "@/lib/actions/admin";

export function AdminReplyBox({ ticketId }: { ticketId: string }) {
  const [state, action, pending] = useActionState(adminReplyTicketAction, null);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state?.success) formRef.current?.reset();
  }, [state]);

  return (
    <form ref={formRef} action={action} className="mt-3">
      <input type="hidden" name="ticket_id" value={ticketId} />
      <label htmlFor="message" className="field-label">
        Staff reply
      </label>
      <textarea
        id="message"
        name="message"
        required
        rows={5}
        placeholder="Answer the question, then set the ticket to answered."
        className="textarea"
      />
      {state?.error && (
        <p role="alert" className="mt-1.5 text-[0.74rem] text-[#a13b3b]">
          {state.error}
        </p>
      )}
      {state?.success && (
        <p className="mt-1.5 flex items-center gap-1 text-[0.74rem] text-[#0a7a4e]">
          <CheckCircle2 className="size-3" />
          {state.success}
        </p>
      )}
      <div className="mt-2 flex items-center justify-between gap-2">
        <span className="text-[0.66rem] text-mutedblue">
          The customer gets this by email. Ticket moves to answered.
        </span>
        <button type="submit" disabled={pending} className="btn btn-primary btn-sm">
          {pending ? (
            <>
              <Loader2 className="size-3.5 animate-spin" />
              Sending
            </>
          ) : (
            <>
              <Send className="size-3.5" />
              Send reply
            </>
          )}
        </button>
      </div>
    </form>
  );
}
