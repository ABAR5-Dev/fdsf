"use client";

import type { ButtonHTMLAttributes, MouseEvent } from "react";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  /** Question shown before the form submits. Cancelling keeps the record. */
  message: string;
};

/**
 * Submit button for destructive admin actions. Server action forms post
 * immediately, so the last chance to stop a misclick is here.
 */
export function ConfirmSubmitButton({ message, onClick, ...props }: Props) {
  function handleClick(event: MouseEvent<HTMLButtonElement>) {
    if (!window.confirm(message)) {
      event.preventDefault();
      return;
    }
    onClick?.(event);
  }

  return <button {...props} type="submit" onClick={handleClick} />;
}
