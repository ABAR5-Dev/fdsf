"use client";

import Link from "next/link";
import { useActionState } from "react";
import { CheckCircle2, Loader2, Save } from "lucide-react";
import { saveCategoryAction } from "@/lib/actions/admin";
import type { CategoryRow } from "@/lib/types";

export function CategoryForm({ category }: { category?: CategoryRow }) {
  const [state, action, pending] = useActionState(saveCategoryAction, null);

  return (
    <form action={action} className="space-y-4">
      {category && <input type="hidden" name="id" value={category.id} />}

      {state?.error && (
        <p
          role="alert"
          className="rounded-lg border border-[#f3c6c6] bg-[#fff5f5] px-3 py-2 text-[0.78rem] text-[#a13b3b]"
        >
          {state.error}
        </p>
      )}
      {state?.success && (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-[#c4e8d5] bg-[#f2fbf6] px-3 py-2 text-[0.78rem] text-[#0a7a4e]">
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="size-3.5" />
            {state.success}
          </span>
          <Link href="/admin/categories" className="font-semibold hover:underline">
            Back to categories
          </Link>
        </div>
      )}

      <section className="glass rounded-2xl p-4 sm:p-5">
        <h2 className="text-[0.9rem] font-semibold text-ink">Storefront</h2>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <div>
            <label htmlFor="name" className="field-label">
              Name
            </label>
            <input
              id="name"
              name="name"
              required
              minLength={2}
              maxLength={60}
              defaultValue={category?.name ?? ""}
              placeholder="Minecraft"
              className="input"
            />
          </div>
          <div>
            <label htmlFor="tagline" className="field-label">
              Tagline
            </label>
            <input
              id="tagline"
              name="tagline"
              maxLength={100}
              defaultValue={category?.tagline ?? ""}
              placeholder="Modded, vanilla, or somewhere in between."
              className="input"
            />
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="description" className="field-label">
              Description
            </label>
            <textarea
              id="description"
              name="description"
              rows={3}
              maxLength={400}
              defaultValue={category?.description ?? ""}
              placeholder="Used on the category page and store cards."
              className="textarea"
            />
          </div>
          <div>
            <label htmlFor="icon" className="field-label">
              Icon key
            </label>
            <input
              id="icon"
              name="icon"
              defaultValue={category?.icon ?? "gamepad-2"}
              placeholder="pickaxe"
              className="input mono text-[0.78rem]"
            />
            <p className="field-hint">
              Known keys: minecraft, fivem, rust, samp, discord-bots, vps.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="accent" className="field-label">
                Accent
              </label>
              <input
                id="accent"
                name="accent"
                type="color"
                defaultValue={category?.accent ?? "#0a63ff"}
                className="input h-9 p-1"
              />
            </div>
            <div>
              <label htmlFor="sort_order" className="field-label">
                Order
              </label>
              <input
                id="sort_order"
                name="sort_order"
                type="number"
                min={0}
                step={1}
                defaultValue={category?.sort_order ?? 0}
                className="input"
              />
            </div>
          </div>
          <label className="flex items-center gap-2 text-[0.78rem] text-ink-soft sm:col-span-2">
            <input
              type="checkbox"
              name="active"
              defaultChecked={category ? category.active === 1 : true}
              className="size-4 rounded border-[#c3d6e6] accent-[#0a63ff]"
            />
            Show this category in the store
          </label>
        </div>
      </section>

      <details className="glass rounded-2xl p-4 sm:p-5">
        <summary className="cursor-pointer text-[0.9rem] font-semibold text-ink">
          Egg defaults for this category
        </summary>
        <p className="mt-1 text-[0.72rem] text-mutedblue">
          Products inherit these unless they override them.
        </p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          {[
            { name: "nest_id", label: "Nest id", value: category?.nest_id ?? "" },
            { name: "egg_id", label: "Egg id", value: category?.egg_id ?? "" },
            {
              name: "docker_image",
              label: "Docker image",
              value: category?.docker_image ?? "",
            },
            {
              name: "startup",
              label: "Startup command",
              value: category?.startup ?? "",
            },
          ].map((field) => (
            <div key={field.name}>
              <label htmlFor={field.name} className="field-label">
                {field.label}
              </label>
              <input
                id={field.name}
                name={field.name}
                defaultValue={field.value}
                className="input mono text-[0.76rem]"
              />
            </div>
          ))}
          <div className="sm:col-span-2">
            <label htmlFor="environment" className="field-label">
              Environment (JSON)
            </label>
            <textarea
              id="environment"
              name="environment"
              rows={3}
              defaultValue={category?.environment ?? ""}
              placeholder='{"SERVER_JARFILE":"server.jar"}'
              className="textarea mono text-[0.76rem]"
            />
          </div>
        </div>
      </details>

      <div className="flex flex-wrap gap-2">
        <button type="submit" disabled={pending} className="btn btn-primary">
          {pending ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Saving
            </>
          ) : (
            <>
              <Save className="size-4" />
              {category ? "Save category" : "Create category"}
            </>
          )}
        </button>
        <Link href="/admin/categories" className="btn btn-secondary">
          Cancel
        </Link>
      </div>
    </form>
  );
}
