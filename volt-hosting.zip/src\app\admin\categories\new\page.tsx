import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { CategoryForm } from "@/components/app/category-form";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "New category" };

export default async function NewCategoryPage() {
  await requireAdmin("/admin/categories/new");
  return (
    <div className="mx-auto max-w-[960px]">
      <Link
        href="/admin/categories"
        className="inline-flex items-center gap-1.5 text-[0.74rem] font-medium text-mutedblue transition hover:text-ink"
      >
        <ArrowLeft className="size-3.5" />
        Categories
      </Link>
      <h1 className="display mt-3 text-[1.9rem] text-ink sm:text-[2.2rem]">
        New category
      </h1>
      <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
        Pick a name customers recognize. The slug is generated automatically.
      </p>
      <div className="mt-5">
        <CategoryForm />
      </div>
    </div>
  );
}
