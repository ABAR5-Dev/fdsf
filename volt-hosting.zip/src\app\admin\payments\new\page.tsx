import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { GatewayForm } from "@/components/app/payment-forms";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "New payment method" };

export default async function NewPaymentPage() {
  await requireAdmin("/admin/payments/new");
  return (
    <div className="mx-auto max-w-[860px]">
      <Link
        href="/admin/payments"
        className="inline-flex items-center gap-1.5 text-[0.74rem] font-medium text-mutedblue transition hover:text-ink"
      >
        <ArrowLeft className="size-3.5" />
        Payments
      </Link>
      <h1 className="display mt-3 text-[1.9rem] text-ink sm:text-[2.2rem]">
        New payment method
      </h1>
      <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
        Add UPI and Google Pay as a Discord-ticket method, a bank transfer, or
        card checkout through Stripe.
      </p>
      <div className="mt-5">
        <GatewayForm />
      </div>
    </div>
  );
}
