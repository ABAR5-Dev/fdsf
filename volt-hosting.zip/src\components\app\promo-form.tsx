"use client";

import { useActionState, useState } from "react";
import Link from "next/link";
import { ArrowUpRight, CheckCircle2, Loader2, Save, TicketPercent } from "lucide-react";
import { savePromoCodeAction } from "@/lib/actions/admin";
import type { PromoCodeRow, ActionState } from "@/lib/types";

function Feedback({ state }: { state: ActionState }) {
  if (!state) return null;
  if (state.error) {
    return (
      <p
        role="alert"
        className="rounded-lg border border-[#f3c6c6] bg-[#fff5f5] px-3 py-2 text-[0.76rem] text-[#a13b3b]"
      >
        {state.error}
      </p>
    );
  }
  if (state.success) {
    return (
      <p className="flex items-center gap-1.5 rounded-lg border border-[#c4e8d5] bg-[#f2fbf6] px-3 py-2 text-[0.76rem] text-[#0a7a4e]">
        <CheckCircle2 className="size-3.5" />
        {state.success}
      </p>
    );
  }
  return null;
}

export function PromoForm({ promo }: { promo?: PromoCodeRow }) {
  const [state, action, pending] = useActionState(savePromoCodeAction, null);
  const [kind, setKind] = useState<"percent" | "fixed">(promo?.kind ?? "percent");

  return (
    <form action={action} className="space-y-4">
      <Feedback state={state} />
      {promo && <input type="hidden" name="id" value={promo.id} />}

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label htmlFor="code" className="field-label">
            Code
          </label>
          <div className="relative">
            <TicketPercent className="pointer-events-none absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-[#7fa5c2]" />
            <input
              id="code"
              name="code"
              defaultValue={promo?.code ?? ""}
              required
              minLength={3}
              maxLength={32}
              placeholder="WINTER25"
              autoComplete="off"
              spellCheck={false}
              className="input mono pl-8 uppercase placeholder:normal-case"
            />
          </div>
          <p className="field-hint">
            Letters, numbers, dashes and underscores. Saved in uppercase.
          </p>
        </div>
        <div>
          <label htmlFor="description" className="field-label">
            Internal note
          </label>
          <input
            id="description"
            name="description"
            defaultValue={promo?.description ?? ""}
            maxLength={200}
            placeholder="Winter sale, creator code, win-back"
            className="input"
          />
          <p className="field-hint">Only admins see this. Never shown at checkout.</p>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <div>
          <label htmlFor="kind" className="field-label">
            Discount type
          </label>
          <select
            id="kind"
            name="kind"
            value={kind}
            onChange={(event) => setKind(event.target.value as "percent" | "fixed")}
            className="select"
          >
            <option value="percent">Percent off</option>
            <option value="fixed">Fixed amount off</option>
          </select>
        </div>
        <div>
          <label htmlFor="value" className="field-label">
            {kind === "percent" ? "Percent off" : "Dollars off"}
          </label>
          <input
            id="value"
            name="value"
            type="number"
            step={kind === "percent" ? "1" : "0.01"}
            min={kind === "percent" ? "1" : "0.01"}
            max={kind === "percent" ? "100" : undefined}
            required
            defaultValue={
              promo
                ? promo.kind === "fixed"
                  ? (promo.value / 100).toFixed(2)
                  : promo.value
                : ""
            }
            placeholder={kind === "percent" ? "15" : "5.00"}
            className="input"
          />
        </div>
        <div>
          <label htmlFor="min_dollars" className="field-label">
            Minimum order
          </label>
          <input
            id="min_dollars"
            name="min_dollars"
            type="number"
            step="0.01"
            min="0"
            defaultValue={
              promo && promo.min_cents > 0
                ? (promo.min_cents / 100).toFixed(2)
                : ""
            }
            placeholder="0.00"
            className="input"
          />
          <p className="field-hint">Blank means no minimum.</p>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label htmlFor="max_uses" className="field-label">
            Redemption limit
          </label>
          <input
            id="max_uses"
            name="max_uses"
            type="number"
            min="0"
            step="1"
            defaultValue={promo?.max_uses ?? 0}
            className="input"
          />
          <p className="field-hint">0 means unlimited. Counts paid orders only.</p>
        </div>
        <div>
          <label htmlFor="expires_at" className="field-label">
            Expires
          </label>
          <input
            id="expires_at"
            name="expires_at"
            type="date"
            defaultValue={promo?.expires_at ? promo.expires_at.slice(0, 10) : ""}
            className="input"
          />
          <p className="field-hint">Optional. Valid through the end of that day.</p>
        </div>
      </div>

      <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-white/90 bg-white/50 px-3 py-2.5 text-[0.78rem] text-ink-soft">
        <input
          type="checkbox"
          name="active"
          defaultChecked={promo ? promo.active === 1 : true}
          className="accent-[#0a63ff]"
        />
        Available at checkout
      </label>

      <div className="flex flex-wrap items-center gap-2">
        <button type="submit" disabled={pending} className="btn btn-primary btn-sm">
          {pending ? (
            <>
              <Loader2 className="size-3.5 animate-spin" />
              Saving
            </>
          ) : (
            <>
              <Save className="size-3.5" />
              {promo ? "Save changes" : "Create promo code"}
            </>
          )}
        </button>
        <Link href="/admin/promotions" className="btn btn-secondary btn-sm">
          {promo ? "All promo codes" : "Cancel"}
          <ArrowUpRight className="size-3.5" />
        </Link>
      </div>
    </form>
  );
}
