import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { Inbox, Mail, MailCheck, MailX, Settings2 } from "lucide-react";
import { StatusPill } from "@/components/status-pill";
import { getEmailLog, getSmtp } from "@/lib/queries";
import { dateTimeLabel } from "@/lib/format";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Email log" };

const STATUS_META: Record<
  string,
  { label: string; tone: "mint" | "blue" | "rose" }
> = {
  sent: { label: "Sent", tone: "mint" },
  simulated: { label: "Simulated", tone: "blue" },
  failed: { label: "Failed", tone: "rose" },
};

export default async function AdminEmailPage() {
  await requireAdmin("/admin/email");
  const log = getEmailLog(100);
  const smtp = getSmtp();
  const sent = log.filter((row) => row.status === "sent").length;
  const simulated = log.filter((row) => row.status === "simulated").length;
  const failed = log.filter((row) => row.status === "failed").length;

  return (
    <div className="mx-auto max-w-[1240px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">Email log</h1>
          <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
            Every message the platform tried to send, newest first.
          </p>
        </div>
        <Link href="/admin/settings#smtp" className="btn btn-secondary btn-sm">
          <Settings2 className="size-4" />
          Email settings
        </Link>
      </div>

      {!smtp.enabled && (
        <div className="mt-4 rounded-xl border border-[#cfe6ff] bg-[#eef7ff] px-4 py-3">
          <p className="text-[0.8rem] font-semibold text-[#083f72]">
            SMTP is off — messages are being simulated.
          </p>
          <p className="mt-1 text-[0.76rem] leading-relaxed text-[#3c6c92]">
            Credentials and receipts are logged but never leave the server.
            Configure a mailbox to deliver them for real.
          </p>
        </div>
      )}

      <div className="mt-4 grid grid-cols-3 gap-3">
        {[
          { label: "Sent", value: sent, icon: MailCheck, tone: "text-[#0a7a4e]" },
          { label: "Simulated", value: simulated, icon: Mail, tone: "text-[#0a5fbe]" },
          { label: "Failed", value: failed, icon: MailX, tone: "text-[#a13b3b]" },
        ].map((stat) => (
          <div key={stat.label} className="glass rounded-xl px-4 py-3">
            <p className="text-[0.68rem] font-medium text-mutedblue">{stat.label}</p>
            <p className={`tabular mt-1 flex items-center gap-2 text-[1.35rem] font-semibold ${stat.tone}`}>
              <stat.icon className="size-4" />
              {stat.value}
            </p>
          </div>
        ))}
      </div>

      <section className="glass mt-4 overflow-hidden rounded-2xl">
        {log.length === 0 ? (
          <div className="px-6 py-14 text-center">
            <span className="mx-auto grid size-11 place-items-center rounded-xl bg-[#e7f2ff] text-[#0a63ff]">
              <Inbox className="size-5" />
            </span>
            <p className="mt-3 text-[0.85rem] font-semibold text-ink">
              Nothing sent yet.
            </p>
            <p className="mx-auto mt-1 max-w-[46ch] text-[0.76rem] leading-relaxed text-mutedblue">
              Welcome messages, credentials and ticket replies appear here as
              soon as they are attempted.
            </p>
          </div>
        ) : (
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Recipient</th>
                  <th>Subject</th>
                  <th>Status</th>
                  <th>Detail</th>
                  <th className="text-right">When</th>
                </tr>
              </thead>
              <tbody>
                {log.map((row) => {
                  const meta = STATUS_META[row.status] ?? {
                    label: row.status,
                    tone: "blue" as const,
                  };
                  return (
                    <tr key={row.id}>
                      <td className="max-w-[220px] truncate font-medium text-ink">
                        {row.to_email}
                      </td>
                      <td className="max-w-[300px] truncate text-ink-soft">
                        {row.subject}
                      </td>
                      <td>
                        <StatusPill label={meta.label} tone={meta.tone} dot />
                      </td>
                      <td className="max-w-[280px]">
                        {row.error ? (
                          <span className="text-[0.72rem] leading-relaxed text-[#a13b3b]">
                            {row.error}
                          </span>
                        ) : (
                          <span className="text-[0.72rem] text-mutedblue">
                            {row.status === "simulated" ? "Not delivered" : "Delivered"}
                          </span>
                        )}
                      </td>
                      <td className="tabular whitespace-nowrap text-right text-[0.72rem] text-mutedblue">
                        {dateTimeLabel(row.created_at)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <p className="mt-4 px-1 text-[0.7rem] leading-relaxed text-mutedblue">
        Showing the latest {log.length === 100 ? "100" : String(log.length)} messages.
        Failed sends keep their error message so you can fix the mailbox and
        follow up by hand.
      </p>
    </div>
  );
}
