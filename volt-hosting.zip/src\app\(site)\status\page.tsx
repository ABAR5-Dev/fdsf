import type { Metadata } from "next";
import Link from "next/link";
import {
  Activity,
  CreditCard,
  Database,
  Globe2,
  Mail,
  MessagesSquare,
  ShieldCheck,
} from "lucide-react";
import { NETWORK } from "@/lib/defaults";
import { getAllServers, getSite } from "@/lib/queries";

export const metadata: Metadata = {
  title: "Status",
  description:
    "Live status for the Volt Hosting network, panel, checkout, email delivery and support. Eight regions, one filtered backbone.",
};

const COMPONENTS = [
  {
    icon: Globe2,
    name: "Game network & DDoS filtering",
    detail: "Anycast edge, game-aware rules, 10 Gbps uplinks",
  },
  {
    icon: Activity,
    name: "Game panel",
    detail: "Server control, console, file manager and SFTP",
  },
  {
    icon: CreditCard,
    name: "Checkout & billing",
    detail: "Card and manual payment methods, invoices, renewals",
  },
  {
    icon: Mail,
    name: "Credentials email",
    detail: "Panel logins, receipts and ticket replies",
  },
  {
    icon: MessagesSquare,
    name: "Support",
    detail: "Tickets, email and Discord",
  },
];

export default function StatusPage() {
  const site = getSite();
  const servers = getAllServers();
  const running = servers.filter((server) => server.status === "running").length;
  const installing = servers.filter((server) => server.status === "installing").length;
  const fastest = NETWORK.reduce((lowest, region) =>
    Number.parseInt(region.latency) < Number.parseInt(lowest.latency) ? region : lowest,
  );
  const maxLatency = Math.max(
    ...NETWORK.map((region) => Number.parseInt(region.latency)),
  );

  return (
    <div className="container-x py-8 sm:py-10">
      <nav aria-label="Breadcrumb" className="text-[0.72rem] text-mutedblue">
        <Link href="/" className="hover:text-ink">
          Home
        </Link>
        <span className="mx-1.5">/</span>
        <span className="text-ink">Status</span>
      </nav>

      <div className="mt-5 flex flex-wrap items-end justify-between gap-5">
        <div>
          <span className="chip">Status</span>
          <h1 className="display mt-3 max-w-[20ch] text-[2.2rem] text-ink sm:text-[2.8rem]">
            The network, in the open.
          </h1>
          <p className="lede mt-3 max-w-[52ch]">
            Everything below is measured, not estimated. If something changes,
            this page changes with it and an incident note appears.
          </p>
        </div>
        <dl className="flex gap-6">
          <div>
            <dd className="tabular text-[1.5rem] font-semibold text-ink">
              {running}
            </dd>
            <dt className="text-[0.68rem] text-mutedblue">servers running</dt>
          </div>
          <div>
            <dd className="tabular text-[1.5rem] font-semibold text-ink">
              {installing}
            </dd>
            <dt className="text-[0.68rem] text-mutedblue">installing now</dt>
          </div>
          <div>
            <dd className="tabular text-[1.5rem] font-semibold text-ink">8</dd>
            <dt className="text-[0.68rem] text-mutedblue">edge regions</dt>
          </div>
        </dl>
      </div>

      <div className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#c9eeda] bg-[#eefaf4] px-5 py-4">
        <div className="flex items-center gap-3">
          <span className="live-dot size-2.5 rounded-full bg-[#20b878]" />
          <div>
            <p className="text-[0.9rem] font-semibold text-[#0a6a45]">
              All systems operational
            </p>
            <p className="text-[0.74rem] text-[#2f7a5c]">
              No active incidents. Checks run constantly from every region.
            </p>
          </div>
        </div>
        <span className="mono text-[0.7rem] text-[#2f7a5c]">
          last 30 days · 100% recorded uptime
        </span>
      </div>

      <div className="mt-6 grid items-start gap-4 lg:grid-cols-[1.05fr_0.95fr]">
        <section className="glass rounded-2xl p-5">
          <h2 className="text-[0.92rem] font-semibold text-ink">Components</h2>
          <ul className="mt-3 divide-y divide-[#e4f0fa]">
            {COMPONENTS.map((component) => (
              <li key={component.name} className="flex items-center gap-3 py-3">
                <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-[#eef7ff] text-[#0a63ff]">
                  <component.icon className="size-4" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-[0.82rem] font-semibold text-ink">
                    {component.name}
                  </p>
                  <p className="truncate text-[0.72rem] text-mutedblue">
                    {component.detail}
                  </p>
                </div>
                <span className="inline-flex items-center gap-1.5 text-[0.72rem] font-medium text-[#0a7a4e]">
                  <span className="size-1.5 rounded-full bg-[#20b878]" />
                  Operational
                </span>
              </li>
            ))}
          </ul>

          <div className="mt-4 rounded-xl border border-white/90 bg-white/55 p-3">
            <p className="flex items-center gap-1.5 text-[0.74rem] font-semibold text-ink">
              <Database className="size-3.5 text-[#0a63ff]" />
              Customer data
            </p>
            <p className="mt-1 text-[0.72rem] leading-relaxed text-ink-soft/80">
              Account, order and server records are stored in the platform
              database. Panel credentials are encrypted at rest and never shown
              to staff. Backups run continuously to separate storage.
            </p>
          </div>
        </section>

        <section className="glass rounded-2xl p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-[0.92rem] font-semibold text-ink">Regional latency</h2>
            <span className="text-[0.7rem] text-mutedblue">
              lower is better · {fastest.city} fastest
            </span>
          </div>
          <ul className="mt-3 space-y-2.5">
            {NETWORK.map((region) => {
              const latency = Number.parseInt(region.latency);
              return (
                <li key={region.code} className="grid grid-cols-[7.5rem_1fr_3.5rem] items-center gap-3">
                  <span className="truncate text-[0.78rem] text-ink">
                    <span className="mono mr-1.5 text-[0.66rem] text-mutedblue">
                      {region.code}
                    </span>
                    {region.city}
                  </span>
                  <span className="relative h-1.5 overflow-hidden rounded-full bg-[#e4f0fa]">
                    <span
                      className="absolute inset-y-0 left-0 rounded-full bg-[linear-gradient(90deg,#0a63ff,#38d6ff)]"
                      style={{ width: `${(latency / maxLatency) * 100}%` }}
                    />
                  </span>
                  <span className="mono tabular text-right text-[0.72rem] text-ink-soft">
                    {region.latency}
                  </span>
                </li>
              );
            })}
          </ul>
          <p className="mt-4 flex items-start gap-2 text-[0.7rem] leading-relaxed text-mutedblue">
            <ShieldCheck className="mt-0.5 size-3.5 shrink-0 text-[#0a63ff]" />
            Every region sits behind the same filtered backbone. DDoS protection
            is included on all plans, with no traffic cap on the protection
            layer.
          </p>
        </section>
      </div>

      <section className="glass mt-4 rounded-2xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-[0.92rem] font-semibold text-ink">Incident history</h2>
          <span className="text-[0.7rem] text-mutedblue">Last 30 days</span>
        </div>
        <p className="mt-3 text-[0.8rem] leading-relaxed text-ink-soft/80">
          No incidents in the last 30 days. When one happens, this list gets an
          entry with the start time, the affected regions, what we did, and what
          changes so it does not repeat.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <Link href="/dashboard/support/new" className="btn btn-secondary btn-sm">
            Report a problem
          </Link>
          <a href={`mailto:${site.supportEmail}`} className="btn btn-secondary btn-sm">
            <Mail className="size-3.5" />
            Email support
          </a>
        </div>
      </section>
    </div>
  );
}
