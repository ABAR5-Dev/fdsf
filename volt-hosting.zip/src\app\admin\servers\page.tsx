import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { ArrowUpRight, Server } from "lucide-react";
import { StatusPill } from "@/components/status-pill";
import {
  SERVER_STATUS_META,
  dateLabel,
  diskLabel,
  ramLabel,
  relativeTime,
} from "@/lib/format";
import { getAllServers } from "@/lib/queries";
import type { ServerStatus } from "@/lib/types";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Servers" };

const TONES: Record<ServerStatus, string> = {
  running: "bg-[#0a63ff]",
  installing: "bg-[#d99a2b]",
  provisioning: "bg-[#5b8fd6]",
  offline: "bg-[#8fa9bd]",
  suspended: "bg-[#c05a5a]",
  failed: "bg-[#a13b3b]",
};

export default async function AdminServersPage() {
  await requireAdmin("/admin/servers");
  const servers = getAllServers();
  const counts = servers.reduce<Record<string, number>>((acc, server) => {
    acc[server.status] = (acc[server.status] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <div className="mx-auto max-w-[1240px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">Servers</h1>
          <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
            The fleet as the panel sees it. Sync pulls fresh state straight
            from Pterodactyl.
          </p>
        </div>
        <span className="mono text-[0.74rem] text-mutedblue">
          {servers.length} container{servers.length === 1 ? "" : "s"}
        </span>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {(
          ["running", "installing", "suspended", "failed", "offline"] as ServerStatus[]
        ).map((status) => {
          const meta = SERVER_STATUS_META[status];
          return (
            <span
              key={status}
              className="inline-flex items-center gap-1.5 rounded-full border border-white/90 bg-white/55 px-2.5 py-1 text-[0.7rem] text-ink-soft"
            >
              <span className={`size-1.5 rounded-full ${TONES[status]}`} />
              {meta.label}
              <span className="mono text-[0.64rem] text-mutedblue">
                {counts[status] ?? 0}
              </span>
            </span>
          );
        })}
      </div>

      <section className="glass mt-3 rounded-2xl p-2 sm:p-3">
        {servers.length === 0 ? (
          <div className="py-14 text-center">
            <span className="mx-auto grid size-11 place-items-center rounded-xl bg-white/80 text-[#0a63ff]">
              <Server className="size-5" />
            </span>
            <p className="mt-3 text-[0.86rem] font-semibold text-ink">
              No servers provisioned.
            </p>
            <p className="mt-1 text-[0.76rem] text-mutedblue">
              A paid order creates the first one automatically.
            </p>
          </div>
        ) : (
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th scope="col">Server</th>
                  <th scope="col">Customer</th>
                  <th scope="col">Resources</th>
                  <th scope="col">Address</th>
                  <th scope="col">Renews</th>
                  <th scope="col">Synced</th>
                  <th scope="col">Status</th>
                  <th scope="col" aria-label="Open" />
                </tr>
              </thead>
              <tbody>
                {servers.map((server) => {
                  const meta =
                    SERVER_STATUS_META[server.status] ?? SERVER_STATUS_META.offline;
                  return (
                    <tr key={server.id}>
                      <td>
                        <Link
                          href={`/admin/servers/${server.id}`}
                          className="block text-[0.8rem] font-medium text-ink hover:text-[#0a63ff]"
                        >
                          {server.name}
                        </Link>
                        <span className="mono text-[0.64rem] text-mutedblue">
                          {server.identifier}
                        </span>
                      </td>
                      <td>
                        <span className="block text-[0.76rem] text-ink-soft">
                          {server.user_name}
                        </span>
                        <span className="text-[0.64rem] text-mutedblue">
                          {server.user_email}
                        </span>
                      </td>
                      <td className="whitespace-nowrap text-[0.72rem] text-ink-soft">
                        {ramLabel(server.ram_mb)} / {diskLabel(server.disk_mb)}
                      </td>
                      <td className="mono whitespace-nowrap text-[0.7rem] text-mutedblue">
                        {server.ip ? `${server.ip}:${server.port ?? ""}` : "—"}
                      </td>
                      <td className="whitespace-nowrap text-[0.7rem] text-mutedblue">
                        {server.renewal_at ? dateLabel(server.renewal_at) : "—"}
                      </td>
                      <td className="whitespace-nowrap text-[0.7rem] text-mutedblue">
                        {server.last_synced_at
                          ? relativeTime(server.last_synced_at)
                          : "Never"}
                      </td>
                      <td>
                        <StatusPill label={meta.label} tone={meta.tone} dot />
                      </td>
                      <td>
                        <Link
                          href={`/admin/servers/${server.id}`}
                          aria-label={`Open ${server.name}`}
                          className="grid size-7 place-items-center rounded-lg text-[#7fa5c2] transition hover:bg-white/70 hover:text-[#0a63ff]"
                        >
                          <ArrowUpRight className="size-3.5" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
