import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import {
  ArrowUpRight,
  CreditCard,
  Plus,
  Power,
  Trash2,
  Wallet,
} from "lucide-react";
import { ConfirmSubmitButton } from "@/components/app/confirm-submit-button";
import { PaymentsSettingsForm } from "@/components/app/payment-forms";
import { StatusPill } from "@/components/status-pill";
import { getGateways, getPayments } from "@/lib/queries";
import {
  deleteGatewayAction,
  toggleGatewayAction,
} from "@/lib/actions/admin";
import type { GatewayType } from "@/lib/types";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Payments" };

const TYPE_META: Record<GatewayType, { label: string; tone: "blue" | "mint" | "amber" }> = {
  discord: { label: "Discord / UPI", tone: "mint" },
  stripe: { label: "Stripe", tone: "blue" },
  manual: { label: "Manual", tone: "amber" },
};

function configHints(raw: string) {
  try {
    const config = JSON.parse(raw) as Record<string, unknown>;
    return {
      hasSecret: Boolean(config.secretKeyEnc || config.secretKey),
      hasWebhook: Boolean(config.webhookSecretEnc || config.webhookSecret),
      hasInstructions: Boolean(config.instructions),
      hasDiscordUrl: Boolean(config.discordUrl),
      publishableKey:
        typeof config.publishableKey === "string" ? config.publishableKey : "",
    };
  } catch {
    return {
      hasSecret: false,
      hasWebhook: false,
      hasInstructions: false,
      hasDiscordUrl: false,
      publishableKey: "",
    };
  }
}

export default async function AdminPaymentsPage() {
  await requireAdmin("/admin/payments");
  const gateways = getGateways();
  const payments = getPayments();
  const enabled = gateways.filter((gateway) => gateway.enabled === 1).length;

  return (
    <div className="mx-auto max-w-[1240px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">Payments</h1>
          <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
            What checkout offers, and the switch that pauses it entirely.
          </p>
        </div>
        <Link href="/admin/payments/new" className="btn btn-primary btn-sm">
          <Plus className="size-4" />
          Add method
        </Link>
      </div>

      <div className="mt-4 grid items-start gap-4 lg:grid-cols-[0.9fr_1.1fr]">
        <section className="glass rounded-2xl p-4 sm:p-5">
          <h2 className="flex items-center gap-1.5 text-[0.9rem] font-semibold text-ink">
            <Wallet className="size-4 text-[#0a63ff]" />
            Checkout settings
          </h2>
          <p className="mt-1 mb-3 text-[0.74rem] text-mutedblue">
            Pausing checkout does not cancel running servers or stop renewals.
          </p>
          <PaymentsSettingsForm settings={payments} />
        </section>

        <section className="glass rounded-2xl p-4 sm:p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="flex items-center gap-1.5 text-[0.9rem] font-semibold text-ink">
              <CreditCard className="size-4 text-[#0a63ff]" />
              Methods
            </h2>
            <span className="text-[0.7rem] text-mutedblue">
              {enabled} of {gateways.length} offered
            </span>
          </div>

          {!payments.enabled && (
            <p className="mt-3 rounded-lg border border-[#f5e2c0] bg-[#fff8eb] px-3 py-2 text-[0.74rem] text-[#7d5410]">
              Checkout is currently paused. No method will be shown to customers.
            </p>
          )}

          {gateways.length === 0 ? (
            <div className="py-8 text-center">
              <p className="text-[0.8rem] font-semibold text-ink">
                No payment methods.
              </p>
              <p className="mt-1 text-[0.74rem] text-mutedblue">
                Add UPI / GPay through Discord, bank transfer or Stripe.
              </p>
              <Link href="/admin/payments/new" className="btn btn-primary btn-sm mt-3">
                Add the first method
              </Link>
            </div>
          ) : (
            <ul className="mt-3 space-y-2">
              {gateways.map((gateway) => {
                const type = TYPE_META[gateway.type] ?? TYPE_META.manual;
                const hints = configHints(gateway.config);
                return (
                  <li
                    key={gateway.id}
                    className="rounded-xl border border-white/90 bg-white/55 p-3"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-[0.82rem] font-semibold text-ink">
                            {gateway.name}
                          </span>
                          <StatusPill label={type.label} tone={type.tone} />
                          <StatusPill
                            label={gateway.enabled === 1 ? "Offered" : "Off"}
                            tone={gateway.enabled === 1 ? "mint" : "slate"}
                            dot
                          />
                        </div>
                        <p className="mt-1 text-[0.72rem] leading-relaxed text-ink-soft/80">
                          {gateway.description || "No description."}
                        </p>
                        <p className="mt-1 text-[0.66rem] text-mutedblue">
                          {gateway.type === "stripe" &&
                            `${hints.hasSecret ? "Secret key saved" : "No secret key"}${
                              hints.hasWebhook ? " · webhook saved" : ""
                            }`}
                          {gateway.type === "manual" &&
                            (hints.hasInstructions
                              ? "Instructions saved"
                              : "No instructions yet")}
                          {gateway.type === "discord" &&
                            `${hints.hasInstructions ? "Ticket instructions saved" : "No ticket instructions"}${
                              hints.hasDiscordUrl ? " · invite saved" : " · uses site invite"
                            }`}
                        </p>
                      </div>

                      <div className="flex items-center gap-1">
                        <Link
                          href={`/admin/payments/${gateway.id}`}
                          aria-label={`Edit ${gateway.name}`}
                          className="grid size-7 place-items-center rounded-lg text-[#7fa5c2] transition hover:bg-white/80 hover:text-[#0a63ff]"
                        >
                          <ArrowUpRight className="size-3.5" />
                        </Link>
                        <form action={toggleGatewayAction}>
                          <input type="hidden" name="id" value={gateway.id} />
                          <button
                            type="submit"
                            aria-label={
                              gateway.enabled === 1
                                ? `Disable ${gateway.name}`
                                : `Enable ${gateway.name}`
                            }
                            className="grid size-7 place-items-center rounded-lg text-[#7fa5c2] transition hover:bg-white/80 hover:text-[#0a63ff]"
                          >
                            <Power className="size-3.5" />
                          </button>
                        </form>
                        <form action={deleteGatewayAction}>
                          <input type="hidden" name="id" value={gateway.id} />
                          <ConfirmSubmitButton
                            message={`Delete ${gateway.name}? Customers will no longer be able to pay through it.`}
                            aria-label={`Delete ${gateway.name}`}
                            className="grid size-7 place-items-center rounded-lg text-[#b58c8c] transition hover:bg-[#fff1f1] hover:text-[#a13b3b]"
                          >
                            <Trash2 className="size-3.5" />
                          </ConfirmSubmitButton>
                        </form>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      </div>

      <p className="mt-4 px-1 text-[0.7rem] leading-relaxed text-mutedblue">
        Stripe keys live encrypted in the database. The checkout page never
        receives them; it only knows which methods are on.
      </p>
    </div>
  );
}
