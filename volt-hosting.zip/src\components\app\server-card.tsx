import Link from "next/link";
import { ArrowRight, Cpu, HardDrive, MemoryStick } from "lucide-react";
import { CopyButton } from "@/components/copy-button";
import { StatusPill } from "@/components/status-pill";
import {
  SERVER_STATUS_META,
  cpuLabel,
  dateLabel,
  diskLabel,
  ramLabel,
} from "@/lib/format";
import type { ServerRow } from "@/lib/types";

export function ServerCard({ server }: { server: ServerRow }) {
  const meta = SERVER_STATUS_META[server.status] ?? SERVER_STATUS_META.offline;
  const address = server.ip ? `${server.ip}${server.port ? `:${server.port}` : ""}` : "Assigning…";

  return (
    <article className="glass-quiet rounded-2xl p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="truncate text-[0.92rem] font-semibold text-ink">
            {server.name}
          </h3>
          <p className="mt-0.5 text-[0.7rem] text-mutedblue">
            {server.region}
            {server.renewal_at ? ` · renews ${dateLabel(server.renewal_at)}` : ""}
          </p>
        </div>
        <StatusPill label={meta.label} tone={meta.tone} dot />
      </div>

      <div className="mt-3 flex items-center gap-1.5">
        <code className="mono min-w-0 flex-1 truncate rounded-md border border-white/90 bg-white/65 px-2 py-1 text-[0.68rem] text-[#2b5270]">
          {address}
        </code>
        {server.ip && <CopyButton value={address} label="Copy" />}
      </div>

      <div className="mt-3 grid grid-cols-3 gap-1.5">
        {[
          { icon: MemoryStick, value: ramLabel(server.ram_mb) },
          { icon: Cpu, value: cpuLabel(server.cpu_pct) },
          { icon: HardDrive, value: diskLabel(server.disk_mb) },
        ].map((item, index) => {
          const Icon = item.icon;
          return (
            <div
              key={index}
              className="flex items-center gap-1 rounded-lg border border-white/80 bg-white/45 px-2 py-1.5 text-[0.68rem] text-ink-soft"
            >
              <Icon className="size-3 shrink-0 text-[#7fa5c2]" />
              <span className="mono truncate">{item.value}</span>
            </div>
          );
        })}
      </div>

      <Link
        href={`/dashboard/servers/${server.id}`}
        className="mt-3 inline-flex items-center gap-1 text-[0.76rem] font-semibold text-[#0a63ff] hover:underline"
      >
        Manage server
        <ArrowRight className="size-3.5" />
      </Link>
    </article>
  );
}
