import Link from "next/link";
import {
  ArrowRight,
  Check,
  Gamepad2,
  ShieldCheck,
  Sparkles,
  Zap,
} from "lucide-react";
import { HeroConsole } from "@/components/marketing/hero-console";
import {
  FaqSection,
  FinalCta,
  HowItWorks,
  NetworkSection,
  Testimonials,
  TrustStrip,
} from "@/components/marketing/landing-sections";
import { GameShowcase, type ShowcaseGame } from "@/components/marketing/game-showcase";
import { PanelShowcase } from "@/components/marketing/panel-showcase";
import { PlanConfigurator } from "@/components/marketing/plan-configurator";
import { GAME_META } from "@/lib/defaults";
import { money } from "@/lib/format";
import { getCategories, getFeaturedProducts, getPricing, getProducts, getSite } from "@/lib/queries";

export default function Home() {
  const site = getSite();
  const pricing = getPricing();
  const categories = getCategories({ activeOnly: true });
  const products = getProducts({ activeOnly: true });
  const featured = getFeaturedProducts();

  const games: ShowcaseGame[] = categories
    .filter((category) => GAME_META[category.slug])
    .map((category) => {
      const plans = products.filter((product) => product.category_id === category.id);
      const min = plans.reduce(
        (lowest, plan) => Math.min(lowest, plan.price_cents),
        Number.POSITIVE_INFINITY,
      );
      return {
        slug: category.slug,
        name: category.name,
        tagline: category.tagline,
        planCount: plans.length,
        startingAt: Number.isFinite(min) ? `${money(min)}` : GAME_META[category.slug].startingAt,
      };
    });

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden pb-10 pt-8 sm:pb-14 sm:pt-12">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-40 -top-32 -z-10 size-[42rem] rounded-full bg-[radial-gradient(circle,rgba(86,197,255,0.35),transparent_68%)] blur-2xl drift"
        />
        <div className="container-x grid items-center gap-10 lg:grid-cols-[1.02fr_0.98fr] lg:gap-12">
          <div>
            <div className="enter" style={{ animationDelay: "60ms" }}>
              <span className="chip chip-accent">
                <Sparkles className="size-3.5" />
                Ryzen 9 · NVMe · eight regions
              </span>
            </div>

            <h1
              className="display enter mt-5 max-w-[13ch] text-[2.75rem] text-ink sm:text-[3.5rem] lg:text-[3.85rem]"
              style={{ animationDelay: "120ms" }}
            >
              Boot a world while the kettle boils.
            </h1>

            <p
              className="lede enter mt-5 max-w-[48ch]"
              style={{ animationDelay: "220ms" }}
            >
              Game hosting for Minecraft, FiveM, Rust, SA-MP and Discord bots.
              Pick your RAM, pay once, and your panel login lands in your inbox
              before the water is hot.
            </p>

            <div
              className="enter mt-7 flex flex-wrap items-center gap-2.5"
              style={{ animationDelay: "300ms" }}
            >
              <Link href="/store" className="btn btn-primary btn-lg">
                Deploy a server
                <ArrowRight className="size-4" />
              </Link>
              <Link href="#pricing" className="btn btn-secondary btn-lg">
                Build your own
              </Link>
            </div>

            <ul
              className="enter mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 text-[0.78rem] text-ink-soft/80"
              style={{ animationDelay: "380ms" }}
            >
              {["No setup fee", "DDoS filtering included", "Cancel anytime"].map(
                (item) => (
                  <li key={item} className="inline-flex items-center gap-1.5">
                    <span className="grid size-4 place-items-center rounded-full bg-[#dff1ff] text-[#0a63ff]">
                      <Check className="size-2.5" strokeWidth={3} />
                    </span>
                    {item}
                  </li>
                ),
              )}
            </ul>

            <div
              className="enter mt-7 flex items-center gap-3"
              style={{ animationDelay: "440ms" }}
            >
              <div className="flex -space-x-2">
                {["RK", "SO", "NF", "JD"].map((person, index) => (
                  <span
                    key={person}
                    className="grid size-8 place-items-center rounded-full border-2 border-[#f4fbff] bg-gradient-to-br from-[#dbeeff] to-white text-[0.58rem] font-bold text-[#0a4bb0]"
                    style={{ zIndex: 4 - index }}
                  >
                    {person}
                  </span>
                ))}
              </div>
              <p className="text-[0.76rem] leading-snug text-mutedblue">
                Joined by <span className="font-semibold text-ink">12,400</span>{" "}
                communities
                <span className="block text-[0.68rem]">
                  4.9/5 across 1,284 support tickets
                </span>
              </p>
            </div>
          </div>

          <div className="enter" style={{ animationDelay: "180ms" }}>
            <HeroConsole pricing={pricing} />
          </div>
        </div>

        <div className="container-x mt-10 sm:mt-12">
          <TrustStrip />
        </div>
      </section>

      {/* Games */}
      <section id="games" className="section">
        <div className="container-x">
          <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
            <div>
              <span className="chip">
                <Gamepad2 className="size-3.5" />
                Six categories, one control plane
              </span>
              <h2 className="display mt-4 max-w-[18ch] text-[2rem] text-ink sm:text-[2.6rem]">
                Pick the world. We bring the hardware.
              </h2>
            </div>
            <div className="max-w-[28ch]">
              <p className="text-[0.86rem] leading-relaxed text-ink-soft/80">
                Same panel, same backups, same network. The only thing that
                changes is the runtime your game needs.
              </p>
              <Link
                href="/store"
                className="mt-2 inline-flex items-center gap-1 text-[0.8rem] font-semibold text-[#0a63ff] hover:underline"
              >
                Compare all plans
                <ArrowRight className="size-3.5" />
              </Link>
            </div>
          </div>

          <GameShowcase games={games} />
        </div>
      </section>

      {/* Why Volt / panel */}
      <section id="why-volt" className="section">
        <div className="container-x">
          <PanelShowcase />
        </div>
      </section>

      {/* How it works */}
      <section className="section pt-0">
        <div className="container-x">
          <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
            <div>
              <span className="chip">
                <Zap className="size-3.5" />
                From cart to console
              </span>
              <h2 className="display mt-4 max-w-[17ch] text-[2rem] text-ink sm:text-[2.6rem]">
                Three steps. No onboarding call.
              </h2>
            </div>
            <p className="max-w-[30ch] text-[0.86rem] leading-relaxed text-ink-soft/80">
              Provisioning is automatic. If your chosen node is full, we email
              the ETA instead of leaving you guessing.
            </p>
          </div>
          <HowItWorks />
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="section pt-0">
        <div className="container-x">
          <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
            <div>
              <span className="chip">
                <ShieldCheck className="size-3.5" />
                Transparent pricing
              </span>
              <h2 className="display mt-4 max-w-[16ch] text-[2rem] text-ink sm:text-[2.6rem]">
                Pay for the RAM you need.
              </h2>
            </div>
            <p className="max-w-[31ch] text-[0.86rem] leading-relaxed text-ink-soft/80">
              Every build includes the panel, DDoS filtering, NVMe storage and
              backups. No setup fee, no per-slot charge.
            </p>
          </div>
          <PlanConfigurator
            games={games.map((game) => ({
              slug: game.slug,
              name: game.name,
              startingAt: game.startingAt,
            }))}
            pricing={pricing}
            featured={featured}
          />
        </div>
      </section>

      {/* Network */}
      <section id="network" className="section pt-0">
        <div className="container-x">
          <NetworkSection />
        </div>
      </section>

      {/* Testimonials */}
      <section className="section pt-0">
        <div className="container-x">
          <Testimonials />
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="section pt-0">
        <div className="container-x">
          <FaqSection />
        </div>
      </section>

      {/* Final CTA */}
      <section className="pb-4">
        <div className="container-x">
          <FinalCta discordInvite={site.discordInvite} />
        </div>
      </section>
    </>
  );
}
