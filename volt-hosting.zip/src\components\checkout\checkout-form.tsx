"use client";

import { useActionState, useState, useTransition } from "react";
import {
  Check,
  CreditCard,
  Cpu,
  Database,
  HardDrive,
  Loader2,
  Lock,
  MemoryStick,
  Server,
  ShieldCheck,
  TicketPercent,
  X,
} from "lucide-react";
import { BillingTerms } from "@/components/billing-terms";
import { createOrderAction } from "@/lib/actions/checkout";
import { previewPromoAction } from "@/lib/actions/promo";
import { REGIONS } from "@/lib/defaults";
import {
  calculateCustomCents,
  cpuLabel,
  diskLabel,
  money,
  ramLabel,
  termPrice,
} from "@/lib/format";
import type { PricingSettings, Specs } from "@/lib/types";

export type CheckoutGateway = {
  id: string;
  name: string;
  type: string;
  description: string;
};

export type CheckoutConfig = {
  kind: "product" | "custom";
  productSlug: string;
  categorySlug: string;
  categoryName: string;
  itemName: string;
  description: string;
  serverName: string;
  monthlyCents: number;
  months: number;
  specs: Specs;
};

export function CheckoutForm({
  config,
  pricing,
  gateways,
  note,
  cancelled,
}: {
  config: CheckoutConfig;
  pricing: PricingSettings;
  gateways: CheckoutGateway[];
  note: string;
  cancelled?: boolean;
}) {
  const [state, action, pending] = useActionState(createOrderAction, null);
  const [months, setMonths] = useState(config.months);
  const [ramGb, setRamGb] = useState(Math.max(1, Math.round(config.specs.ramMb / 1024)));
  const [cpuCores, setCpuCores] = useState(Math.max(1, Math.round(config.specs.cpuPct / 100)));
  const [diskGb, setDiskGb] = useState(Math.max(5, Math.round(config.specs.diskMb / 1024)));
  const [backups, setBackups] = useState(config.specs.backups);
  const [region, setRegion] = useState("Frankfurt");
  const [gatewayId, setGatewayId] = useState(gateways[0]?.id ?? "");
  const [terms, setTerms] = useState(false);
  const [promoInput, setPromoInput] = useState("");
  const [promo, setPromo] = useState<{
    code: string;
    kind: "percent" | "fixed";
    value: number;
    minCents: number;
    description: string;
  } | null>(null);
  const [promoError, setPromoError] = useState("");
  const [promoPending, startPromo] = useTransition();

  const isCustom = config.kind === "custom";
  const specs: Specs = isCustom
    ? {
        ramMb: ramGb * 1024,
        cpuPct: cpuCores * 100,
        diskMb: diskGb * 1024,
        backups,
        databases: Math.max(1, Math.min(5, Math.ceil(ramGb / 4))),
        allocations: Math.max(1, Math.min(5, Math.ceil(ramGb / 8))),
        players: 0,
      }
    : config.specs;

  const monthlyCents = isCustom ? calculateCustomCents(specs, pricing) : config.monthlyCents;
  const subtotal = monthlyCents * months;
  const total = termPrice(monthlyCents, months, pricing);
  const discount = subtotal - total;
  const gateway = gateways.find((item) => item.id === gatewayId) ?? gateways[0];

  const promoCounts = Boolean(promo) && total >= (promo?.minCents ?? 0);
  const promoDiscount = !promo || !promoCounts
    ? 0
    : Math.min(
        total,
        promo.kind === "percent"
          ? Math.round((total * Math.min(100, promo.value)) / 100)
          : promo.value,
      );
  const dueToday = Math.max(0, total - promoDiscount);

  function applyPromo() {
    const code = promoInput.trim();
    if (!code) {
      setPromoError("Enter a promo code.");
      return;
    }
    setPromoError("");
    startPromo(async () => {
      const result = await previewPromoAction(code, total);
      if (!result.ok) {
        setPromo(null);
        setPromoError(result.error);
        return;
      }
      setPromo({
        code: result.code,
        kind: result.kind,
        value: result.value,
        minCents: result.minCents,
        description: result.description,
      });
      setPromoInput(result.code);
    });
  }

  function removePromo() {
    setPromo(null);
    setPromoInput("");
    setPromoError("");
  }

  const cta =
    gateway?.type === "stripe"
      ? `Continue to card payment`
      : gateway?.type === "discord"
        ? `Place order · ${money(dueToday)}`
        : gateway?.type === "manual"
          ? `Place order · ${money(dueToday)}`
          : `Complete order · ${money(dueToday)}`;

  return (
    <form action={action} className="grid items-start gap-6 lg:grid-cols-[1.15fr_0.85fr]">
      <input type="hidden" name="kind" value={config.kind} />
      <input type="hidden" name="product_slug" value={config.productSlug} />
      <input type="hidden" name="category_slug" value={config.categorySlug} />
      <input type="hidden" name="billing_months" value={months} />
      <input type="hidden" name="region" value={region} />
      <input type="hidden" name="gateway_id" value={gatewayId} />
      <input
        type="hidden"
        name="promo_code"
        value={promo && promoCounts ? promo.code : ""}
      />
      {isCustom && (
        <>
          <input type="hidden" name="ram_gb" value={ramGb} />
          <input type="hidden" name="cpu_cores" value={cpuCores} />
          <input type="hidden" name="disk_gb" value={diskGb} />
          <input type="hidden" name="backups" value={backups} />
        </>
      )}

      <div className="space-y-4">
        {cancelled && (
          <p className="rounded-xl border border-[#f3ddb6] bg-[#fffaf0] px-4 py-3 text-[0.8rem] text-[#8a5a12]">
            Payment was cancelled before it completed. Nothing was charged —
            your order is still in this tab if you want to retry.
          </p>
        )}
        {state?.error && (
          <p
            role="alert"
            className="rounded-xl border border-[#f3c6c6] bg-[#fff5f5] px-4 py-3 text-[0.8rem] text-[#a13b3b]"
          >
            {state.error}
          </p>
        )}

        {/* Step 1 — server */}
        <section className="glass rounded-2xl p-5">
          <div className="flex items-center gap-2">
            <span className="grid size-6 place-items-center rounded-full bg-[#0a63ff] text-[0.68rem] font-bold text-white">
              1
            </span>
            <h2 className="text-[0.9rem] font-semibold text-ink">Server details</h2>
          </div>

          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="server_name" className="field-label">
                Server name
              </label>
              <input
                id="server_name"
                name="server_name"
                defaultValue={config.serverName}
                required
                minLength={2}
                maxLength={48}
                placeholder="smp-season-six"
                className="input"
              />
              <p className="field-hint">Shown in the panel and on your dashboard.</p>
            </div>
            <div>
              <label htmlFor="region" className="field-label">
                Location
              </label>
              <select
                id="region"
                value={region}
                onChange={(event) => setRegion(event.target.value)}
                className="select"
              >
                {REGIONS.map((item) => (
                  <option key={item.id} value={item.name}>
                    {item.name} · {item.latency} ms
                  </option>
                ))}
              </select>
              <p className="field-hint">Pick the city closest to your players.</p>
            </div>
          </div>

          {isCustom ? (
            <div className="mt-5 space-y-4 rounded-xl border border-white/90 bg-white/45 p-4">
              <p className="text-[0.72rem] font-semibold text-ink-soft">
                Tune your {config.categoryName} build
              </p>

              <div className="grid gap-3 sm:grid-cols-2">
                <RangeField
                  id="ram"
                  label="Memory"
                  value={ramGb}
                  display={ramLabel(specs.ramMb)}
                  min={1}
                  max={32}
                  step={1}
                  onChange={setRamGb}
                />
                <RangeField
                  id="cpu"
                  label="CPU"
                  value={cpuCores}
                  display={cpuLabel(specs.cpuPct)}
                  min={1}
                  max={8}
                  step={1}
                  onChange={setCpuCores}
                />
                <RangeField
                  id="disk"
                  label="NVMe storage"
                  value={diskGb}
                  display={diskLabel(specs.diskMb)}
                  min={5}
                  max={200}
                  step={5}
                  onChange={setDiskGb}
                />
                <RangeField
                  id="backups"
                  label="Backup slots"
                  value={backups}
                  display={`${backups} slot${backups === 1 ? "" : "s"}`}
                  min={0}
                  max={10}
                  step={1}
                  onChange={setBackups}
                />
              </div>
            </div>
          ) : (
            <dl className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {[
                { icon: MemoryStick, label: "Memory", value: ramLabel(specs.ramMb) },
                { icon: Cpu, label: "CPU", value: cpuLabel(specs.cpuPct) },
                { icon: HardDrive, label: "NVMe", value: diskLabel(specs.diskMb) },
                {
                  icon: Database,
                  label: "Backups",
                  value: `${specs.backups} slot${specs.backups === 1 ? "" : "s"}`,
                },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.label}
                    className="rounded-lg border border-white/90 bg-white/55 px-2.5 py-2"
                  >
                    <dt className="flex items-center gap-1 text-[0.6rem] text-mutedblue">
                      <Icon className="size-3" />
                      {item.label}
                    </dt>
                    <dd className="mono mt-0.5 text-[0.74rem] font-semibold text-ink">
                      {item.value}
                    </dd>
                  </div>
                );
              })}
            </dl>
          )}
        </section>

        {/* Step 2 — billing */}
        <section className="glass rounded-2xl p-5">
          <div className="flex items-center gap-2">
            <span className="grid size-6 place-items-center rounded-full bg-[#0a63ff] text-[0.68rem] font-bold text-white">
              2
            </span>
            <h2 className="text-[0.9rem] font-semibold text-ink">Billing term</h2>
          </div>
          <div className="mt-4">
            <BillingTerms value={months} onChange={setMonths} pricing={pricing} />
          </div>
          <p className="mt-2 text-[0.72rem] text-mutedblue">
            {months === 1
              ? "Billed monthly, renews on the same date."
              : `Billed ${money(total)} every ${months} months. The discount is already applied.`}
          </p>
        </section>

        {/* Step 3 — payment */}
        <section className="glass rounded-2xl p-5">
          <div className="flex items-center gap-2">
            <span className="grid size-6 place-items-center rounded-full bg-[#0a63ff] text-[0.68rem] font-bold text-white">
              3
            </span>
            <h2 className="text-[0.9rem] font-semibold text-ink">Payment method</h2>
          </div>

          <div className="mt-4 space-y-2" role="radiogroup" aria-label="Payment method">
            {gateways.map((item) => {
              const selected = item.id === gatewayId;
              return (
                <label
                  key={item.id}
                  className={[
                    "flex cursor-pointer items-start gap-3 rounded-xl border px-3.5 py-3 transition",
                    selected
                      ? "border-[#9bd2ff] bg-white shadow-sm"
                      : "border-white/90 bg-white/40 hover:bg-white/70",
                  ].join(" ")}
                >
                  <input
                    type="radio"
                    name="gateway_choice"
                    value={item.id}
                    checked={selected}
                    onChange={() => setGatewayId(item.id)}
                    className="mt-1 accent-[#0a63ff]"
                  />
                  <span className="grid size-8 shrink-0 place-items-center rounded-lg border border-white bg-white/80 text-[#0a63ff]">
                    {item.type === "manual" ? (
                      <Server className="size-4" />
                    ) : item.type === "discord" ? (
                      <TicketPercent className="size-4" />
                    ) : (
                      <CreditCard className="size-4" />
                    )}
                  </span>
                  <span className="min-w-0">
                    <span className="block text-[0.82rem] font-semibold text-ink">
                      {item.name}
                    </span>
                    <span className="mt-0.5 block text-[0.72rem] leading-relaxed text-ink-soft/80">
                      {item.description}
                    </span>
                  </span>
                  {selected && (
                    <Check className="ml-auto mt-1 size-4 shrink-0 text-[#0a63ff]" />
                  )}
                </label>
              );
            })}
          </div>

          <label className="mt-4 flex cursor-pointer items-start gap-2 text-[0.74rem] leading-relaxed text-ink-soft/85">
            <input
              type="checkbox"
              name="terms"
              checked={terms}
              onChange={(event) => setTerms(event.target.checked)}
              className="mt-0.5 accent-[#0a63ff]"
            />
            <span>
              I agree to the terms of service and understand that recurring
              billing continues until I cancel.
            </span>
          </label>

          <button
            type="submit"
            disabled={pending || !terms || !gateway}
            className="btn btn-primary mt-4 w-full"
          >
            {pending ? (
              <>
                <Loader2 className="size-4 animate-spin" />
                Creating your order
              </>
            ) : (
              <>
                <Lock className="size-3.5" />
                {cta}
              </>
            )}
          </button>
          <p className="mt-2 flex items-center justify-center gap-1.5 text-center text-[0.68rem] text-mutedblue">
            <ShieldCheck className="size-3.5 text-[#0a8f5b]" />
            Your details are encrypted in transit.
          </p>
        </section>
      </div>

      {/* Summary */}
      <aside className="glass rounded-2xl p-5 lg:sticky lg:top-24">
        <div className="flex items-center justify-between">
          <h2 className="text-[0.9rem] font-semibold text-ink">Order summary</h2>
          <span className="chip text-[0.6rem]">{config.categoryName}</span>
        </div>

        <div className="mt-3 rounded-xl border border-white/90 bg-white/55 p-3">
          <p className="text-[0.84rem] font-semibold text-ink">{config.itemName}</p>
          <p className="mt-0.5 text-[0.72rem] leading-relaxed text-ink-soft/80">
            {config.description}
          </p>
        </div>

        <dl className="mt-4 space-y-1.5 text-[0.78rem]">
          <div className="flex justify-between gap-4">
            <dt className="text-mutedblue">Memory</dt>
            <dd className="mono text-ink">{ramLabel(specs.ramMb)}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-mutedblue">CPU</dt>
            <dd className="mono text-ink">{cpuLabel(specs.cpuPct)}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-mutedblue">NVMe</dt>
            <dd className="mono text-ink">{diskLabel(specs.diskMb)}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-mutedblue">Backups</dt>
            <dd className="mono text-ink">
              {specs.backups} slot{specs.backups === 1 ? "" : "s"}
            </dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-mutedblue">Location</dt>
            <dd className="text-ink">{region}</dd>
          </div>
        </dl>

        <div className="mt-4 space-y-1.5 border-t border-[#dcecfa]/80 pt-3 text-[0.78rem]">
          <div className="flex justify-between gap-4">
            <span className="text-mutedblue">
              {money(monthlyCents)} × {months} month{months === 1 ? "" : "s"}
            </span>
            <span className="mono text-ink">{money(subtotal)}</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between gap-4 text-[#177a52]">
              <span>Term discount</span>
              <span className="mono">−{money(discount)}</span>
            </div>
          )}
          {promoDiscount > 0 && (
            <div className="flex justify-between gap-4 text-[#177a52]">
              <span>Promo {promo?.code}</span>
              <span className="mono">−{money(promoDiscount)}</span>
            </div>
          )}
        </div>

        <div className="mt-4 border-t border-[#dcecfa]/80 pt-3">
          <label htmlFor="promo" className="field-label">
            Promo code
          </label>
          {promo && promoCounts ? (
            <div className="flex items-center justify-between gap-2 rounded-xl border border-[#bfe7d2] bg-[#f2fbf6] px-3 py-2">
              <span className="min-w-0">
                <span className="mono block text-[0.76rem] font-semibold text-[#0a6b45]">
                  {promo.code} applied
                </span>
                <span className="block truncate text-[0.66rem] text-[#3f7d63]">
                  {promo.description || `${money(promoDiscount)} off this order`}
                </span>
              </span>
              <button
                type="button"
                onClick={removePromo}
                aria-label="Remove promo code"
                className="grid size-6 shrink-0 place-items-center rounded-md text-[#4f8a6f] transition hover:bg-white hover:text-[#0a6b45]"
              >
                <X className="size-3.5" />
              </button>
            </div>
          ) : (
            <div className="flex gap-2">
              <input
                id="promo"
                value={promoInput}
                onChange={(event) => setPromoInput(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") {
                    event.preventDefault();
                    applyPromo();
                  }
                }}
                maxLength={32}
                autoComplete="off"
                spellCheck={false}
                placeholder="LAUNCH20"
                className="input mono text-[0.78rem] uppercase placeholder:normal-case"
              />
              <button
                type="button"
                onClick={applyPromo}
                disabled={promoPending}
                className="btn btn-secondary btn-sm shrink-0"
              >
                {promoPending ? <Loader2 className="size-3.5 animate-spin" /> : "Apply"}
              </button>
            </div>
          )}
          {promoError && (
            <p role="alert" className="mt-1.5 text-[0.7rem] leading-relaxed text-[#a13b3b]">
              {promoError}
            </p>
          )}
          {promo && !promoCounts && (
            <p className="mt-1.5 text-[0.7rem] leading-relaxed text-[#8a5a12]">
              {promo.code} needs a minimum order of {money(promo.minCents)}.
            </p>
          )}
        </div>

        <div className="mt-3 flex items-baseline justify-between border-t border-[#dcecfa]/80 pt-3">
          <span className="text-[0.82rem] font-semibold text-ink">Due today</span>
          <span className="mono tabular text-[1.5rem] font-semibold tracking-[-0.03em] text-ink">
            {money(dueToday)}
          </span>
        </div>
        <p className="mt-1 text-[0.66rem] leading-relaxed text-mutedblue">{note}</p>

        <ul className="mt-4 space-y-1.5">
          {[
            "Panel credentials emailed after payment",
            "DDoS filtering and NVMe included",
            "Cancel from your dashboard anytime",
          ].map((item) => (
            <li
              key={item}
              className="flex items-start gap-1.5 text-[0.72rem] leading-snug text-ink-soft/85"
            >
              <Check className="mt-0.5 size-3 shrink-0 text-[#0a8f5b]" />
              {item}
            </li>
          ))}
        </ul>
      </aside>
    </form>
  );
}

function RangeField({
  id,
  label,
  value,
  display,
  min,
  max,
  step,
  onChange,
}: {
  id: string;
  label: string;
  value: number;
  display: string;
  min: number;
  max: number;
  step: number;
  onChange: (value: number) => void;
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between gap-2">
        <label htmlFor={id} className="text-[0.68rem] font-medium text-mutedblue">
          {label}
        </label>
        <span className="mono text-[0.7rem] font-semibold text-ink">{display}</span>
      </div>
      <input
        id={id}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        className="range mt-1.5 w-full"
      />
    </div>
  );
}
