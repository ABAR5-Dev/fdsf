"use client";

import { useActionState } from "react";
import { CheckCircle2, Loader2, PlugZap, Save, Send } from "lucide-react";
import {
  saveDiscordAction,
  savePricingAction,
  savePterodactylAction,
  saveSiteSettingsAction,
  saveSmtpAction,
  testDiscordAction,
  testPterodactylAction,
} from "@/lib/actions/admin";
import type {
  ActionState,
  DiscordSettings,
  PricingSettings,
  PterodactylSettings,
  SiteSettings,
  SmtpSettings,
} from "@/lib/types";

function Feedback({ state }: { state: ActionState }) {
  if (!state) return null;
  if (state.error) {
    return (
      <p
        role="alert"
        className="rounded-lg border border-[#f3c6c6] bg-[#fff5f5] px-3 py-2 text-[0.76rem] leading-relaxed text-[#a13b3b]"
      >
        {state.error}
      </p>
    );
  }
  if (state.success) {
    return (
      <p className="flex items-center gap-1.5 rounded-lg border border-[#c4e8d5] bg-[#f2fbf6] px-3 py-2 text-[0.76rem] text-[#0a7a4e]">
        <CheckCircle2 className="size-3.5 shrink-0" />
        {state.success}
      </p>
    );
  }
  return null;
}

function SaveButton({ pending, label = "Save" }: { pending: boolean; label?: string }) {
  return (
    <button type="submit" disabled={pending} className="btn btn-primary btn-sm">
      {pending ? (
        <>
          <Loader2 className="size-3.5 animate-spin" />
          Saving
        </>
      ) : (
        <>
          <Save className="size-3.5" />
          {label}
        </>
      )}
    </button>
  );
}

function dollars(cents: number) {
  return (cents / 100).toFixed(2);
}

export function SiteSettingsForm({ settings }: { settings: SiteSettings }) {
  const [state, action, pending] = useActionState(saveSiteSettingsAction, null);

  return (
    <form action={action} className="space-y-3">
      <Feedback state={state} />
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label htmlFor="siteName" className="field-label">
            Site name
          </label>
          <input
            id="siteName"
            name="siteName"
            required
            defaultValue={settings.siteName}
            className="input"
          />
        </div>
        <div>
          <label htmlFor="supportEmail" className="field-label">
            Support email
          </label>
          <input
            id="supportEmail"
            name="supportEmail"
            type="email"
            defaultValue={settings.supportEmail}
            className="input"
          />
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="tagline" className="field-label">
            Tagline
          </label>
          <input
            id="tagline"
            name="tagline"
            maxLength={160}
            defaultValue={settings.tagline}
            className="input"
          />
        </div>
        <div>
          <label htmlFor="appUrl" className="field-label">
            Public app URL
          </label>
          <input
            id="appUrl"
            name="appUrl"
            type="url"
            defaultValue={settings.appUrl}
            className="input mono text-[0.76rem]"
          />
        </div>
        <div>
          <label htmlFor="discordInvite" className="field-label">
            Discord invite
          </label>
          <input
            id="discordInvite"
            name="discordInvite"
            type="url"
            defaultValue={settings.discordInvite}
            placeholder="https://discord.gg/..."
            className="input mono text-[0.76rem]"
          />
        </div>
      </div>
      <SaveButton pending={pending} label="Save site settings" />
    </form>
  );
}

export function PricingForm({ settings }: { settings: PricingSettings }) {
  const [state, action, pending] = useActionState(savePricingAction, null);

  return (
    <form action={action} className="space-y-3">
      <Feedback state={state} />
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {[
          { name: "baseDollars", label: "Base / month", value: settings.baseCents },
          {
            name: "ramPerGbDollars",
            label: "Per GB RAM",
            value: settings.ramPerGbCents,
          },
          {
            name: "cpuPerCoreDollars",
            label: "Per CPU core",
            value: settings.cpuPerCoreCents,
          },
          {
            name: "diskPerGbDollars",
            label: "Per GB NVMe",
            value: settings.diskPerGbCents,
          },
          { name: "backupDollars", label: "Per backup slot", value: settings.backupCents },
          {
            name: "quarterlyDiscount",
            label: "Quarterly discount %",
            value: settings.quarterlyDiscount,
            step: 1,
          },
          {
            name: "yearlyDiscount",
            label: "Yearly discount %",
            value: settings.yearlyDiscount,
            step: 1,
          },
        ].map((field) => (
          <div key={field.name}>
            <label htmlFor={field.name} className="field-label">
              {field.label}
            </label>
            <input
              id={field.name}
              name={field.name}
              type="number"
              min={0}
              step={field.step ?? "0.01"}
              defaultValue={
                field.step === 1 ? field.value : dollars(field.value)
              }
              className="input"
            />
          </div>
        ))}
      </div>
      <p className="field-hint">
        These build the custom server price on the landing page. Catalog plans
        use their own price.
      </p>
      <SaveButton pending={pending} label="Save pricing" />
    </form>
  );
}

export function PterodactylForm({
  settings,
  hasApiKey,
}: {
  settings: PterodactylSettings;
  hasApiKey: boolean;
}) {
  const [state, action, pending] = useActionState(savePterodactylAction, null);
  const [testState, testAction, testing] = useActionState(
    testPterodactylAction,
    null,
  );

  return (
    <form action={action} className="space-y-3">
      <Feedback state={state} />
      <Feedback state={testState} />

      <div className="flex flex-wrap gap-4">
        <label className="flex items-center gap-2 text-[0.78rem] text-ink-soft">
          <input
            type="checkbox"
            name="enabled"
            defaultChecked={settings.enabled}
            className="size-4 rounded border-[#c3d6e6] accent-[#0a63ff]"
          />
          Provision servers automatically through the panel API
        </label>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label htmlFor="panelUrl" className="field-label">
            Panel URL
          </label>
          <input
            id="panelUrl"
            name="panelUrl"
            type="url"
            defaultValue={settings.panelUrl}
            placeholder="https://panel.example.com"
            className="input mono text-[0.76rem]"
          />
        </div>
        <div>
          <label htmlFor="apiKey" className="field-label">
            Application API key
          </label>
          <input
            id="apiKey"
            name="apiKey"
            type="password"
            autoComplete="off"
            placeholder={hasApiKey ? "•••••• saved — leave blank" : "ptla_..."}
            className="input mono text-[0.76rem]"
          />
        </div>
        {[
          {
            name: "defaultNodeId",
            label: "Default node id",
            value: settings.defaultNodeId,
          },
          {
            name: "defaultNestId",
            label: "Default nest id",
            value: settings.defaultNestId,
          },
          {
            name: "defaultEggId",
            label: "Default egg id",
            value: settings.defaultEggId,
          },
          {
            name: "defaultAllocationId",
            label: "Default allocation id",
            value: settings.defaultAllocationId,
          },
          {
            name: "defaultDockerImage",
            label: "Default docker image",
            value: settings.defaultDockerImage,
          },
        ].map((field) => (
          <div key={field.name}>
            <label htmlFor={field.name} className="field-label">
              {field.label}
            </label>
            <input
              id={field.name}
              name={field.name}
              defaultValue={field.value}
              className="input mono text-[0.76rem]"
            />
          </div>
        ))}
        <div className="sm:col-span-2">
          <label htmlFor="defaultStartup" className="field-label">
            Default startup command
          </label>
          <input
            id="defaultStartup"
            name="defaultStartup"
            defaultValue={settings.defaultStartup}
            className="input mono text-[0.76rem]"
          />
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="defaultEnvironment" className="field-label">
            Default environment (JSON)
          </label>
          <textarea
            id="defaultEnvironment"
            name="defaultEnvironment"
            rows={4}
            defaultValue={settings.defaultEnvironment}
            className="textarea mono text-[0.76rem]"
          />
        </div>
      </div>

      <p className="field-hint">
        Create the key in the panel under Admin → Application API with read and
        write scopes for servers, users and nodes. Categories and products can
        override the egg values above.
      </p>

      <div className="flex flex-wrap gap-2">
        <SaveButton pending={pending} label="Save Pterodactyl settings" />
        <button
          type="submit"
          formAction={testAction}
          disabled={testing}
          className="btn btn-secondary btn-sm"
        >
          {testing ? (
            <>
              <Loader2 className="size-3.5 animate-spin" />
              Testing
            </>
          ) : (
            <>
              <PlugZap className="size-3.5" />
              Test connection
            </>
          )}
        </button>
      </div>
    </form>
  );
}

export function SmtpForm({
  settings,
  hasPassword,
}: {
  settings: SmtpSettings;
  hasPassword: boolean;
}) {
  const [state, action, pending] = useActionState(saveSmtpAction, null);

  return (
    <form action={action} className="space-y-3">
      <Feedback state={state} />

      <label className="flex items-center gap-2 text-[0.78rem] text-ink-soft">
        <input
          type="checkbox"
          name="enabled"
          defaultChecked={settings.enabled}
          className="size-4 rounded border-[#c3d6e6] accent-[#0a63ff]"
        />
        Send transactional email (credentials, invoices, ticket replies)
      </label>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label htmlFor="host" className="field-label">
            SMTP host
          </label>
          <input
            id="host"
            name="host"
            defaultValue={settings.host}
            placeholder="smtp.gmail.com"
            className="input"
          />
        </div>
        <div>
          <label htmlFor="port" className="field-label">
            Port
          </label>
          <input
            id="port"
            name="port"
            type="number"
            min={1}
            max={65535}
            defaultValue={settings.port}
            className="input"
          />
        </div>
        <div>
          <label htmlFor="user" className="field-label">
            Username
          </label>
          <input
            id="user"
            name="user"
            defaultValue={settings.user}
            placeholder="you@gmail.com"
            autoComplete="off"
            className="input"
          />
        </div>
        <div>
          <label htmlFor="pass" className="field-label">
            Password / app password
          </label>
          <input
            id="pass"
            name="pass"
            type="password"
            autoComplete="off"
            placeholder={hasPassword ? "•••••• saved — leave blank" : "16-character app password"}
            className="input"
          />
        </div>
        <div>
          <label htmlFor="fromName" className="field-label">
            From name
          </label>
          <input
            id="fromName"
            name="fromName"
            defaultValue={settings.fromName}
            className="input"
          />
        </div>
        <div>
          <label htmlFor="fromEmail" className="field-label">
            From email
          </label>
          <input
            id="fromEmail"
            name="fromEmail"
            type="email"
            defaultValue={settings.fromEmail}
            className="input"
          />
        </div>
      </div>

      <label className="flex items-center gap-2 text-[0.78rem] text-ink-soft">
        <input
          type="checkbox"
          name="secure"
          defaultChecked={settings.secure}
          className="size-4 rounded border-[#c3d6e6] accent-[#0a63ff]"
        />
        Use TLS on connect (port 465). Leave off for STARTTLS on 587.
      </label>

      <p className="field-hint">
        Gmail requires an App Password, not the account password. Every send is
        recorded in the email log with its result.
      </p>

      <SaveButton pending={pending} label="Save SMTP settings" />
    </form>
  );
}

function DiscordPreview({
  username,
  iconUrl,
}: {
  username: string;
  iconUrl: string;
}) {
  const avatar = iconUrl.trim();
  return (
    <div className="rounded-xl bg-[#313338] p-3 text-[#dbdee1]">
      <div className="flex items-center gap-2 text-[0.7rem] text-[#949ba4]">
        <span className="font-semibold text-[#f2f3f5]"># notifications</span>
        <span className="rounded bg-[#5865f2]/25 px-1.5 py-0.5 text-[0.62rem] font-semibold text-[#a5adff]">
          preview
        </span>
      </div>
      <div className="mt-3 flex gap-2.5 border-l-4 border-[#10b981] bg-[#2b2d31] px-3 py-2.5">
        <div className="mt-0.5 grid size-7 shrink-0 place-items-center overflow-hidden rounded-full bg-[#5865f2] text-[0.6rem] font-bold text-white">
          {avatar ? (
            // Admins paste the URL they want, so a plain image is fine here.
            // eslint-disable-next-line @next/next/no-img-element
            <img src={avatar} alt="" className="size-7 object-cover" />
          ) : (
            (username || "VH").slice(0, 2).toUpperCase()
          )}
        </div>
        <div className="min-w-0">
          <p className="flex flex-wrap items-center gap-1.5 text-[0.72rem]">
            <span className="font-semibold text-white">{username || "Volt Hosting"}</span>
            <span className="rounded bg-[#5865f2] px-1 py-px text-[0.55rem] font-semibold uppercase tracking-wide text-white">
              app
            </span>
            <span className="text-[0.62rem] text-[#949ba4]">today</span>
          </p>
          <p className="mt-1 text-[0.68rem] text-[#b5bac1]">
            Order paid · Minecraft Obsidian — 8 GB purchased by Alex Rivera
          </p>
          <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1.5 text-[0.65rem]">
            <div>
              <p className="text-[0.58rem] uppercase tracking-wide text-[#949ba4]">Order</p>
              <p className="text-[#dbdee1]">#A1B2C3D4</p>
            </div>
            <div>
              <p className="text-[0.58rem] uppercase tracking-wide text-[#949ba4]">Total</p>
              <p className="text-[#dbdee1]">$17.91</p>
            </div>
            <div>
              <p className="text-[0.58rem] uppercase tracking-wide text-[#949ba4]">Payment</p>
              <p className="text-[#dbdee1]">UPI, GPay & more</p>
            </div>
            <div>
              <p className="text-[0.58rem] uppercase tracking-wide text-[#949ba4]">Location</p>
              <p className="text-[#dbdee1]">Frankfurt</p>
            </div>
          </div>
          <p className="mt-2 text-[0.58rem] text-[#949ba4]">
            Volt Hosting · Order paid
          </p>
        </div>
      </div>
    </div>
  );
}

export function DiscordForm({ settings }: { settings: DiscordSettings }) {
  const [state, action, pending] = useActionState(saveDiscordAction, null);
  const [testState, testAction, testing] = useActionState(
    testDiscordAction,
    null,
  );

  return (
    <div className="space-y-4">
      <form action={action} className="space-y-3">
        <Feedback state={state} />

        <div className="flex flex-wrap gap-4">
          <label className="flex items-center gap-2 text-[0.78rem] text-ink-soft">
            <input
              type="checkbox"
              name="enabled"
              defaultChecked={settings.enabled}
              className="size-4 rounded border-[#c3d6e6] accent-[#0a63ff]"
            />
            Post events to Discord
          </label>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label htmlFor="username" className="field-label">
              Sender name
            </label>
            <input
              id="username"
              name="username"
              defaultValue={settings.username}
              placeholder="Volt Hosting"
              className="input"
            />
          </div>
          <div>
            <label htmlFor="iconUrl" className="field-label">
              Sender avatar URL
            </label>
            <input
              id="iconUrl"
              name="iconUrl"
              type="url"
              defaultValue={settings.iconUrl}
              placeholder="https://cdn.example.com/logo.png"
              className="input mono text-[0.74rem]"
            />
          </div>
        </div>

        <div className="grid gap-3">
          {[
            {
              name: "signupWebhook",
              label: "Signups",
              value: settings.signupWebhook,
              hint: "New accounts",
            },
            {
              name: "purchaseWebhook",
              label: "Orders",
              value: settings.purchaseWebhook,
              hint: "Paid orders and orders waiting on UPI / GPay",
            },
            {
              name: "ticketWebhook",
              label: "Support tickets",
              value: settings.ticketWebhook,
              hint: "New customer tickets",
            },
          ].map((field) => (
            <div key={field.name}>
              <label htmlFor={field.name} className="field-label">
                {field.label}
                <span className="ml-2 font-normal text-ink-faint">{field.hint}</span>
              </label>
              <input
                id={field.name}
                name={field.name}
                type="url"
                defaultValue={field.value}
                placeholder="https://discord.com/api/webhooks/..."
                className="input mono text-[0.74rem]"
              />
            </div>
          ))}
        </div>

        <p className="field-hint">
          One webhook can serve all three; separate channels usually read better.
          Create a webhook in Discord under Channel settings → Integrations →
          Webhooks, then paste its URL here.
        </p>

        <SaveButton pending={pending} label="Save Discord settings" />
      </form>

      <div className="grid gap-3 border-t border-[#d8e8f4] pt-4 lg:grid-cols-[1fr_1.05fr]">
        <div>
          <p className="field-label">Test a feed</p>
          <p className="field-hint mb-2">
            Save first, then send a real message to the channel to confirm the
            webhook works. Tests ignore the switch above so you can check a
            channel before going live.
          </p>
          <Feedback state={testState} />
          <form action={testAction} className="mt-2 flex flex-wrap gap-2">
            {(
              [
                ["signup", "Signup"],
                ["purchase", "Order"],
                ["ticket", "Ticket"],
              ] as const
            ).map(([kind, label]) => (
              <button
                key={kind}
                type="submit"
                name="kind"
                value={kind}
                disabled={testing}
                className="btn btn-secondary btn-sm"
              >
                {testing ? (
                  <Loader2 className="size-3.5 animate-spin" />
                ) : (
                  <Send className="size-3.5" />
                )}
                Test {label}
              </button>
            ))}
          </form>
        </div>
        <DiscordPreview username={settings.username} iconUrl={settings.iconUrl} />
      </div>
    </div>
  );
}
