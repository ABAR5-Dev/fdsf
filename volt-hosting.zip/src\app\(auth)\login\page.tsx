import type { Metadata } from "next";
import { Suspense } from "react";
import { redirect } from "next/navigation";
import { AuthShell } from "@/components/auth/auth-shell";
import { LoginForm } from "@/components/auth/auth-forms";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = {
  title: "Sign in",
  description: "Sign in to your Volt Hosting account.",
};

type PageProps = { searchParams: Promise<{ next?: string }> };

function safeNext(value: string | undefined) {
  if (!value || !value.startsWith("/") || value.startsWith("//")) return undefined;
  return value;
}

export default function LoginPage({ searchParams }: PageProps) {
  return (
    <Suspense fallback={<AuthShell><AuthSkeleton /></AuthShell>}>
      <LoginGate searchParams={searchParams} />
    </Suspense>
  );
}

async function LoginGate({ searchParams }: PageProps) {
  const user = await getCurrentUser();
  const { next } = await searchParams;
  if (user) redirect(safeNext(next) ?? (user.role === "admin" ? "/admin" : "/dashboard"));
  return (
    <AuthShell>
      <LoginForm next={safeNext(next)} />
    </AuthShell>
  );
}

function AuthSkeleton() {
  return (
    <div className="space-y-3" aria-hidden="true">
      <div className="h-6 w-36 animate-pulse rounded-md bg-white/80" />
      <div className="h-3.5 w-56 animate-pulse rounded bg-white/60" />
      <div className="mt-6 h-10 animate-pulse rounded-lg bg-white/70" />
      <div className="h-10 animate-pulse rounded-lg bg-white/70" />
      <div className="h-10 animate-pulse rounded-lg bg-[#cfe9ff]" />
    </div>
  );
}
