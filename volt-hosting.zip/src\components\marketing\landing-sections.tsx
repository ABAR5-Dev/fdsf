import Link from "next/link";
import {
  ArrowRight,
  Check,
  Clock3,
  CreditCard,
  Globe2,
  Headphones,
  KeyRound,
  Layers,
  MessageSquare,
  Plus,
  ShieldCheck,
  Sparkles,
  Zap,
} from "lucide-react";
import { FAQS, NETWORK, SOCIAL_PROOF, TESTIMONIALS } from "@/lib/defaults";
import { initials } from "@/lib/format";

export function TrustStrip() {
  return (
    <div className="glass grid grid-cols-2 gap-y-5 rounded-2xl px-4 py-5 md:grid-cols-4 md:px-6">
      {SOCIAL_PROOF.map((item, index) => (
        <div
          key={item.label}
          className={[
            "px-2 text-center md:px-4",
            index > 0 ? "md:border-l md:border-[#dcecfa]" : "",
            index % 2 === 1 ? "border-l border-[#dcecfa] md:border-l" : "",
          ].join(" ")}
        >
          <p className="mono tabular text-[1.35rem] font-semibold leading-none tracking-[-0.03em] text-ink">
            {item.value}
          </p>
          <p className="mt-1.5 text-[0.72rem] text-mutedblue">{item.label}</p>
        </div>
      ))}
    </div>
  );
}

export function HowItWorks() {
  const steps = [
    {
      title: "Choose a world",
      body: "Pick a game and a plan, or slide the specs yourself. The price updates as you go — no quote forms.",
      icon: Layers,
      meta: "Takes about 40 seconds",
    },
    {
      title: "Check out",
      body: "Pay by card or bank transfer. Your order is reserved the moment checkout confirms.",
      icon: CreditCard,
      meta: "No setup fee",
    },
    {
      title: "Your panel lands",
      body: "We create your Pterodactyl account and server, then email the panel URL, username and password.",
      icon: KeyRound,
      meta: "Usually under 90 seconds",
    },
  ];

  return (
    <div className="relative grid gap-4 md:grid-cols-3">
      <div
        aria-hidden="true"
        className="absolute left-[12%] right-[12%] top-8 hidden h-px bg-gradient-to-r from-transparent via-[#9dcbf0] to-transparent md:block"
      />
      {steps.map((step, index) => {
        const Icon = step.icon;
        return (
          <div key={step.title} className="glass relative rounded-2xl p-5">
            <div className="flex items-center justify-between">
              <span className="grid size-11 place-items-center rounded-xl bg-gradient-to-br from-white to-[#dcefff] text-[#0a63ff] shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_10px_20px_-14px_rgba(10,80,160,0.5)] ring-1 ring-white">
                <Icon className="size-5" />
              </span>
              <span className="mono text-[0.68rem] font-semibold text-[#8aa9c1]">
                {String(index + 1).padStart(2, "0")}
              </span>
            </div>
            <h3 className="display-soft mt-4 text-[1.18rem] text-ink">{step.title}</h3>
            <p className="mt-1.5 text-[0.83rem] leading-relaxed text-ink-soft/85">
              {step.body}
            </p>
            <p className="mt-3 inline-flex items-center gap-1.5 text-[0.7rem] font-medium text-[#0a63ff]">
              <Clock3 className="size-3" />
              {step.meta}
            </p>
          </div>
        );
      })}
    </div>
  );
}

export function NetworkSection() {
  const hub = NETWORK[0];
  return (
    <div className="grid items-center gap-8 lg:grid-cols-[0.92fr_1.08fr]">
      <div>
        <span className="chip chip-accent">
          <Globe2 className="size-3.5" />
          Eight edge locations
        </span>
        <h2 className="display mt-4 max-w-[16ch] text-[2rem] text-ink sm:text-[2.6rem]">
          Close enough to feel local.
        </h2>
        <p className="lede mt-4 max-w-[46ch] text-[0.95rem]">
          Every location runs the same Ryzen 9 and NVMe platform, behind a
          filtered 10 Gbps uplink. Choose the city your players live in and the
          ping chart does the rest.
        </p>

        <div className="mt-6 grid max-w-lg grid-cols-2 gap-3">
          {[
            { icon: Zap, label: "10 Gbps uplink", value: "per node" },
            { icon: ShieldCheck, label: "Game-aware DDoS rules", value: "always on" },
            { icon: Clock3, label: "Network uptime", value: "99.99%" },
            { icon: Headphones, label: "Human support", value: "24/7" },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.label}
                className="flex items-center gap-2.5 rounded-xl border border-white/80 bg-white/45 px-3 py-2.5 backdrop-blur-md"
              >
                <Icon className="size-4 shrink-0 text-[#0a7fd0]" />
                <div className="min-w-0">
                  <p className="truncate text-[0.76rem] font-semibold text-ink">
                    {item.label}
                  </p>
                  <p className="text-[0.66rem] text-mutedblue">{item.value}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="glass-tint relative aspect-[4/3] overflow-hidden rounded-3xl p-4 sm:p-5">
        <div className="absolute inset-0 opacity-[0.5] [background-image:radial-gradient(rgba(10,99,255,0.22)_1px,transparent_1px)] [background-size:18px_18px]" />
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_55%_at_55%_35%,rgba(120,205,255,0.35),transparent_70%)]" />

        <div className="relative mb-3 flex items-center justify-between">
          <p className="text-[0.78rem] font-semibold text-ink">Volt network</p>
          <span className="mono text-[0.64rem] text-mutedblue">fra-03 · 18 ms</span>
        </div>

        <div className="relative h-[calc(100%-2rem)] w-full">
          <svg
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
            className="absolute inset-0 h-full w-full"
            aria-hidden="true"
          >
            {NETWORK.slice(1).map((city) => {
              const midX = (hub.x + city.x) / 2;
              const midY = Math.min(hub.y, city.y) - 12;
              return (
                <path
                  key={city.code}
                  d={`M ${hub.x} ${hub.y} Q ${midX} ${midY} ${city.x} ${city.y}`}
                  fill="none"
                  stroke="rgba(10,99,255,0.28)"
                  strokeWidth="0.35"
                  strokeDasharray="1.4 1.5"
                />
              );
            })}
          </svg>

          {NETWORK.map((city) => {
            const isHub = city.code === "FRA";
            return (
              <div
                key={city.code}
                className="group absolute -translate-x-1/2 -translate-y-1/2"
                style={{ left: `${city.x}%`, top: `${city.y}%` }}
              >
                <span
                  className={[
                    "block rounded-full ring-2 ring-white/90",
                    isHub
                      ? "live-dot size-3 bg-[#0a63ff] shadow-[0_0_0_5px_rgba(10,99,255,0.16)]"
                      : "size-2 bg-[#1aa3e8] shadow-[0_0_0_3px_rgba(26,163,232,0.14)]",
                  ].join(" ")}
                  aria-hidden="true"
                />
                <span className="pointer-events-none absolute left-1/2 top-full mt-1.5 hidden -translate-x-1/2 whitespace-nowrap rounded-md border border-white/90 bg-white/90 px-1.5 py-0.5 text-[0.58rem] font-semibold text-ink shadow-sm backdrop-blur group-hover:block">
                  {city.city} · {city.latency}
                </span>
                <span
                  className={[
                    "pointer-events-none absolute left-1/2 top-full mt-1.5 -translate-x-1/2 whitespace-nowrap text-[0.55rem] font-semibold",
                    isHub ? "text-[#0a4bb0]" : "text-ink-soft/70",
                    "group-hover:hidden",
                  ].join(" ")}
                >
                  {city.code}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export function FaqSection() {
  return (
    <div className="grid gap-8 lg:grid-cols-[0.8fr_1.2fr]">
      <div>
        <span className="chip">Straight answers</span>
        <h2 className="display mt-4 max-w-[13ch] text-[2rem] text-ink sm:text-[2.5rem]">
          The questions before the checkout.
        </h2>
        <p className="lede mt-4 max-w-[38ch] text-[0.92rem]">
          Still unsure? Open a ticket or join the Discord. A person answers, not
          a macro.
        </p>
        <Link href="/support" className="btn btn-secondary btn-sm mt-5">
          <MessageSquare className="size-4" />
          Ask support
        </Link>
      </div>

      <div className="glass overflow-hidden rounded-2xl">
        {FAQS.map((item) => (
          <details key={item.q} className="group border-b border-[#dcecfa]/80 last:border-0">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-4 px-5 py-4">
              <span className="text-[0.9rem] font-semibold text-ink">
                {item.q}
              </span>
              <span className="grid size-7 shrink-0 place-items-center rounded-full border border-white bg-white/70 text-[#0a63ff] transition-transform duration-300 group-open:rotate-45">
                <Plus className="size-3.5" />
              </span>
            </summary>
            <div className="px-5 pb-4 pr-12 text-[0.84rem] leading-[1.7] text-ink-soft/85">
              {item.a}
            </div>
          </details>
        ))}
      </div>
    </div>
  );
}

export function Testimonials() {
  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <span className="chip">From the server owners</span>
          <h2 className="display mt-4 max-w-[17ch] text-[2rem] text-ink sm:text-[2.5rem]">
            The quiet reviews are the good ones.
          </h2>
        </div>
        <div className="flex items-center gap-2 text-[0.78rem] text-mutedblue">
          <span className="flex gap-0.5 text-[#f0a63a]">
            {[0, 1, 2, 3, 4].map((star) => (
              <Sparkles key={star} className="size-3.5 fill-current" />
            ))}
          </span>
          4.9 average across 1,284 tickets
        </div>
      </div>

      <div className="mt-7 grid gap-4 md:grid-cols-[1.15fr_0.85fr]">
        <figure className="glass relative flex flex-col justify-between overflow-hidden rounded-2xl p-6 sm:p-8">
          <span
            aria-hidden="true"
            className="pointer-events-none absolute -right-10 -top-16 size-56 rounded-full bg-[radial-gradient(circle,rgba(60,180,255,0.3),transparent_70%)]"
          />
          <blockquote className="display-soft relative text-[1.35rem] leading-[1.32] text-ink sm:text-[1.55rem]">
            “{TESTIMONIALS[0].quote}”
          </blockquote>
          <figcaption className="mt-6 flex items-center gap-3">
            <span className="grid size-9 place-items-center rounded-full bg-gradient-to-br from-[#d8ecff] to-white text-[0.7rem] font-bold text-[#0a4bb0] ring-1 ring-white">
              {initials(TESTIMONIALS[0].name)}
            </span>
            <span>
              <span className="block text-[0.82rem] font-semibold text-ink">
                {TESTIMONIALS[0].name}
              </span>
              <span className="block text-[0.72rem] text-mutedblue">
                {TESTIMONIALS[0].role}
              </span>
            </span>
          </figcaption>
        </figure>

        <div className="grid gap-4">
          {TESTIMONIALS.slice(1).map((item) => (
            <figure key={item.name} className="glass-quiet rounded-2xl p-5">
              <blockquote className="text-[0.88rem] leading-[1.62] text-ink-soft">
                “{item.quote}”
              </blockquote>
              <figcaption className="mt-4 flex items-center gap-2.5">
                <span className="grid size-7 place-items-center rounded-full bg-white text-[0.6rem] font-bold text-[#0a4bb0] ring-1 ring-white">
                  {initials(item.name)}
                </span>
                <span className="text-[0.74rem]">
                  <span className="font-semibold text-ink">{item.name}</span>
                  <span className="text-mutedblue"> · {item.role}</span>
                </span>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </div>
  );
}

export function FinalCta({ discordInvite }: { discordInvite: string }) {
  return (
    <div className="console noise relative overflow-hidden rounded-[26px] px-6 py-10 text-center sm:px-10 sm:py-14">
      <div className="console-grid pointer-events-none absolute inset-0 opacity-60" />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-0 h-64 w-[36rem] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(circle,rgba(48,178,255,0.4),transparent_70%)] blur-2xl"
      />
      <div className="relative mx-auto max-w-[42rem]">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-[#7ecdff]/25 bg-[#7ecdff]/10 px-3 py-1 text-[0.68rem] font-semibold text-[#a9e6ff]">
          <span className="live-dot size-1.5 rounded-full bg-[#5be3a6]" />
          Nodes are awake
        </span>
        <h2 className="display mt-5 text-[2rem] text-white sm:text-[2.9rem]">
          Your next world is one checkout away.
        </h2>
        <p className="mx-auto mt-4 max-w-[36ch] text-[0.92rem] leading-relaxed text-[#a6c8dd]">
          Pick a plan and let provisioning do the boring part. If anything goes
          sideways, a human is one ticket away.
        </p>
        <div className="mt-7 flex flex-wrap items-center justify-center gap-2.5">
          <Link href="/store" className="btn btn-primary btn-lg">
            Browse game servers
            <ArrowRight className="size-4" />
          </Link>
          <a
            href={discordInvite || "#"}
            target="_blank"
            rel="noreferrer"
            className="btn btn-lg border border-[#7ecdff]/25 bg-[#7ecdff]/10 text-[#cdeeff] hover:bg-[#7ecdff]/16"
          >
            <MessageSquare className="size-4" />
            Join the Discord
          </a>
        </div>
        <p className="mt-4 inline-flex items-center gap-1.5 text-[0.7rem] text-[#7fa9c4]">
          <Check className="size-3.5 text-[#5be3a6]" />
          Real people on support, every day of the week
        </p>
      </div>
    </div>
  );
}
