"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "../db";
import { getCurrentUser } from "../auth";
import {
  getCategoryById,
  getCategoryBySlug,
  getGatewayById,
  getOrderById,
  getProductById,
  getPterodactyl,
  getServerById,
  getSmtp,
  getTicketById,
  getUserById,
  setSetting,
} from "../queries";
import { encryptSecret } from "../crypto";
import { slugify } from "../format";
import { sendTicketReplyEmail } from "../mail";
import { markOrderPaid } from "../provision";
import { sendDiscordTest } from "../discord";
import { normalizePromoCode } from "../promo";
import {
  suspendPanelServer,
  unsuspendPanelServer,
  testPterodactyl,
} from "../pterodactyl";
import { syncServerStatus } from "../provision";
import type {
  ActionState,
  DiscordSettings,
  GatewayType,
  PaymentSettings,
  PricingSettings,
  PterodactylSettings,
  SiteSettings,
  TicketPriority,
  TicketStatus,
} from "../types";

async function requireAdmin(): Promise<
  { ok: true; id: string; name: string } | { ok: false; error: string }
> {
  const user = await getCurrentUser();
  if (!user) return { ok: false, error: "Your session expired. Sign in again." };
  if (user.role !== "admin") {
    return { ok: false, error: "Admin access is required." };
  }
  return { ok: true, id: user.id, name: user.name };
}

function str(form: FormData, key: string): string {
  return String(form.get(key) ?? "").trim();
}

function num(form: FormData, key: string, fallback = 0, min = 0, max = 1e9) {
  const value = Number(form.get(key));
  if (!Number.isFinite(value)) return fallback;
  return Math.min(max, Math.max(min, Math.round(value)));
}

function bool(form: FormData, key: string): boolean {
  return form.get(key) === "on" || form.get(key) === "true";
}

function uniqueSlug(
  table: "products" | "categories",
  name: string,
  ownId?: string,
): string {
  const base = slugify(name) || "item";
  let candidate = base;
  let counter = 2;
  for (;;) {
    const row = db
      .prepare(`SELECT id FROM ${table} WHERE slug = ?`)
      .get(candidate) as { id: string } | undefined;
    if (!row || row.id === ownId) return candidate;
    candidate = `${base}-${counter++}`;
  }
}

function refreshStore() {
  revalidatePath("/");
  revalidatePath("/store");
  revalidatePath("/admin/products");
  revalidatePath("/admin/categories");
  revalidatePath("/checkout");
}

/* -------------------------------------------------------------------------- */
/*                                   Catalog                                  */
/* -------------------------------------------------------------------------- */

export async function saveProductAction(
  _prev: ActionState,
  form: FormData,
): Promise<ActionState> {
  const admin = await requireAdmin();
  if (!admin.ok) return { error: admin.error };

  const id = str(form, "id");
  const name = str(form, "name");
  const categoryId = str(form, "category_id");
  const description = str(form, "description");
  const features = str(form, "features")
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .slice(0, 12);

  if (name.length < 2) return { error: "Give the product a name." };
  if (!getCategoryById(categoryId)) return { error: "Choose a category." };

  const priceDollars = Number(form.get("price_dollars"));
  const priceCents = Number.isFinite(priceDollars) && priceDollars >= 0
    ? Math.round(priceDollars * 100)
    : num(form, "price_cents", 0, 100, 10_000_000);
  const ramGb = Number(form.get("ram_gb"));
  const ramMb = Number.isFinite(ramGb) && ramGb > 0
    ? Math.round(ramGb * 1024)
    : num(form, "ram_mb", 1024, 256, 262_144);
  const cpuPct = num(form, "cpu_pct", 100, 50, 1600);
  const diskGb = Number(form.get("disk_gb"));
  const diskMb = Number.isFinite(diskGb) && diskGb > 0
    ? Math.round(diskGb * 1024)
    : num(form, "disk_mb", 10240, 1024, 2_097_152);
  const backups = num(form, "backups", 0, 0, 50);
  const databases = num(form, "databases", 0, 0, 25);
  const allocations = num(form, "allocations", 1, 1, 25);
  const players = num(form, "players", 0, 0, 100_000);
  const sortOrder = num(form, "sort_order", 0, 0, 9999);
  const env = str(form, "environment");
  if (env) {
    try {
      JSON.parse(env);
    } catch {
      return { error: "Environment must be valid JSON (or left empty)." };
    }
  }

  const values = {
    category_id: categoryId,
    name,
    description,
    price_cents: priceCents,
    ram_mb: ramMb,
    cpu_pct: cpuPct,
    disk_mb: diskMb,
    backups,
    databases,
    allocations,
    players,
    popular: bool(form, "popular") ? 1 : 0,
    active: bool(form, "active") ? 1 : 0,
    sort_order: sortOrder,
    features: JSON.stringify(features),
    nest_id: str(form, "nest_id"),
    egg_id: str(form, "egg_id"),
    docker_image: str(form, "docker_image"),
    startup: str(form, "startup"),
    environment: env,
    allocation_id: str(form, "allocation_id"),
  };

  if (id) {
    if (!getProductById(id)) return { error: "Product not found." };
    const slug = uniqueSlug("products", name, id);
    db.prepare(
      `UPDATE products SET category_id = ?, name = ?, slug = ?, description = ?,
       price_cents = ?, ram_mb = ?, cpu_pct = ?, disk_mb = ?, backups = ?,
       databases = ?, allocations = ?, players = ?, popular = ?, active = ?,
       sort_order = ?, features = ?, nest_id = ?, egg_id = ?, docker_image = ?,
       startup = ?, environment = ?, allocation_id = ? WHERE id = ?`,
    ).run(
      values.category_id,
      values.name,
      slug,
      values.description,
      values.price_cents,
      values.ram_mb,
      values.cpu_pct,
      values.disk_mb,
      values.backups,
      values.databases,
      values.allocations,
      values.players,
      values.popular,
      values.active,
      values.sort_order,
      values.features,
      values.nest_id,
      values.egg_id,
      values.docker_image,
      values.startup,
      values.environment,
      values.allocation_id,
      id,
    );
  } else {
    const slug = uniqueSlug("products", name);
    db.prepare(
      `INSERT INTO products
       (id, category_id, name, slug, description, price_cents, ram_mb, cpu_pct, disk_mb,
        backups, databases, allocations, players, popular, active, sort_order, features,
        nest_id, egg_id, docker_image, startup, environment, allocation_id, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    ).run(
      randomUUID(),
      values.category_id,
      values.name,
      slug,
      values.description,
      values.price_cents,
      values.ram_mb,
      values.cpu_pct,
      values.disk_mb,
      values.backups,
      values.databases,
      values.allocations,
      values.players,
      values.popular,
      values.active,
      values.sort_order,
      values.features,
      values.nest_id,
      values.egg_id,
      values.docker_image,
      values.startup,
      values.environment,
      values.allocation_id,
      new Date().toISOString(),
    );
  }

  refreshStore();
  return { success: id ? "Product updated." : "Product created." };
}

export async function toggleProductAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "id");
  const row = getProductById(id);
  if (!row) redirect("/admin/products");
  db.prepare("UPDATE products SET active = ? WHERE id = ?").run(
    row.active ? 0 : 1,
    id,
  );
  refreshStore();
  revalidatePath(`/admin/products/${id}`);
  redirect("/admin/products");
}

export async function deleteProductAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "id");
  const used = db
    .prepare("SELECT COUNT(*) AS n FROM orders WHERE product_id = ?")
    .get(id) as { n: number };
  if (used.n > 0) {
    db.prepare("UPDATE products SET active = 0 WHERE id = ?").run(id);
    refreshStore();
    redirect("/admin/products?archived=1");
  }
  db.prepare("DELETE FROM products WHERE id = ?").run(id);
  refreshStore();
  redirect("/admin/products?deleted=1");
}

export async function saveCategoryAction(
  _prev: ActionState,
  form: FormData,
): Promise<ActionState> {
  const admin = await requireAdmin();
  if (!admin.ok) return { error: admin.error };

  const id = str(form, "id");
  const name = str(form, "name");
  const tagline = str(form, "tagline");
  const description = str(form, "description");
  const accent = str(form, "accent") || "#0a63ff";
  const env = str(form, "environment");

  if (name.length < 2) return { error: "Give the category a name." };
  if (env) {
    try {
      JSON.parse(env);
    } catch {
      return { error: "Environment must be valid JSON (or left empty)." };
    }
  }

  const values = {
    name,
    tagline,
    description,
    icon: str(form, "icon") || "gamepad-2",
    accent,
    sort_order: num(form, "sort_order", 0, 0, 999),
    active: bool(form, "active") ? 1 : 0,
    nest_id: str(form, "nest_id"),
    egg_id: str(form, "egg_id"),
    docker_image: str(form, "docker_image"),
    startup: str(form, "startup"),
    environment: env,
  };

  if (id) {
    if (!getCategoryById(id)) return { error: "Category not found." };
    const slug = uniqueSlug("categories", name, id);
    db.prepare(
      `UPDATE categories SET name = ?, slug = ?, tagline = ?, description = ?,
       icon = ?, accent = ?, sort_order = ?, active = ?, nest_id = ?, egg_id = ?,
       docker_image = ?, startup = ?, environment = ? WHERE id = ?`,
    ).run(
      values.name,
      slug,
      values.tagline,
      values.description,
      values.icon,
      values.accent,
      values.sort_order,
      values.active,
      values.nest_id,
      values.egg_id,
      values.docker_image,
      values.startup,
      values.environment,
      id,
    );
  } else {
    const existing = getCategoryBySlug(slugify(name));
    if (existing) return { error: "A category with that name already exists." };
    db.prepare(
      `INSERT INTO categories
       (id, name, slug, tagline, description, icon, accent, sort_order, active,
        nest_id, egg_id, docker_image, startup, environment, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    ).run(
      randomUUID(),
      values.name,
      uniqueSlug("categories", name),
      values.tagline,
      values.description,
      values.icon,
      values.accent,
      values.sort_order,
      values.active,
      values.nest_id,
      values.egg_id,
      values.docker_image,
      values.startup,
      values.environment,
      new Date().toISOString(),
    );
  }

  refreshStore();
  return { success: id ? "Category updated." : "Category created." };
}

export async function toggleCategoryAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "id");
  const row = getCategoryById(id);
  if (!row) redirect("/admin/categories");
  db.prepare("UPDATE categories SET active = ? WHERE id = ?").run(
    row.active ? 0 : 1,
    id,
  );
  refreshStore();
  redirect("/admin/categories");
}

/* -------------------------------------------------------------------------- */
/*                                  Payments                                  */
/* -------------------------------------------------------------------------- */

const GATEWAY_TYPES: GatewayType[] = ["stripe", "manual", "discord"];

export async function saveGatewayAction(
  _prev: ActionState,
  form: FormData,
): Promise<ActionState> {
  const admin = await requireAdmin();
  if (!admin.ok) return { error: admin.error };

  const id = str(form, "id");
  const name = str(form, "name");
  const typeRaw = str(form, "type");
  const description = str(form, "description");
  const type = GATEWAY_TYPES.includes(typeRaw as GatewayType)
    ? (typeRaw as GatewayType)
    : null;

  if (name.length < 2) return { error: "Give the payment method a name." };
  if (!type) return { error: "Choose a payment method type." };

  const existing = id ? getGatewayById(id) : undefined;
  if (id && !existing) return { error: "Payment method not found." };

  let config: Record<string, unknown> = {};
  if (existing) {
    try {
      config = JSON.parse(existing.config) as Record<string, unknown>;
    } catch {
      config = {};
    }
  }

  if (type === "manual") {
    config.instructions = str(form, "instructions");
  }
  if (type === "discord") {
    config.instructions = str(form, "instructions");
    const discordUrl = str(form, "discord_url");
    if (
      discordUrl &&
      !/^https:\/\/(discord\.gg|discord\.com\/invite)\//.test(discordUrl)
    ) {
      return {
        error: "Use a Discord invite link that starts with https://discord.gg/.",
      };
    }
    config.discordUrl = discordUrl;
  }
  if (type === "stripe") {
    const publishable = str(form, "publishable_key");
    const secret = str(form, "secret_key");
    const webhook = str(form, "webhook_secret");
    if (publishable) config.publishableKey = publishable;
    if (secret) {
      config.secretKeyEnc = encryptSecret(secret);
      delete config.secretKey;
    }
    if (webhook) {
      config.webhookSecretEnc = encryptSecret(webhook);
      delete config.webhookSecret;
    }
  }

  if (id && existing) {
    db.prepare(
      `UPDATE gateways SET name = ?, type = ?, description = ?, enabled = ?,
       config = ?, sort_order = ? WHERE id = ?`,
    ).run(
      name,
      type,
      description,
      bool(form, "enabled") ? 1 : 0,
      JSON.stringify(config),
      num(form, "sort_order", 0, 0, 999),
      id,
    );
  } else {
    db.prepare(
      `INSERT INTO gateways (id, name, type, description, enabled, config, sort_order, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    ).run(
      randomUUID(),
      name,
      type,
      description,
      bool(form, "enabled") ? 1 : 0,
      JSON.stringify(config),
      num(form, "sort_order", 0, 0, 999),
      new Date().toISOString(),
    );
  }

  revalidatePath("/admin/payments");
  revalidatePath("/checkout");
  return { success: id ? "Payment method updated." : "Payment method added." };
}

export async function toggleGatewayAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "id");
  const row = getGatewayById(id);
  if (!row) redirect("/admin/payments");
  db.prepare("UPDATE gateways SET enabled = ? WHERE id = ?").run(
    row.enabled ? 0 : 1,
    id,
  );
  revalidatePath("/admin/payments");
  revalidatePath("/checkout");
  redirect("/admin/payments");
}

export async function deleteGatewayAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "id");
  db.prepare("DELETE FROM gateways WHERE id = ?").run(id);
  revalidatePath("/admin/payments");
  revalidatePath("/checkout");
  redirect("/admin/payments?deleted=1");
}

export async function savePaymentsAction(
  _prev: ActionState,
  form: FormData,
): Promise<ActionState> {
  const admin = await requireAdmin();
  if (!admin.ok) return { error: admin.error };

  const value: PaymentSettings = {
    enabled: bool(form, "enabled"),
    currency: (str(form, "currency") || "USD").toUpperCase().slice(0, 3),
    note: str(form, "note"),
  };
  setSetting("payments", value);
  revalidatePath("/admin/payments");
  revalidatePath("/checkout");
  revalidatePath("/");
  return { success: value.enabled ? "Checkout is live." : "Checkout has been paused." };
}

/* -------------------------------------------------------------------------- */
/*                                  Settings                                  */
/* -------------------------------------------------------------------------- */

export async function saveSiteSettingsAction(
  _prev: ActionState,
  form: FormData,
): Promise<ActionState> {
  const admin = await requireAdmin();
  if (!admin.ok) return { error: admin.error };

  const name = str(form, "siteName");
  const appUrl = str(form, "appUrl").replace(/\/+$/, "");
  if (name.length < 2) return { error: "Enter the site name." };
  if (!/^https?:\/\//.test(appUrl)) {
    return { error: "App URL must start with http:// or https://." };
  }

  const value: SiteSettings = {
    siteName: name,
    tagline: str(form, "tagline"),
    supportEmail: str(form, "supportEmail"),
    appUrl,
    discordInvite: str(form, "discordInvite"),
  };
  setSetting("site", value);
  revalidatePath("/", "layout");
  return { success: "Site settings saved." };
}

export async function savePricingAction(
  _prev: ActionState,
  form: FormData,
): Promise<ActionState> {
  const admin = await requireAdmin();
  if (!admin.ok) return { error: admin.error };

  const asCents = (dollarKey: string, centKey: string, fallback: number) => {
    const dollars = form.get(dollarKey);
    if (dollars !== null && String(dollars).trim() !== "") {
      const value = Number(dollars);
      if (Number.isFinite(value) && value >= 0) {
        return Math.min(1_000_000, Math.round(value * 100));
      }
    }
    return num(form, centKey, fallback, 0, 1_000_000);
  };

  const value: PricingSettings = {
    baseCents: asCents("baseDollars", "baseCents", 0),
    ramPerGbCents: asCents("ramPerGbDollars", "ramPerGbCents", 0),
    cpuPerCoreCents: asCents("cpuPerCoreDollars", "cpuPerCoreCents", 0),
    diskPerGbCents: asCents("diskPerGbDollars", "diskPerGbCents", 0),
    backupCents: asCents("backupDollars", "backupCents", 0),
    quarterlyDiscount: num(form, "quarterlyDiscount", 0, 0, 90),
    yearlyDiscount: num(form, "yearlyDiscount", 0, 0, 90),
  };
  setSetting("pricing", value);
  revalidatePath("/", "layout");
  revalidatePath("/store");
  revalidatePath("/checkout");
  revalidatePath("/admin/settings");
  return { success: "Pricing saved." };
}

export async function savePterodactylAction(
  _prev: ActionState,
  form: FormData,
): Promise<ActionState> {
  const admin = await requireAdmin();
  if (!admin.ok) return { error: admin.error };

  const current = getPterodactyl();
  const apiKeyInput = str(form, "apiKey");
  const envInput = str(form, "defaultEnvironment");
  if (envInput) {
    try {
      JSON.parse(envInput);
    } catch {
      return { error: "Default environment must be valid JSON." };
    }
  }
  const panelUrl = str(form, "panelUrl").replace(/\/+$/, "");
  if (panelUrl && !/^https?:\/\//.test(panelUrl)) {
    return { error: "Panel URL must start with http:// or https://." };
  }

  const value: PterodactylSettings = {
    enabled: bool(form, "enabled"),
    panelUrl,
    apiKey: apiKeyInput || current.apiKey,
    defaultNodeId: str(form, "defaultNodeId"),
    defaultNestId: str(form, "defaultNestId"),
    defaultEggId: str(form, "defaultEggId"),
    defaultDockerImage: str(form, "defaultDockerImage"),
    defaultStartup: str(form, "defaultStartup"),
    defaultEnvironment: envInput || current.defaultEnvironment,
    defaultAllocationId: str(form, "defaultAllocationId"),
  };
  setSetting("pterodactyl", value);
  revalidatePath("/admin/settings");
  return { success: "Pterodactyl settings saved." };
}

export async function testPterodactylAction(
  _prev: ActionState,
  form: FormData,
): Promise<ActionState> {
  const admin = await requireAdmin();
  if (!admin.ok) return { error: admin.error };

  const apiKey = str(form, "apiKey");
  const panelUrl = str(form, "panelUrl").replace(/\/+$/, "");
  const current = getPterodactyl();

  if (apiKey && apiKey !== current.apiKey) {
    setSetting("pterodactyl", { ...current, apiKey, panelUrl });
  } else if (panelUrl && panelUrl !== current.panelUrl) {
    setSetting("pterodactyl", { ...current, panelUrl });
  }

  const result = await testPterodactyl();
  revalidatePath("/admin/settings");
  if (!result.ok) return { error: `Connection failed: ${result.error}` };
  return {
    success: `Connected. ${result.nodes} node${result.nodes === 1 ? "" : "s"} visible to this application key.`,
  };
}

export async function saveSmtpAction(
  _prev: ActionState,
  form: FormData,
): Promise<ActionState> {
  const admin = await requireAdmin();
  if (!admin.ok) return { error: admin.error };

  const current = getSmtp();
  const passInput = str(form, "pass");
  const value = {
    enabled: bool(form, "enabled"),
    host: str(form, "host"),
    port: num(form, "port", 587, 1, 65_535),
    secure: bool(form, "secure"),
    user: str(form, "user"),
    pass: passInput || current.pass,
    fromName: str(form, "fromName"),
    fromEmail: str(form, "fromEmail"),
  };
  setSetting("smtp", value);
  revalidatePath("/admin/settings");
  return { success: "SMTP settings saved." };
}

export async function saveDiscordAction(
  _prev: ActionState,
  form: FormData,
): Promise<ActionState> {
  const admin = await requireAdmin();
  if (!admin.ok) return { error: admin.error };

  const iconUrl = str(form, "iconUrl");
  const value: DiscordSettings = {
    enabled: bool(form, "enabled"),
    username: str(form, "username") || "Volt Hosting",
    iconUrl,
    signupWebhook: str(form, "signupWebhook"),
    purchaseWebhook: str(form, "purchaseWebhook"),
    ticketWebhook: str(form, "ticketWebhook"),
  };
  if (iconUrl && !/^https?:\/\//.test(iconUrl)) {
    return { error: "The avatar URL must start with https://." };
  }
  for (const url of [
    value.signupWebhook,
    value.purchaseWebhook,
    value.ticketWebhook,
  ]) {
    if (url && !/^https:\/\/discord(app)?\.com\/api\/webhooks\//.test(url)) {
      return { error: "Discord webhook URLs must start with https://discord.com/api/webhooks/." };
    }
  }
  setSetting("discord", value);
  revalidatePath("/admin/settings");
  return { success: "Discord settings saved." };
}

export async function testDiscordAction(
  _prev: ActionState,
  form: FormData,
): Promise<ActionState> {
  const admin = await requireAdmin();
  if (!admin.ok) return { error: admin.error };

  const kind = str(form, "kind");
  if (kind !== "signup" && kind !== "purchase" && kind !== "ticket") {
    return { error: "Choose which feed to test." };
  }

  const result = await sendDiscordTest(kind);
  if (!result.ok) {
    return {
      error: result.error
        ? `Discord rejected the test: ${result.error}`
        : "The test notification could not be sent.",
    };
  }
  if (result.skipped) {
    return {
      error:
        "Discord notifications are off, or this feed has no webhook yet. Save your changes and try again.",
    };
  }
  return { success: "Test notification sent. Check the channel." };
}

/* -------------------------------------------------------------------------- */
/*                                Promo codes                                 */
/* -------------------------------------------------------------------------- */

export async function savePromoCodeAction(
  _prev: ActionState,
  form: FormData,
): Promise<ActionState> {
  const admin = await requireAdmin();
  if (!admin.ok) return { error: admin.error };

  const id = str(form, "id");
  const code = normalizePromoCode(str(form, "code"));
  const description = str(form, "description").slice(0, 200);
  const kindRaw = str(form, "kind");
  const kind = kindRaw === "fixed" ? "fixed" : "percent";
  const valueInput = Number(form.get("value"));
  const minCents = Math.max(0, Math.round(Number(form.get("min_dollars")) * 100) || 0);
  const maxUses = num(form, "max_uses", 0, 0, 1_000_000);
  const expiresRaw = str(form, "expires_at");
  const active = bool(form, "active") ? 1 : 0;

  if (code.length < 3 || code.length > 32) {
    return { error: "Codes need 3 to 32 characters." };
  }
  if (!/^[A-Z0-9_-]+$/.test(code)) {
    return { error: "Use letters, numbers, dashes or underscores only." };
  }
  if (!Number.isFinite(valueInput) || valueInput <= 0) {
    return { error: "Set a discount greater than zero." };
  }

  const value =
    kind === "percent" ? Math.round(valueInput) : Math.round(valueInput * 100);
  if (kind === "percent" && (value < 1 || value > 100)) {
    return { error: "A percentage discount must be between 1 and 100." };
  }
  if (kind === "fixed" && value < 1) {
    return { error: "A fixed discount must be at least $0.01." };
  }

  let expiresAt: string | null = null;
  if (expiresRaw) {
    const parsed = new Date(`${expiresRaw}T23:59:59`);
    if (Number.isNaN(parsed.getTime())) {
      return { error: "That expiry date is not valid." };
    }
    expiresAt = parsed.toISOString();
  }

  const clash = db
    .prepare("SELECT id FROM promo_codes WHERE code = ? COLLATE NOCASE")
    .get(code) as { id: string } | undefined;
  if (clash && clash.id !== id) {
    return { error: "Another promo code already uses that code." };
  }

  if (id) {
    const existing = db
      .prepare("SELECT id FROM promo_codes WHERE id = ?")
      .get(id) as { id: string } | undefined;
    if (!existing) return { error: "Promo code not found." };
    db.prepare(
      `UPDATE promo_codes SET code = ?, description = ?, kind = ?, value = ?,
       min_cents = ?, max_uses = ?, expires_at = ?, active = ? WHERE id = ?`,
    ).run(
      code,
      description,
      kind,
      value,
      minCents,
      maxUses,
      expiresAt,
      active,
      id,
    );
    revalidatePath("/admin/promotions");
    revalidatePath(`/admin/promotions/${id}`);
    revalidatePath("/checkout");
    return { success: "Promo code updated." };
  }

  db.prepare(
    `INSERT INTO promo_codes
     (id, code, description, kind, value, min_cents, max_uses, used_count,
      expires_at, active, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?)`,
  ).run(
    randomUUID(),
    code,
    description,
    kind,
    value,
    minCents,
    maxUses,
    expiresAt,
    active,
    new Date().toISOString(),
  );
  revalidatePath("/admin/promotions");
  revalidatePath("/checkout");
  return { success: "Promo code created." };
}

export async function togglePromoCodeAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "id");
  const row = db
    .prepare("SELECT active FROM promo_codes WHERE id = ?")
    .get(id) as { active: number } | undefined;
  if (!row) redirect("/admin/promotions");
  db.prepare("UPDATE promo_codes SET active = ? WHERE id = ?").run(
    row.active ? 0 : 1,
    id,
  );
  revalidatePath("/admin/promotions");
  revalidatePath(`/admin/promotions/${id}`);
  revalidatePath("/checkout");
  redirect("/admin/promotions");
}

export async function deletePromoCodeAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "id");
  db.prepare("DELETE FROM promo_codes WHERE id = ?").run(id);
  revalidatePath("/admin/promotions");
  revalidatePath("/checkout");
  redirect("/admin/promotions");
}

/* -------------------------------------------------------------------------- */
/*                                   Orders                                   */
/* -------------------------------------------------------------------------- */

export async function markOrderPaidAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "order_id");
  const order = getOrderById(id);
  if (!order) redirect("/admin/orders");
  await markOrderPaid(id, `manual-${admin.name}`);
  revalidatePath("/admin/orders");
  revalidatePath(`/admin/orders/${id}`);
  revalidatePath("/dashboard");
  redirect(`/admin/orders/${id}`);
}

export async function retryProvisionAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "order_id");
  const order = getOrderById(id);
  if (!order) redirect("/admin/orders");
  await markOrderPaid(id, order.gateway_ref ?? "retry");
  revalidatePath("/admin/orders");
  revalidatePath(`/admin/orders/${id}`);
  redirect(`/admin/orders/${id}`);
}

export async function cancelOrderAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "order_id");
  db.prepare(
    "UPDATE orders SET status = 'cancelled' WHERE id = ? AND status IN ('pending','failed')",
  ).run(id);
  revalidatePath("/admin/orders");
  revalidatePath(`/admin/orders/${id}`);
  redirect(`/admin/orders/${id}`);
}

export async function refundOrderAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "order_id");
  db.prepare("UPDATE orders SET status = 'refunded' WHERE id = ?").run(id);
  revalidatePath("/admin/orders");
  revalidatePath(`/admin/orders/${id}`);
  redirect(`/admin/orders/${id}`);
}

/* -------------------------------------------------------------------------- */
/*                                  Servers                                   */
/* -------------------------------------------------------------------------- */

export async function syncServerAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "server_id");
  await syncServerStatus(id);
  revalidatePath("/admin/servers");
  revalidatePath(`/admin/servers/${id}`);
  redirect(`/admin/servers/${id}`);
}

export async function suspendServerAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "server_id");
  const server = getServerById(id);
  if (!server) redirect("/admin/servers");

  if (server.status === "suspended") {
    if (server.panel_server_id && getPterodactyl().enabled) {
      await unsuspendPanelServer(server.panel_server_id);
    }
    db.prepare("UPDATE servers SET status = 'running' WHERE id = ?").run(id);
  } else {
    if (server.panel_server_id && getPterodactyl().enabled) {
      await suspendPanelServer(server.panel_server_id);
    }
    db.prepare("UPDATE servers SET status = 'suspended' WHERE id = ?").run(id);
  }
  revalidatePath("/admin/servers");
  revalidatePath(`/admin/servers/${id}`);
  revalidatePath("/dashboard/servers");
  redirect(`/admin/servers/${id}`);
}

export async function saveServerNotesAction(
  _prev: ActionState,
  form: FormData,
): Promise<ActionState> {
  const admin = await requireAdmin();
  if (!admin.ok) return { error: admin.error };
  const id = str(form, "server_id");
  const notes = str(form, "notes").slice(0, 4000);
  db.prepare("UPDATE servers SET notes = ? WHERE id = ?").run(notes, id);
  revalidatePath(`/admin/servers/${id}`);
  revalidatePath(`/dashboard/servers/${id}`);
  return { success: "Notes saved." };
}

/* -------------------------------------------------------------------------- */
/*                                    Users                                   */
/* -------------------------------------------------------------------------- */

export async function setUserRoleAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "user_id");
  const role = str(form, "role") === "admin" ? "admin" : "customer";
  const target = getUserById(id);
  if (!target) redirect("/admin/users");
  if (target.id === admin.id && role !== "admin") {
    redirect("/admin/users?error=self");
  }
  db.prepare("UPDATE users SET role = ? WHERE id = ?").run(role, id);
  revalidatePath("/admin/users");
  redirect("/admin/users");
}

/* -------------------------------------------------------------------------- */
/*                                   Tickets                                  */
/* -------------------------------------------------------------------------- */

export async function adminReplyTicketAction(
  _prev: ActionState,
  form: FormData,
): Promise<ActionState> {
  const admin = await requireAdmin();
  if (!admin.ok) return { error: admin.error };

  const ticketId = str(form, "ticket_id");
  const body = str(form, "message");
  const ticket = getTicketById(ticketId);
  if (!ticket) return { error: "Ticket not found." };
  if (body.length < 2) return { error: "Write a reply first." };

  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO ticket_messages (id, ticket_id, user_id, author_name, is_staff, body, created_at)
     VALUES (?, ?, ?, ?, 1, ?, ?)`,
  ).run(randomUUID(), ticket.id, admin.id, admin.name, body, now);
  db.prepare(
    "UPDATE tickets SET status = 'answered', updated_at = ? WHERE id = ?",
  ).run(now, ticket.id);

  void sendTicketReplyEmail({
    to: ticket.user_email,
    name: ticket.user_name,
    subject: ticket.subject,
    ticketId: ticket.id,
    reply: body,
  });

  revalidatePath(`/admin/tickets/${ticket.id}`);
  revalidatePath("/admin/tickets");
  revalidatePath("/dashboard/support");
  revalidatePath(`/dashboard/support/${ticket.id}`);
  return { success: "Reply sent to the customer." };
}

export async function setTicketStatusAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "ticket_id");
  const statusRaw = str(form, "status");
  const status: TicketStatus = ["open", "answered", "closed"].includes(statusRaw)
    ? (statusRaw as TicketStatus)
    : "open";
  db.prepare("UPDATE tickets SET status = ?, updated_at = ? WHERE id = ?").run(
    status,
    new Date().toISOString(),
    id,
  );
  revalidatePath(`/admin/tickets/${id}`);
  revalidatePath("/admin/tickets");
  revalidatePath("/dashboard/support");
  revalidatePath(`/dashboard/support/${id}`);
  redirect(`/admin/tickets/${id}`);
}

export async function setTicketPriorityAction(form: FormData) {
  const admin = await requireAdmin();
  if (!admin.ok) redirect("/login");
  const id = str(form, "ticket_id");
  const raw = str(form, "priority");
  const priority: TicketPriority = ["low", "normal", "high", "urgent"].includes(raw)
    ? (raw as TicketPriority)
    : "normal";
  db.prepare("UPDATE tickets SET priority = ?, updated_at = ? WHERE id = ?").run(
    priority,
    new Date().toISOString(),
    id,
  );
  revalidatePath(`/admin/tickets/${id}`);
  redirect(`/admin/tickets/${id}`);
}
