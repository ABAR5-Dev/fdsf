"use server";

import { randomUUID } from "node:crypto";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { db } from "../db";
import { getCurrentUser } from "../auth";
import { getTicketById } from "../queries";
import { notifyTicket } from "../discord";
import type { ActionState, TicketPriority } from "../types";

const PRIORITIES: TicketPriority[] = ["low", "normal", "high", "urgent"];

export async function createTicketAction(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await getCurrentUser();
  if (!user) return { error: "Your session expired. Sign in again." };

  const subject = String(formData.get("subject") ?? "").trim();
  const category = String(formData.get("category") ?? "general");
  const priorityRaw = String(formData.get("priority") ?? "normal");
  const priority = PRIORITIES.includes(priorityRaw as TicketPriority)
    ? (priorityRaw as TicketPriority)
    : "normal";
  const message = String(formData.get("message") ?? "").trim();

  if (subject.length < 4) return { error: "Add a subject with at least 4 characters." };
  if (message.length < 15) {
    return { error: "Describe the issue in a little more detail (15+ characters)." };
  }

  const id = randomUUID();
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO tickets (id, user_id, subject, category, priority, status, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, 'open', ?, ?)`,
  ).run(id, user.id, subject, category, priority, now, now);
  db.prepare(
    `INSERT INTO ticket_messages (id, ticket_id, user_id, author_name, is_staff, body, created_at)
     VALUES (?, ?, ?, ?, 0, ?, ?)`,
  ).run(randomUUID(), id, user.id, user.name, message, now);

  void notifyTicket({
    ticketId: id,
    subject,
    customer: user.name,
    priority,
    message,
  });

  revalidatePath("/dashboard/support");
  revalidatePath("/admin/tickets");
  redirect(`/dashboard/support/${id}`);
}

export async function replyTicketAction(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await getCurrentUser();
  if (!user) return { error: "Your session expired. Sign in again." };

  const ticketId = String(formData.get("ticket_id") ?? "");
  const body = String(formData.get("message") ?? "").trim();
  const ticket = getTicketById(ticketId);
  if (!ticket || ticket.user_id !== user.id) {
    return { error: "Ticket not found." };
  }
  if (ticket.status === "closed") {
    return { error: "This ticket is closed. Open a new ticket to continue." };
  }
  if (body.length < 2) return { error: "Write a reply first." };

  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO ticket_messages (id, ticket_id, user_id, author_name, is_staff, body, created_at)
     VALUES (?, ?, ?, ?, 0, ?, ?)`,
  ).run(randomUUID(), ticket.id, user.id, user.name, body, now);
  db.prepare(
    "UPDATE tickets SET status = 'open', updated_at = ? WHERE id = ?",
  ).run(now, ticket.id);

  revalidatePath(`/dashboard/support/${ticket.id}`);
  revalidatePath("/dashboard/support");
  revalidatePath("/admin/tickets");
  revalidatePath(`/admin/tickets/${ticket.id}`);
  return { success: "Reply sent." };
}

export async function closeTicketAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const ticketId = String(formData.get("ticket_id") ?? "");
  const ticket = getTicketById(ticketId);
  if (!ticket || ticket.user_id !== user.id) redirect("/dashboard/support");

  db.prepare(
    "UPDATE tickets SET status = 'closed', updated_at = ? WHERE id = ?",
  ).run(new Date().toISOString(), ticket.id);
  revalidatePath(`/dashboard/support/${ticket.id}`);
  revalidatePath("/dashboard/support");
  redirect(`/dashboard/support/${ticket.id}`);
}
