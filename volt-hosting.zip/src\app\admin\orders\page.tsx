import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { ArrowUpRight, ReceiptText, Search } from "lucide-react";
import { StatusPill } from "@/components/status-pill";
import {
  ORDER_STATUS_META,
  billingLabel,
  dateTimeLabel,
  money,
} from "@/lib/format";
import { getAllOrders } from "@/lib/queries";
import type { OrderStatus } from "@/lib/types";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Orders" };

type PageProps = {
  searchParams: Promise<{ status?: string; q?: string }>;
};

const FILTERS: { key: string; label: string; statuses: OrderStatus[] | null }[] = [
  { key: "all", label: "All", statuses: null },
  { key: "pending", label: "Pending", statuses: ["pending"] },
  {
    key: "active",
    label: "Active",
    statuses: ["paid", "provisioning", "active"],
  },
  { key: "failed", label: "Failed", statuses: ["failed"] },
  { key: "cancelled", label: "Cancelled", statuses: ["cancelled"] },
  { key: "refunded", label: "Refunded", statuses: ["refunded"] },
];

export default async function AdminOrdersPage({ searchParams }: PageProps) {
  await requireAdmin("/admin/orders");
  const { status = "all", q = "" } = await searchParams;
  const activeFilter = FILTERS.find((filter) => filter.key === status) ?? FILTERS[0];
  const query = q.trim().toLowerCase();

  const all = getAllOrders(500);
  const filtered = all.filter((order) => {
    if (
      activeFilter.statuses &&
      !activeFilter.statuses.includes(order.status)
    ) {
      return false;
    }
    if (!query) return true;
    return [order.id, order.user_name, order.user_email, order.server_name, order.item_name]
      .join(" ")
      .toLowerCase()
      .includes(query);
  });

  return (
    <div className="mx-auto max-w-[1240px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">Orders</h1>
          <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
            Every purchase, its payment state and what provisioning did with it.
          </p>
        </div>
        <span className="text-[0.74rem] text-mutedblue">
          {filtered.length} of {all.length}
        </span>
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1">
          {FILTERS.map((filter) => {
            const count = filter.statuses
              ? all.filter((order) => filter.statuses?.includes(order.status)).length
              : all.length;
            const selected = filter.key === activeFilter.key;
            return (
              <Link
                key={filter.key}
                href={`/admin/orders?status=${filter.key}${query ? `&q=${encodeURIComponent(query)}` : ""}`}
                aria-current={selected ? "page" : undefined}
                className={`rounded-full px-2.5 py-1 text-[0.72rem] font-medium transition ${
                  selected
                    ? "bg-[#0a63ff] text-white shadow-sm"
                    : "border border-white/90 bg-white/55 text-ink-soft hover:bg-white/80"
                }`}
              >
                {filter.label}
                <span
                  className={`ml-1.5 tabular text-[0.62rem] ${
                    selected ? "text-white/75" : "text-mutedblue"
                  }`}
                >
                  {count}
                </span>
              </Link>
            );
          })}
        </div>

        <form method="get" action="/admin/orders" className="relative">
          <input type="hidden" name="status" value={activeFilter.key} />
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-[#8aa8bc]" />
          <input
            name="q"
            defaultValue={q}
            placeholder="Customer, server or order id"
            className="input h-8 w-[240px] max-w-full pl-8 text-[0.74rem]"
          />
        </form>
      </div>

      <section className="glass mt-3 rounded-2xl p-2 sm:p-3">
        {filtered.length === 0 ? (
          <div className="py-14 text-center">
            <span className="mx-auto grid size-11 place-items-center rounded-xl bg-white/80 text-[#0a63ff]">
              <ReceiptText className="size-5" />
            </span>
            <p className="mt-3 text-[0.86rem] font-semibold text-ink">
              No orders in this view.
            </p>
            <p className="mt-1 text-[0.76rem] text-mutedblue">
              {query
                ? "Try a shorter search."
                : "Change the filter or wait for the first checkout."}
            </p>
          </div>
        ) : (
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th scope="col">Order</th>
                  <th scope="col">Customer</th>
                  <th scope="col">Method</th>
                  <th scope="col">Placed</th>
                  <th scope="col">Term</th>
                  <th scope="col">Total</th>
                  <th scope="col">Status</th>
                  <th scope="col" aria-label="Open" />
                </tr>
              </thead>
              <tbody>
                {filtered.map((order) => {
                  const meta = ORDER_STATUS_META[order.status] ?? ORDER_STATUS_META.pending;
                  return (
                    <tr key={order.id}>
                      <td>
                        <Link
                          href={`/admin/orders/${order.id}`}
                          className="block text-[0.8rem] font-medium text-ink hover:text-[#0a63ff]"
                        >
                          {order.item_name}
                        </Link>
                        <span className="text-[0.64rem] text-mutedblue">
                          {order.server_name} · {order.region}
                        </span>
                      </td>
                      <td>
                        <span className="block text-[0.76rem] text-ink-soft">
                          {order.user_name}
                        </span>
                        <span className="text-[0.64rem] text-mutedblue">
                          {order.user_email}
                        </span>
                      </td>
                      <td className="whitespace-nowrap text-[0.72rem] text-ink-soft">
                        {order.gateway_name ?? "—"}
                      </td>
                      <td className="whitespace-nowrap text-[0.7rem] text-mutedblue">
                        {dateTimeLabel(order.created_at)}
                      </td>
                      <td className="whitespace-nowrap text-[0.72rem] text-ink-soft">
                        {billingLabel(order.billing_months)}
                      </td>
                      <td className="mono whitespace-nowrap text-[0.76rem]">
                        {money(order.amount_cents)}
                      </td>
                      <td>
                        <StatusPill label={meta.label} tone={meta.tone} dot />
                      </td>
                      <td>
                        <Link
                          href={`/admin/orders/${order.id}`}
                          aria-label={`Open ${order.item_name} order`}
                          className="grid size-7 place-items-center rounded-lg text-[#7fa5c2] transition hover:bg-white/70 hover:text-[#0a63ff]"
                        >
                          <ArrowUpRight className="size-3.5" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
