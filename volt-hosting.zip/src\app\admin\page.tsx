import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import {
  ArrowRight,
  ArrowUpRight,
  CreditCard,
  Mail,
  PackagePlus,
  ReceiptText,
  Server,
  Ticket,
  Users,
  Wallet,
} from "lucide-react";
import { StatusPill } from "@/components/status-pill";
import {
  ORDER_STATUS_META,
  dateTimeLabel,
  initials,
  money,
  relativeTime,
} from "@/lib/format";
import {
  getAdminStats,
  getAllOrders,
  getAllServers,
  getAllTickets,
  getEmailLog,
  getPlatformCounts,
  getRecentSignups,
  getRevenueByDay,
} from "@/lib/queries";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Overview" };

function revenueSeries(days: number) {
  const rows = getRevenueByDay(days);
  const byDay = new Map(rows.map((row) => [row.day, row.cents]));
  const series: { day: string; cents: number }[] = [];
  for (let offset = days - 1; offset >= 0; offset -= 1) {
    const day = new Date(Date.now() - offset * 86_400_000)
      .toISOString()
      .slice(0, 10);
    series.push({ day, cents: byDay.get(day) ?? 0 });
  }
  return series;
}

export default async function AdminOverviewPage() {
  await requireAdmin("/admin");
  const stats = getAdminStats();
  const platform = getPlatformCounts();
  const orders = getAllOrders(6);
  const servers = getAllServers();
  const tickets = getAllTickets();
  const signups = getRecentSignups(5);
  const emailLog = getEmailLog(4);
  const series = revenueSeries(14);

  const peak = Math.max(1, ...series.map((point) => point.cents));
  const windowRevenue = series.reduce((sum, point) => sum + point.cents, 0);
  const running = servers.filter((server) => server.status === "running").length;
  const failedServers = servers.filter((server) => server.status === "failed").length;
  const openTickets = tickets.filter((ticket) => ticket.status !== "closed").length;

  const cards = [
    {
      label: "Revenue",
      value: money(stats.revenue),
      hint: `${money(windowRevenue)} in 14 days`,
      icon: Wallet,
      href: "/admin/orders",
    },
    {
      label: "Customers",
      value: String(stats.users),
      hint: `${platform.products} products live`,
      icon: Users,
      href: "/admin/users",
    },
    {
      label: "Servers",
      value: String(stats.servers),
      hint: `${running} running · ${failedServers} failed`,
      icon: Server,
      href: "/admin/servers",
    },
    {
      label: "Open tickets",
      value: String(openTickets),
      hint: `${tickets.length} all time`,
      icon: Ticket,
      href: "/admin/tickets",
    },
  ];

  return (
    <div className="mx-auto max-w-[1240px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">
            Control room
          </h1>
          <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
            Everything that moves on Volt, in one screen.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link href="/admin/products/new" className="btn btn-secondary btn-sm">
            <PackagePlus className="size-3.5" />
            Add product
          </Link>
          <Link href="/admin/orders" className="btn btn-primary btn-sm">
            <ReceiptText className="size-3.5" />
            Review orders
          </Link>
        </div>
      </div>

      {stats.pendingOrders > 0 && (
        <Link
          href="/admin/orders?status=pending"
          className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#f5e2c0] bg-[#fff8eb] px-3.5 py-2.5 text-[0.78rem] text-[#7d5410] transition hover:border-[#e9cf9a]"
        >
          <span>
            <strong className="font-semibold">
              {stats.pendingOrders} pending{" "}
              {stats.pendingOrders === 1 ? "order" : "orders"}
            </strong>{" "}
            waiting to be settled. Manual payments need a nudge.
          </span>
          <ArrowRight className="size-3.5" />
        </Link>
      )}

      <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <Link
              key={card.label}
              href={card.href}
              className="glass-quiet group rounded-2xl p-4 transition hover:-translate-y-px"
            >
              <div className="flex items-center justify-between">
                <span className="text-[0.7rem] font-medium text-mutedblue">
                  {card.label}
                </span>
                <Icon className="size-3.5 text-[#7fa5c2] transition group-hover:text-[#0a63ff]" />
              </div>
              <p className="mono tabular mt-2 text-[1.5rem] font-semibold leading-none tracking-[-0.03em] text-ink">
                {card.value}
              </p>
              <p className="mt-1 text-[0.66rem] text-mutedblue">{card.hint}</p>
            </Link>
          );
        })}
      </div>

      <div className="mt-4 grid items-start gap-4 xl:grid-cols-[1.45fr_0.55fr]">
        <section className="glass rounded-2xl p-4 sm:p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-[0.92rem] font-semibold text-ink">
                Paid, last 14 days
              </h2>
              <p className="mt-0.5 text-[0.7rem] text-mutedblue">
                {money(windowRevenue)} settled · peak day {money(peak)}
              </p>
            </div>
            <span className="inline-flex items-center gap-1 rounded-full bg-white/70 px-2 py-0.5 text-[0.64rem] font-medium text-ink-soft">
              <span className="live-dot" />
              Live
            </span>
          </div>

          <div className="mt-5 flex h-36 items-end gap-1.5">
            {series.map((point) => {
              const height = point.cents === 0 ? 3 : Math.max(8, (point.cents / peak) * 100);
              return (
                <div
                  key={point.day}
                  className="group relative flex h-full flex-1 items-end"
                  title={`${point.day}: ${money(point.cents)}`}
                >
                  <div
                    className={`w-full rounded-t-[4px] transition ${
                      point.cents === 0
                        ? "bg-[#dbe9f5]"
                        : "bg-gradient-to-t from-[#0a63ff] to-[#7cb8ff] group-hover:from-[#0a4bb0]"
                    }`}
                    style={{ height: `${height}%` }}
                  />
                </div>
              );
            })}
          </div>
          <div className="mt-2 flex justify-between text-[0.6rem] text-mutedblue">
            <span>{series[0]?.day.slice(5)}</span>
            <span>today</span>
          </div>
        </section>

        <div className="space-y-4">
          <section className="glass rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <h2 className="text-[0.88rem] font-semibold text-ink">Needs attention</h2>
              <ArrowUpRight className="size-3.5 text-[#7fa5c2]" />
            </div>
            <ul className="mt-2.5 space-y-1.5 text-[0.76rem]">
              <li>
                <Link
                  href="/admin/orders?status=pending"
                  className="flex items-center justify-between rounded-lg px-2 py-1.5 transition hover:bg-white/60"
                >
                  <span className="text-ink-soft">Pending orders</span>
                  <span className="mono font-semibold text-ink">
                    {stats.pendingOrders}
                  </span>
                </Link>
              </li>
              <li>
                <Link
                  href="/admin/tickets"
                  className="flex items-center justify-between rounded-lg px-2 py-1.5 transition hover:bg-white/60"
                >
                  <span className="text-ink-soft">Tickets waiting</span>
                  <span className="mono font-semibold text-ink">{openTickets}</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/admin/servers"
                  className="flex items-center justify-between rounded-lg px-2 py-1.5 transition hover:bg-white/60"
                >
                  <span className="text-ink-soft">Failed servers</span>
                  <span className="mono font-semibold text-ink">{failedServers}</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/admin/email"
                  className="flex items-center justify-between rounded-lg px-2 py-1.5 transition hover:bg-white/60"
                >
                  <span className="text-ink-soft">Emails sent</span>
                  <span className="mono font-semibold text-ink">{emailLog.length}</span>
                </Link>
              </li>
            </ul>
          </section>

          <section className="glass rounded-2xl p-4">
            <h2 className="text-[0.88rem] font-semibold text-ink">Latest signups</h2>
            {signups.length === 0 ? (
              <p className="mt-2 text-[0.74rem] text-mutedblue">No customers yet.</p>
            ) : (
              <ul className="mt-2.5 space-y-2">
                {signups.map((signup) => (
                  <li key={signup.id} className="flex items-center gap-2">
                    <span className="grid size-7 shrink-0 place-items-center rounded-full bg-white/80 text-[0.58rem] font-bold text-[#0a4bb0] ring-1 ring-white">
                      {initials(signup.name)}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[0.74rem] font-medium text-ink">
                        {signup.name}
                      </p>
                      <p className="truncate text-[0.64rem] text-mutedblue">
                        {signup.email}
                      </p>
                    </div>
                    <span className="shrink-0 text-[0.62rem] text-mutedblue">
                      {relativeTime(signup.created_at)}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </div>

      <section className="glass mt-4 rounded-2xl p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-[0.92rem] font-semibold text-ink">Recent orders</h2>
          <Link
            href="/admin/orders"
            className="inline-flex items-center gap-1 text-[0.72rem] font-semibold text-[#0a63ff] hover:underline"
          >
            All orders
            <ArrowRight className="size-3" />
          </Link>
        </div>

        {orders.length === 0 ? (
          <p className="py-8 text-center text-[0.8rem] text-mutedblue">
            The first order will appear here.
          </p>
        ) : (
          <div className="table-scroll mt-2">
            <table className="data-table">
              <thead>
                <tr>
                  <th scope="col">Customer</th>
                  <th scope="col">Server</th>
                  <th scope="col">Placed</th>
                  <th scope="col">Total</th>
                  <th scope="col">Status</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => {
                  const meta = ORDER_STATUS_META[order.status] ?? ORDER_STATUS_META.pending;
                  return (
                    <tr key={order.id}>
                      <td>
                        <Link
                          href={`/admin/orders/${order.id}`}
                          className="block text-[0.78rem] font-medium text-ink hover:text-[#0a63ff]"
                        >
                          {order.user_name}
                        </Link>
                        <span className="text-[0.64rem] text-mutedblue">
                          {order.user_email}
                        </span>
                      </td>
                      <td>
                        <span className="block text-[0.76rem] text-ink-soft">
                          {order.item_name}
                        </span>
                        <span className="text-[0.64rem] text-mutedblue">
                          {order.server_name}
                        </span>
                      </td>
                      <td className="whitespace-nowrap text-[0.72rem] text-mutedblue">
                        {dateTimeLabel(order.created_at)}
                      </td>
                      <td className="mono whitespace-nowrap text-[0.76rem]">
                        {money(order.amount_cents)}
                      </td>
                      <td>
                        <StatusPill label={meta.label} tone={meta.tone} dot />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {[
          {
            href: "/admin/products/new",
            label: "Add a product",
            body: `${platform.products} in the catalog`,
            icon: PackagePlus,
          },
          {
            href: "/admin/payments",
            label: "Payment methods",
            body: `${platform.gateways} configured`,
            icon: CreditCard,
          },
          {
            href: "/admin/email",
            label: "Email delivery",
            body: emailLog[0]
              ? `Last ${relativeTime(emailLog[0].created_at)}`
              : "Nothing sent yet",
            icon: Mail,
          },
          {
            href: "/admin/servers",
            label: "Fleet",
            body: `${servers.length} container${servers.length === 1 ? "" : "s"}`,
            icon: Server,
          },
        ].map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className="glass-quiet group flex items-center gap-3 rounded-2xl p-3.5 transition hover:-translate-y-px"
            >
              <span className="grid size-9 place-items-center rounded-xl bg-white/80 text-[#0a63ff] ring-1 ring-white">
                <Icon className="size-4" />
              </span>
              <div className="min-w-0">
                <p className="text-[0.78rem] font-semibold text-ink">{item.label}</p>
                <p className="truncate text-[0.66rem] text-mutedblue">{item.body}</p>
              </div>
              <ArrowUpRight className="ml-auto size-3.5 text-[#9db9cb] transition group-hover:text-[#0a63ff]" />
            </Link>
          );
        })}
      </div>
    </div>
  );
}
