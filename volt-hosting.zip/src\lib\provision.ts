import { randomUUID } from "node:crypto";
import { db } from "./db";
import {
  getCategoryById,
  getOrderById,
  getPterodactyl,
  getServerById,
  getServersForUser,
  getUserById,
} from "./queries";
import {
  createPanelServer,
  ensurePanelAccount,
  getPanelServer,
  panelServerStatus,
  serverAddress,
} from "./pterodactyl";
import {
  decryptSecret,
  encryptSecret,
  generatePanelPassword,
  usernameFromEmail,
} from "./crypto";
import { sendServerReadyEmail } from "./mail";
import { notifyPurchase } from "./discord";
import { money } from "./format";
import type {
  CategoryRow,
  OrderRow,
  ProductWithCategory,
  ServerRow,
  Specs,
  UserRow,
} from "./types";

function parseJson<T>(value: string | null | undefined, fallback: T): T {
  if (!value) return fallback;
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

function parseEnvironment(
  value: string | null | undefined,
  fallback: Record<string, string>,
): Record<string, string> {
  const parsed = parseJson<Record<string, unknown>>(value, {});
  const entries = Object.entries(parsed).filter(
    (entry): entry is [string, string] => typeof entry[1] === "string",
  );
  return entries.length ? Object.fromEntries(entries) : fallback;
}

function first(...values: (string | null | undefined)[]): string {
  return values.find((value) => value && String(value).trim().length > 0) ?? "";
}

function configFor(
  product: ProductWithCategory | undefined,
  category: CategoryRow | undefined,
) {
  const settings = getPterodactyl();
  const envString = first(
    product?.environment,
    category?.environment,
    settings.defaultEnvironment,
  );
  const fallbackEnv = parseEnvironment(settings.defaultEnvironment, {});
  return {
    settings,
    nestId: first(product?.nest_id, category?.nest_id, settings.defaultNestId),
    eggId: first(product?.egg_id, category?.egg_id, settings.defaultEggId),
    dockerImage: first(
      product?.docker_image,
      category?.docker_image,
      settings.defaultDockerImage,
    ),
    startup: first(
      product?.startup,
      category?.startup,
      settings.defaultStartup,
    ),
    environment: parseEnvironment(envString, fallbackEnv),
    allocationId: first(
      product?.allocation_id,
      settings.defaultAllocationId,
    ),
  };
}

export type ProvisionResult =
  | { ok: true; serverId: string }
  | { ok: false; error: string };

export async function provisionOrder(
  orderId: string,
): Promise<ProvisionResult> {
  const order = getOrderById(orderId);
  if (!order) return { ok: false, error: "Order not found." };

  const existing = db
    .prepare("SELECT id FROM servers WHERE order_id = ?")
    .get(order.id) as { id: string } | undefined;
  if (existing) {
    return { ok: true, serverId: existing.id };
  }

  const user = getUserById(order.user_id);
  if (!user) return { ok: false, error: "The account for this order no longer exists." };

  const product = order.product_id
    ? (db
        .prepare(
          `SELECT p.*, c.name AS category_name, c.slug AS category_slug,
                  c.icon AS category_icon, c.accent AS category_accent
           FROM products p JOIN categories c ON c.id = p.category_id
           WHERE p.id = ?`,
        )
        .get(order.product_id) as ProductWithCategory | undefined)
    : undefined;
  const category = order.category_id
    ? getCategoryById(order.category_id)
    : product
      ? getCategoryById(product.category_id)
      : undefined;

  const specs = parseJson<Partial<Specs>>(order.specs, {});
  const ramMb = Number(specs.ramMb || product?.ram_mb || 2048);
  const cpuPct = Number(specs.cpuPct || product?.cpu_pct || 100);
  const diskMb = Number(specs.diskMb || product?.disk_mb || 10240);
  const backups = Number(specs.backups ?? product?.backups ?? 0);
  const databases = Number(specs.databases ?? product?.databases ?? 0);
  const allocations = Number(specs.allocations ?? product?.allocations ?? 1);
  const config = configFor(product, category);

  const newPassword =
    decryptSecret(user.panel_password_enc) || generatePanelPassword();
  let panelUserId: number | null = null;
  let panelUsername = user.panel_username || usernameFromEmail(user.email);
  let panelPassword = newPassword;
  let panelServerId: number | null = null;
  let identifier = "";
  let address = { ip: "", port: null as number | null };

  try {
    if (!config.settings.enabled) {
      throw new Error(
        "Server provisioning is not connected yet. Add your Pterodactyl panel in Admin → Settings, or create this server by hand in the panel.",
      );
    }

    const nestId = Number(config.nestId);
    const eggId = Number(config.eggId);
    const allocationId = Number(config.allocationId);

    if (!nestId || !eggId) {
      throw new Error(
        "This product is missing its Pterodactyl nest or egg ID. Update the product or default settings.",
      );
    }
    if (!allocationId) {
      throw new Error(
        "No Pterodactyl allocation is configured. Add a default allocation ID in settings or on the product.",
      );
    }
    if (!config.dockerImage || !config.startup) {
      throw new Error(
        "This product is missing its Docker image or startup command.",
      );
    }

    const account = await ensurePanelAccount({ user, newPassword });
    panelUserId = account.id;
    panelUsername = account.username;
    panelPassword = account.password;

    const panelServer = await createPanelServer({
      name: order.server_name,
      panelUserId,
      nestId,
      eggId,
      dockerImage: config.dockerImage,
      startup: config.startup,
      environment: config.environment,
      memoryMb: ramMb,
      diskMb,
      cpuPct,
      databases,
      backups,
      allocations,
      allocationId,
    });

    panelServerId = panelServer.id;
    identifier = panelServer.identifier;
    address = serverAddress(panelServer);

    const serverId = randomUUID();
    const now = new Date();
    const renewal = new Date(
      now.getTime() + order.billing_months * 30 * 86_400_000,
    );

    db.prepare(
      `INSERT INTO servers
       (id, user_id, order_id, product_id, name, identifier, panel_server_id, panel_user_id,
        ram_mb, cpu_pct, disk_mb, backups, databases, allocations, nest_id, egg_id, docker_image,
        startup, environment, status, ip, port, region, panel_username, panel_password_enc,
        created_at, renewal_at, last_synced_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'installing', ?, ?, ?, ?, ?, ?, ?, ?)`,
    ).run(
      serverId,
      user.id,
      order.id,
      product?.id ?? null,
      order.server_name,
      identifier,
      panelServerId,
      panelUserId,
      ramMb,
      cpuPct,
      diskMb,
      backups,
      databases,
      allocations,
      config.nestId,
      config.eggId,
      config.dockerImage,
      config.startup,
      JSON.stringify(config.environment),
      address.ip,
      address.port,
      order.region || "Frankfurt",
      panelUsername,
      encryptSecret(panelPassword),
      now.toISOString(),
      renewal.toISOString(),
      now.toISOString(),
    );

    db.prepare(
      `UPDATE users SET panel_user_id = ?, panel_username = ?, panel_password_enc = ? WHERE id = ?`,
    ).run(
      panelUserId,
      panelUsername,
      encryptSecret(panelPassword),
      user.id,
    );

    db.prepare(
      `UPDATE orders SET status = 'active', paid_at = COALESCE(paid_at, ?), provision_error = NULL WHERE id = ?`,
    ).run(now.toISOString(), order.id);

    const server = getServerById(serverId);
    if (server) {
      await sendServerReadyEmail({
        user,
        server,
        order: { ...order, status: "active" },
        password: panelPassword,
      });
      await notifyPurchase({
        orderId: order.id,
        customer: user.name,
        email: user.email,
        item: order.item_name,
        amount: money(order.amount_cents),
        gateway: "Automated",
        server: server.name,
        location: server.region,
      });
    }

    return { ok: true, serverId };
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Provisioning failed.";
    db.prepare(
      `UPDATE orders SET status = 'failed', provision_error = ?, paid_at = COALESCE(paid_at, ?) WHERE id = ?`,
    ).run(message, new Date().toISOString(), order.id);

    await notifyPurchase({
      orderId: order.id,
      customer: user.name,
      email: user.email,
      item: order.item_name,
      amount: money(order.amount_cents),
      gateway: "Provisioning failed",
      server: message,
    }).catch(() => undefined);

    return { ok: false, error: message };
  }
}

export async function markOrderPaid(
  orderId: string,
  reference?: string,
): Promise<ProvisionResult> {
  const order = getOrderById(orderId);
  if (!order) return { ok: false, error: "Order not found." };
  if (order.status === "active") {
    const existing = db
      .prepare("SELECT id FROM servers WHERE order_id = ?")
      .get(order.id) as { id: string } | undefined;
    if (existing) return { ok: true, serverId: existing.id };
  }

  const firstPayment = !order.paid_at;

  db.prepare(
    `UPDATE orders SET status = 'provisioning', paid_at = ?, gateway_ref = COALESCE(?, gateway_ref) WHERE id = ?`,
  ).run(new Date().toISOString(), reference ?? null, order.id);

  if (firstPayment && order.promo_code) {
    db.prepare(
      "UPDATE promo_codes SET used_count = used_count + 1 WHERE code = ? COLLATE NOCASE",
    ).run(order.promo_code);
  }

  return provisionOrder(order.id);
}

export async function syncServerStatus(serverId: string): Promise<void> {
  const server = getServerById(serverId);
  if (!server) return;
  const config = getPterodactyl();

  if (!config.enabled || !server.panel_server_id) return;

  try {
    const panel = await getPanelServer(server.panel_server_id);
    const status = panelServerStatus(panel);
    const address = serverAddress(panel);
    db.prepare(
      `UPDATE servers SET status = ?, ip = ?, port = ?, last_synced_at = ? WHERE id = ?`,
    ).run(
      status,
      address.ip || server.ip,
      address.port ?? server.port,
      new Date().toISOString(),
      server.id,
    );
  } catch (error) {
    console.error("[pterodactyl] status sync failed:", error);
  }
}

export async function syncUserServers(userId: string): Promise<ServerRow[]> {
  const servers = getServersForUser(userId);
  await Promise.allSettled(servers.map((server) => syncServerStatus(server.id)));
  return getServersForUser(userId);
}

export { getOrderById, getUserById };
export type { OrderRow, UserRow, ServerRow };
