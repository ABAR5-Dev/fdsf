"use client";

import { useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  Bot,
  Boxes,
  CarFront,
  Check,
  ChevronRight,
  Flame,
  Gamepad2,
  Pickaxe,
  Server,
  Sparkles,
} from "lucide-react";
import { GAME_META } from "@/lib/defaults";

export type ShowcaseGame = {
  slug: string;
  name: string;
  tagline: string;
  startingAt: string;
  planCount: number;
};

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  minecraft: Pickaxe,
  fivem: CarFront,
  rust: Flame,
  samp: Gamepad2,
  "discord-bots": Bot,
  vps: Server,
};

const ORBS: Record<string, string> = {
  minecraft: "radial-gradient(60% 60% at 70% 30%, rgba(46,190,255,0.55), transparent 70%), radial-gradient(40% 40% at 20% 80%, rgba(125,240,221,0.4), transparent 70%)",
  fivem: "radial-gradient(60% 60% at 72% 26%, rgba(30,140,255,0.6), transparent 70%), radial-gradient(42% 42% at 18% 82%, rgba(18,200,255,0.4), transparent 70%)",
  rust: "radial-gradient(60% 60% at 72% 28%, rgba(229,107,47,0.55), transparent 70%), radial-gradient(44% 44% at 20% 80%, rgba(255,196,107,0.42), transparent 70%)",
  samp: "radial-gradient(60% 60% at 72% 28%, rgba(13,147,136,0.5), transparent 70%), radial-gradient(44% 44% at 20% 80%, rgba(109,242,214,0.38), transparent 70%)",
  "discord-bots": "radial-gradient(60% 60% at 72% 28%, rgba(59,108,255,0.55), transparent 70%), radial-gradient(44% 44% at 20% 80%, rgba(154,167,255,0.4), transparent 70%)",
  vps: "radial-gradient(60% 60% at 72% 28%, rgba(20,118,201,0.5), transparent 70%), radial-gradient(44% 44% at 20% 80%, rgba(102,217,255,0.38), transparent 70%)",
};

export function GameShowcase({ games }: { games: ShowcaseGame[] }) {
  const [activeSlug, setActiveSlug] = useState(games[0]?.slug ?? "minecraft");
  const active = games.find((game) => game.slug === activeSlug) ?? games[0];
  if (!active) return null;

  const meta = GAME_META[active.slug] ?? GAME_META.minecraft;
  const Icon = ICONS[active.slug] ?? Boxes;

  return (
    <div className="grid gap-3 lg:grid-cols-[320px_minmax(0,1fr)]">
      <div className="glass flex flex-col gap-1 rounded-2xl p-2">
        {games.map((game) => {
          const GameIcon = ICONS[game.slug] ?? Boxes;
          const selected = game.slug === active.slug;
          return (
            <button
              key={game.slug}
              type="button"
              onClick={() => setActiveSlug(game.slug)}
              aria-pressed={selected}
              className={[
                "group flex items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition-all duration-200",
                selected
                  ? "border-white bg-white/90 shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_10px_24px_-18px_rgba(10,80,160,0.55)]"
                  : "border-transparent hover:border-white/70 hover:bg-white/50",
              ].join(" ")}
            >
              <span
                className={[
                  "grid size-9 shrink-0 place-items-center rounded-[10px] transition-colors",
                  selected
                    ? "bg-gradient-to-br from-[#1272ff] to-[#0a4fd8] text-white"
                    : "bg-[#e8f4ff] text-[#3b78ad] group-hover:text-[#0a63ff]",
                ].join(" ")}
              >
                <GameIcon className="size-[18px]" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-baseline justify-between gap-2">
                  <span className="text-[0.9rem] font-semibold text-ink">{game.name}</span>
                  <span className="mono text-[0.72rem] font-semibold text-[#0a63ff]">
                    {game.startingAt}
                  </span>
                </span>
                <span className="mt-0.5 block truncate text-[0.72rem] text-mutedblue">
                  {game.planCount} plan{game.planCount === 1 ? "" : "s"} · {game.tagline}
                </span>
              </span>
              <ChevronRight
                className={[
                  "size-3.5 shrink-0 transition",
                  selected ? "text-[#0a63ff]" : "text-[#9fbed4]",
                ].join(" ")}
              />
            </button>
          );
        })}

        <div className="mt-auto flex items-center gap-2 px-3 py-2 text-[0.7rem] text-mutedblue">
          <Sparkles className="size-3.5 text-[#0a9ad4]" />
          Every plan includes DDoS filtering and backups.
        </div>
      </div>

      <div className="glass-tint noise relative min-h-[420px] overflow-hidden rounded-3xl p-5 sm:p-7">
        <div
          key={`${active.slug}-orb`}
          aria-hidden="true"
          className="pointer-events-none absolute -right-16 -top-20 size-[380px] rounded-full opacity-80 blur-[2px] enter"
          style={{ background: ORBS[active.slug] ?? ORBS.minecraft }}
        />
        <div
          aria-hidden="true"
          className="console-grid pointer-events-none absolute inset-0 opacity-40"
        />

        <div key={active.slug} className="relative enter">
          <div className="flex items-start justify-between gap-4">
            <span className="grid size-14 place-items-center rounded-2xl border border-white/90 bg-white/80 text-[#0a63ff] shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_16px_30px_-18px_rgba(10,80,160,0.5)] backdrop-blur-md">
              <Icon className="size-7" />
            </span>
            <span className="chip">
              <span className="size-1.5 rounded-full bg-[#20b878]" />
              {meta.statValue} {meta.statLabel}
            </span>
          </div>

          <h3 className="display-soft mt-5 max-w-[19ch] text-[1.75rem] text-ink sm:text-[2.15rem]">
            {meta.headline}
          </h3>
          <p className="mt-3 max-w-[52ch] text-[0.92rem] leading-[1.7] text-ink-soft/85">
            {meta.blurb}
          </p>

          <ul className="mt-5 grid gap-x-5 gap-y-2 sm:grid-cols-2">
            {meta.bullets.map((bullet) => (
              <li key={bullet} className="flex items-start gap-2 text-[0.82rem] text-ink-soft">
                <span className="mt-0.5 grid size-4 shrink-0 place-items-center rounded-full bg-[#dff1ff] text-[#0a63ff]">
                  <Check className="size-2.5" strokeWidth={3} />
                </span>
                {bullet}
              </li>
            ))}
          </ul>

          <div className="mt-7 flex flex-wrap items-center gap-2.5">
            <Link href={`/store/${active.slug}`} className="btn btn-primary">
              See {active.name} plans
              <ArrowRight className="size-4" />
            </Link>
            <Link
              href={`/checkout?custom=${active.slug}`}
              className="btn btn-secondary"
            >
              Build your own
            </Link>
            <span className="mono ml-1 text-[0.72rem] text-ink-soft/70">
              from {active.startingAt}/mo
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
