import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowRight, CalendarClock, CreditCard, ReceiptText, Wallet } from "lucide-react";
import { StatusPill } from "@/components/status-pill";
import { getCurrentUser } from "@/lib/auth";
import {
  ORDER_STATUS_META,
  billingLabel,
  dateLabel,
  dateTimeLabel,
  money,
} from "@/lib/format";
import {
  getGateways,
  getOrdersForUser,
  getServersForUser,
} from "@/lib/queries";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Billing" };

export default async function BillingPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/billing");

  const orders = getOrdersForUser(user.id);
  const servers = getServersForUser(user.id);
  const gateways = getGateways();
  const gatewayNames = new Map(gateways.map((gateway) => [gateway.id, gateway.name]));

  const paid = orders.filter((order) =>
    ["active", "provisioning", "paid"].includes(order.status),
  );
  const totalPaid = orders
    .filter((order) => order.status !== "cancelled" && order.status !== "refunded")
    .reduce((sum, order) => sum + order.amount_cents, 0);
  const monthlyValue = servers.reduce((sum, server) => {
    const order = orders.find((item) => item.id === server.order_id);
    return sum + (order ? Math.round(order.amount_cents / order.billing_months) : 0);
  }, 0);
  const nextRenewal = servers
    .map((server) => server.renewal_at)
    .filter((value): value is string => Boolean(value))
    .sort()[0];

  return (
    <div className="mx-auto max-w-[1120px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">Billing</h1>
          <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
            Orders, renewals and payment history in one place.
          </p>
        </div>
        <Link href="/dashboard/support/new" className="btn btn-secondary btn-sm">
          Billing question
        </Link>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        {[
          {
            label: "Monthly value",
            value: money(monthlyValue),
            hint: `${servers.length} active service${servers.length === 1 ? "" : "s"}`,
            icon: Wallet,
          },
          {
            label: "Next renewal",
            value: nextRenewal ? dateLabel(nextRenewal) : "—",
            hint: nextRenewal ? "Charged automatically" : "Nothing scheduled",
            icon: CalendarClock,
          },
          {
            label: "Lifetime orders",
            value: money(totalPaid),
            hint: `${paid.length} completed`,
            icon: ReceiptText,
          },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="glass-quiet rounded-2xl p-4">
              <div className="flex items-center justify-between">
                <span className="text-[0.7rem] font-medium text-mutedblue">
                  {stat.label}
                </span>
                <Icon className="size-3.5 text-[#7fa5c2]" />
              </div>
              <p className="mono tabular mt-2 text-[1.35rem] font-semibold leading-none tracking-[-0.03em] text-ink">
                {stat.value}
              </p>
              <p className="mt-1 text-[0.66rem] text-mutedblue">{stat.hint}</p>
            </div>
          );
        })}
      </div>

      <section className="glass mt-6 rounded-2xl p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-[0.92rem] font-semibold text-ink">Order history</h2>
          <span className="text-[0.7rem] text-mutedblue">
            {orders.length} {orders.length === 1 ? "order" : "orders"}
          </span>
        </div>

        {orders.length === 0 ? (
          <div className="py-12 text-center">
            <span className="mx-auto grid size-11 place-items-center rounded-xl bg-white/80 text-[#0a63ff]">
              <ReceiptText className="size-5" />
            </span>
            <p className="mt-3 text-[0.86rem] font-semibold text-ink">
              No orders yet.
            </p>
            <p className="mt-1 text-[0.76rem] text-mutedblue">
              Your invoices will collect here after your first deployment.
            </p>
            <Link href="/store" className="btn btn-primary btn-sm mt-4">
              Browse servers
              <ArrowRight className="size-3.5" />
            </Link>
          </div>
        ) : (
          <div className="table-scroll mt-2">
            <table className="data-table">
              <thead>
                <tr>
                  <th scope="col">Order</th>
                  <th scope="col">Placed</th>
                  <th scope="col">Term</th>
                  <th scope="col">Method</th>
                  <th scope="col">Total</th>
                  <th scope="col">Status</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => {
                  const meta = ORDER_STATUS_META[order.status] ?? ORDER_STATUS_META.pending;
                  return (
                    <tr key={order.id}>
                      <td>
                        <span className="block text-[0.8rem] font-medium text-ink">
                          {order.item_name}
                        </span>
                        <span className="text-[0.66rem] text-mutedblue">
                          {order.server_name} · {order.region}
                        </span>
                      </td>
                      <td className="whitespace-nowrap text-[0.74rem] text-mutedblue">
                        {dateTimeLabel(order.created_at)}
                      </td>
                      <td className="whitespace-nowrap text-[0.74rem] text-ink-soft">
                        {billingLabel(order.billing_months)}
                      </td>
                      <td className="whitespace-nowrap text-[0.74rem] text-ink-soft">
                        {order.gateway_id
                          ? gatewayNames.get(order.gateway_id) ?? "—"
                          : "—"}
                      </td>
                      <td className="mono whitespace-nowrap text-[0.78rem]">
                        {money(order.amount_cents)}
                      </td>
                      <td>
                        <StatusPill label={meta.label} tone={meta.tone} dot />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <div className="glass rounded-2xl p-4">
          <h2 className="flex items-center gap-1.5 text-[0.88rem] font-semibold text-ink">
            <CreditCard className="size-4 text-[#0a63ff]" />
            Payment methods
          </h2>
          <p className="mt-1 text-[0.76rem] leading-relaxed text-ink-soft/80">
            The methods below are offered at checkout. Card details are never
            stored on Volt servers.
          </p>
          <ul className="mt-3 flex flex-wrap gap-2">
            {gateways
              .filter((gateway) => gateway.enabled === 1)
              .map((gateway) => (
                <li
                  key={gateway.id}
                  className="rounded-full border border-white/90 bg-white/60 px-2.5 py-1 text-[0.7rem] font-medium text-ink-soft"
                >
                  {gateway.name}
                </li>
              ))}
          </ul>
        </div>

        <div className="glass rounded-2xl p-4">
          <h2 className="text-[0.88rem] font-semibold text-ink">
            Cancel or change a plan
          </h2>
          <p className="mt-1 text-[0.76rem] leading-relaxed text-ink-soft/80">
            Open a ticket and tell us the server name. Changes are applied at the
            next renewal so you keep the time you paid for.
          </p>
          <Link
            href="/dashboard/support/new"
            className="btn btn-secondary btn-sm mt-3"
          >
            Contact billing
          </Link>
        </div>
      </div>
    </div>
  );
}
