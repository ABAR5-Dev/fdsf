import Link from "next/link";
import {
  ArrowUpRight,
  ChevronDown,
  CreditCard,
  LayoutDashboard,
  LifeBuoy,
  LogOut,
  Server,
  ShieldCheck,
  Wrench,
} from "lucide-react";
import { getCurrentUser } from "@/lib/auth";
import { getSite } from "@/lib/queries";
import { logoutAction } from "@/lib/actions/auth";
import { Avatar } from "./avatar";
import { Brand } from "./brand";
import { MobileMenu } from "./mobile-menu";

const NAV = [
  { href: "/store", label: "Game servers" },
  { href: "/#why-volt", label: "Why Volt" },
  { href: "/#network", label: "Network" },
  { href: "/#pricing", label: "Pricing" },
  { href: "/support", label: "Support" },
];

export async function SiteHeader() {
  const user = await getCurrentUser();
  const site = getSite();
  const isAdmin = user?.role === "admin";

  return (
    <header className="sticky top-0 z-40 border-b border-white/60 bg-[#f2faff]/72 backdrop-blur-xl">
      <div className="container-x flex h-[72px] items-center justify-between gap-4">
        <div className="flex items-center gap-7">
          <Brand name={site.siteName} />
          <nav className="hidden items-center gap-0.5 lg:flex" aria-label="Main">
            {NAV.map((item) => (
              <Link key={item.href} href={item.href} className="nav-link">
                {item.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-2.5">
          <Link
            href="/status"
            className="hidden items-center gap-2 rounded-full border border-white/80 bg-white/55 px-3 py-1.5 text-[0.72rem] font-semibold text-[#2c5a46] backdrop-blur-md transition hover:bg-white/80 xl:inline-flex"
          >
            <span className="live-dot size-1.5 rounded-full bg-[#20b878]" />
            All systems operational
          </Link>

          {user ? (
            <details className="group relative hidden lg:block">
              <summary className="flex cursor-pointer list-none items-center gap-2 rounded-xl border border-white/80 bg-white/60 py-1.5 pl-1.5 pr-2.5 text-sm font-semibold text-ink shadow-sm backdrop-blur-md transition hover:bg-white/85">
                <Avatar
                  name={user.name}
                  src={user.avatarUrl}
                  size={28}
                  className="rounded-lg"
                />
                <span className="max-w-[8.5rem] truncate">{user.name.split(" ")[0]}</span>
                <ChevronDown className="size-3.5 text-mutedblue transition-transform group-open:rotate-180" />
              </summary>
              <div className="glass absolute right-0 top-[calc(100%+9px)] w-60 rounded-2xl p-1.5">
                <div className="flex items-center gap-2.5 px-2.5 pb-2 pt-2">
                  <Avatar name={user.name} src={user.avatarUrl} size={36} />
                  <div className="min-w-0">
                    <p className="truncate text-[0.82rem] font-semibold text-ink">
                      {user.name}
                    </p>
                    <p className="truncate text-[0.72rem] text-mutedblue">{user.email}</p>
                  </div>
                </div>
                <div className="hairline mb-1" />
                <MenuLink href="/dashboard" icon={<LayoutDashboard />} label="Dashboard" />
                <MenuLink href="/dashboard/servers" icon={<Server />} label="My servers" />
                <MenuLink href="/dashboard/billing" icon={<CreditCard />} label="Billing" />
                <MenuLink href="/dashboard/support" icon={<LifeBuoy />} label="Support" />
                <MenuLink href="/dashboard/account" icon={<Wrench />} label="Account" />
                {isAdmin && (
                  <>
                    <div className="hairline my-1" />
                    <MenuLink href="/admin" icon={<ShieldCheck />} label="Admin panel" />
                  </>
                )}
                <div className="hairline my-1" />
                <form action={logoutAction}>
                  <button
                    type="submit"
                    className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-[0.82rem] font-medium text-[#8a3b3b] transition hover:bg-[#fff1f1]"
                  >
                    <LogOut className="size-4" />
                    Sign out
                  </button>
                </form>
              </div>
            </details>
          ) : (
            <Link
              href="/login"
              className="hidden rounded-xl px-3 py-2 text-sm font-semibold text-ink-soft transition hover:bg-white/55 hover:text-[#0847a8] lg:block"
            >
              Sign in
            </Link>
          )}

          <Link
            href={user ? "/dashboard" : "/register"}
            className="btn btn-primary btn-sm hidden lg:inline-flex"
          >
            {user ? "Open dashboard" : "Deploy a server"}
            <ArrowUpRight className="size-4" />
          </Link>

          <MobileMenu signedIn={Boolean(user)} isAdmin={isAdmin} />
        </div>
      </div>
    </header>
  );
}

function MenuLink({
  href,
  icon,
  label,
}: {
  href: string;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <Link
      href={href}
      className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[0.82rem] font-medium text-ink-soft transition hover:bg-white/70 hover:text-[#0847a8] [&_svg]:size-4 [&_svg]:text-mutedblue"
    >
      {icon}
      {label}
    </Link>
  );
}

export function SiteHeaderFallback() {
  return (
    <header className="sticky top-0 z-40 border-b border-white/60 bg-[#f2faff]/72 backdrop-blur-xl">
      <div className="container-x flex h-[72px] items-center justify-between gap-4">
        <Brand />
        <div className="hidden items-center gap-6 lg:flex">
          {NAV.map((item) => (
            <Link key={item.href} href={item.href} className="nav-link">
              {item.label}
            </Link>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <span className="h-9 w-20 animate-pulse rounded-xl bg-white/60" />
          <span className="h-9 w-32 animate-pulse rounded-xl bg-white/70" />
        </div>
      </div>
    </header>
  );
}
