"use client";

import Link from "next/link";
import { useActionState } from "react";
import { CheckCircle2, Loader2, Save } from "lucide-react";
import { saveProductAction } from "@/lib/actions/admin";
import type { CategoryRow, ProductRow } from "@/lib/types";

function featuresOf(product?: ProductRow): string {
  if (!product?.features) return "";
  try {
    const parsed = JSON.parse(product.features) as unknown;
    if (Array.isArray(parsed)) return parsed.join("\n");
  } catch {
    // Stored as plain lines.
  }
  return product.features;
}

export function ProductForm({
  product,
  categories,
}: {
  product?: ProductRow;
  categories: CategoryRow[];
}) {
  const [state, action, pending] = useActionState(saveProductAction, null);

  return (
    <form action={action} className="space-y-4">
      {product && <input type="hidden" name="id" value={product.id} />}

      {state?.error && (
        <p
          role="alert"
          className="rounded-lg border border-[#f3c6c6] bg-[#fff5f5] px-3 py-2 text-[0.78rem] text-[#a13b3b]"
        >
          {state.error}
        </p>
      )}
      {state?.success && (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-[#c4e8d5] bg-[#f2fbf6] px-3 py-2 text-[0.78rem] text-[#0a7a4e]">
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="size-3.5" />
            {state.success}
          </span>
          <Link href="/admin/products" className="font-semibold hover:underline">
            Back to products
          </Link>
        </div>
      )}

      <section className="glass rounded-2xl p-4 sm:p-5">
        <h2 className="text-[0.9rem] font-semibold text-ink">Basics</h2>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label htmlFor="name" className="field-label">
              Plan name
            </label>
            <input
              id="name"
              name="name"
              required
              minLength={2}
              maxLength={80}
              defaultValue={product?.name ?? ""}
              placeholder="Volt 4 GB"
              className="input"
            />
          </div>
          <div>
            <label htmlFor="category_id" className="field-label">
              Category
            </label>
            <select
              id="category_id"
              name="category_id"
              required
              defaultValue={product?.category_id ?? categories[0]?.id ?? ""}
              className="select"
            >
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="price_dollars" className="field-label">
              Price per month (USD)
            </label>
            <input
              id="price_dollars"
              name="price_dollars"
              type="number"
              min={1}
              step="0.01"
              required
              defaultValue={
                product ? (product.price_cents / 100).toFixed(2) : "9.00"
              }
              className="input"
            />
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="description" className="field-label">
              Short description
            </label>
            <textarea
              id="description"
              name="description"
              rows={2}
              maxLength={280}
              defaultValue={product?.description ?? ""}
              placeholder="A modded world for a small crew, with room for plugins."
              className="textarea"
            />
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="features" className="field-label">
              Selling points · one per line
            </label>
            <textarea
              id="features"
              name="features"
              rows={4}
              defaultValue={featuresOf(product)}
              placeholder={"Unlimited player slots\nFree subdomain\nOne-click modpacks"}
              className="textarea"
            />
            <p className="field-hint">Up to 12 lines. Shown on the store card.</p>
          </div>
        </div>
      </section>

      <section className="glass rounded-2xl p-4 sm:p-5">
        <h2 className="text-[0.9rem] font-semibold text-ink">Resources</h2>
        <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {[
            {
              name: "ram_gb",
              label: "Memory (GB)",
              value: product ? product.ram_mb / 1024 : 2,
              min: 0.5,
              step: 0.5,
            },
            {
              name: "cpu_pct",
              label: "CPU (%)",
              value: product?.cpu_pct ?? 100,
              min: 50,
              step: 50,
            },
            {
              name: "disk_gb",
              label: "Disk (GB)",
              value: product ? product.disk_mb / 1024 : 10,
              min: 1,
              step: 1,
            },
            {
              name: "backups",
              label: "Backups",
              value: product?.backups ?? 2,
              min: 0,
              step: 1,
            },
            {
              name: "databases",
              label: "Databases",
              value: product?.databases ?? 1,
              min: 0,
              step: 1,
            },
            {
              name: "allocations",
              label: "Port allocations",
              value: product?.allocations ?? 1,
              min: 1,
              step: 1,
            },
            {
              name: "players",
              label: "Player slots (display)",
              value: product?.players ?? 20,
              min: 0,
              step: 1,
            },
            {
              name: "sort_order",
              label: "Sort order",
              value: product?.sort_order ?? 0,
              min: 0,
              step: 1,
            },
          ].map((field) => (
            <div key={field.name}>
              <label htmlFor={field.name} className="field-label">
                {field.label}
              </label>
              <input
                id={field.name}
                name={field.name}
                type="number"
                min={field.min}
                step={field.step}
                defaultValue={field.value}
                className="input"
              />
            </div>
          ))}
        </div>
        <p className="field-hint mt-2">
          CPU is a percentage of one core; 100 = one full core, 200 = two.
        </p>
      </section>

      <section className="glass rounded-2xl p-4 sm:p-5">
        <h2 className="text-[0.9rem] font-semibold text-ink">Visibility</h2>
        <div className="mt-3 flex flex-wrap gap-4">
          <label className="flex items-center gap-2 text-[0.78rem] text-ink-soft">
            <input
              type="checkbox"
              name="active"
              defaultChecked={product ? product.active === 1 : true}
              className="size-4 rounded border-[#c3d6e6] accent-[#0a63ff]"
            />
            Show in the store
          </label>
          <label className="flex items-center gap-2 text-[0.78rem] text-ink-soft">
            <input
              type="checkbox"
              name="popular"
              defaultChecked={product?.popular === 1}
              className="size-4 rounded border-[#c3d6e6] accent-[#0a63ff]"
            />
            Mark as most popular
          </label>
        </div>
      </section>

      <details className="glass rounded-2xl p-4 sm:p-5">
        <summary className="cursor-pointer text-[0.9rem] font-semibold text-ink">
          Pterodactyl overrides
        </summary>
        <p className="mt-1 text-[0.72rem] text-mutedblue">
          Leave empty to inherit the category or global defaults. These are the
          values sent when the server is created.
        </p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          {[
            { name: "nest_id", label: "Nest id", value: product?.nest_id ?? "" },
            { name: "egg_id", label: "Egg id", value: product?.egg_id ?? "" },
            {
              name: "allocation_id",
              label: "Allocation id",
              value: product?.allocation_id ?? "",
            },
            {
              name: "docker_image",
              label: "Docker image",
              value: product?.docker_image ?? "",
            },
            {
              name: "startup",
              label: "Startup command",
              value: product?.startup ?? "",
            },
          ].map((field) => (
            <div key={field.name} className={field.name === "startup" ? "sm:col-span-2" : ""}>
              <label htmlFor={field.name} className="field-label">
                {field.label}
              </label>
              <input
                id={field.name}
                name={field.name}
                defaultValue={field.value}
                className="input mono text-[0.76rem]"
              />
            </div>
          ))}
          <div className="sm:col-span-2">
            <label htmlFor="environment" className="field-label">
              Environment (JSON)
            </label>
            <textarea
              id="environment"
              name="environment"
              rows={3}
              defaultValue={product?.environment ?? ""}
              placeholder='{"SERVER_JARFILE":"server.jar"}'
              className="textarea mono text-[0.76rem]"
            />
          </div>
        </div>
      </details>

      <div className="flex flex-wrap items-center gap-2">
        <button type="submit" disabled={pending} className="btn btn-primary">
          {pending ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Saving
            </>
          ) : (
            <>
              <Save className="size-4" />
              {product ? "Save product" : "Create product"}
            </>
          )}
        </button>
        <Link href="/admin/products" className="btn btn-secondary">
          Cancel
        </Link>
      </div>
    </form>
  );
}
