import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, Check, Globe2, Sparkles, Timer } from "lucide-react";
import { GameIcon, GAME_ORBS } from "@/components/game-icon";
import { PlanCard } from "@/components/plan-card";
import { GAME_META } from "@/lib/defaults";
import { cpuLabel, diskLabel, money, ramLabel } from "@/lib/format";
import { getCategories, getCategoryBySlug, getProducts } from "@/lib/queries";

type PageProps = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return getCategories({ activeOnly: true }).map((category) => ({
    slug: category.slug,
  }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const category = getCategoryBySlug(slug);
  if (!category) return { title: "Category not found" };
  return {
    title: `${category.name} hosting`,
    description:
      category.description ||
      GAME_META[slug]?.blurb ||
      `Deploy a ${category.name} server on Volt Hosting.`,
  };
}

export default async function CategoryPage({ params }: PageProps) {
  const { slug } = await params;
  const category = getCategoryBySlug(slug);
  if (!category || category.active !== 1) notFound();

  const plans = getProducts({ activeOnly: true, categoryId: category.id });
  const meta = GAME_META[slug];
  const otherCategories = getCategories({ activeOnly: true }).filter(
    (item) => item.id !== category.id,
  );
  const from = plans.reduce(
    (lowest, plan) => Math.min(lowest, plan.price_cents),
    Number.POSITIVE_INFINITY,
  );

  return (
    <>
      <section className="relative overflow-hidden pb-8 pt-8 sm:pt-10">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-32 -top-24 -z-10 size-[36rem] rounded-full blur-2xl"
          style={{
            background:
              GAME_ORBS[slug] ??
              "radial-gradient(circle, rgba(86,197,255,0.3), transparent 70%)",
          }}
        />
        <div className="container-x">
          <nav aria-label="Breadcrumb" className="text-[0.72rem] text-mutedblue">
            <Link href="/" className="hover:text-ink">
              Home
            </Link>
            <span className="mx-1.5">/</span>
            <Link href="/store" className="hover:text-ink">
              Store
            </Link>
            <span className="mx-1.5">/</span>
            <span className="text-ink">{category.name}</span>
          </nav>

          <div className="mt-5 grid items-center gap-8 lg:grid-cols-[1.08fr_0.92fr]">
            <div>
              <span className="chip chip-accent">
                <GameIcon slug={slug} className="size-3.5" />
                {category.name} hosting
              </span>
              <h1 className="display mt-4 max-w-[17ch] text-[2.2rem] text-ink sm:text-[3rem]">
                {meta?.headline ?? category.name}
              </h1>
              <p className="lede mt-4 max-w-[54ch]">
                {category.description || meta?.blurb || category.tagline}
              </p>

              {meta && (
                <ul className="mt-5 grid max-w-xl gap-2 sm:grid-cols-2">
                  {meta.bullets.map((bullet) => (
                    <li
                      key={bullet}
                      className="flex items-start gap-2 text-[0.8rem] text-ink-soft/85"
                    >
                      <span className="mt-0.5 grid size-4 shrink-0 place-items-center rounded-full bg-[#dff1ff] text-[#0a63ff]">
                        <Check className="size-2.5" strokeWidth={3} />
                      </span>
                      {bullet}
                    </li>
                  ))}
                </ul>
              )}

              <div className="mt-6 flex flex-wrap items-center gap-3">
                <a href="#plans" className="btn btn-primary">
                  See {plans.length} {plans.length === 1 ? "plan" : "plans"}
                  <ArrowRight className="size-4" />
                </a>
                <Link href="/#pricing" className="btn btn-secondary">
                  Build custom
                </Link>
                <span className="text-[0.76rem] text-mutedblue">
                  {Number.isFinite(from) ? (
                    <>
                      from{" "}
                      <span className="mono tabular font-semibold text-ink">
                        {money(from)}
                      </span>
                      /mo
                    </>
                  ) : (
                    "Custom pricing"
                  )}
                </span>
              </div>
            </div>

            <div className="glass-tint relative overflow-hidden rounded-3xl p-6">
              <div
                aria-hidden="true"
                className="absolute inset-0 opacity-70"
                style={{
                  background:
                    GAME_ORBS[slug] ??
                    "radial-gradient(circle, rgba(86,197,255,0.3), transparent 70%)",
                }}
              />
              <div className="relative flex items-center gap-4">
                <span className="grid size-16 place-items-center rounded-2xl border border-white/90 bg-white/75 text-[#0a63ff] shadow-sm backdrop-blur">
                  <GameIcon slug={slug} className="size-7" />
                </span>
                <div>
                  <p className="text-[0.68rem] font-semibold uppercase tracking-[0.14em] text-mutedblue">
                    {meta?.statLabel ?? "servers online"}
                  </p>
                  <p className="mono tabular text-[1.7rem] font-semibold leading-none text-ink">
                    {meta?.statValue ?? "—"}
                  </p>
                </div>
              </div>

              <dl className="relative mt-5 space-y-2.5">
                {[
                  { label: "Runtime", value: category.egg_id ? `egg ${category.egg_id}` : "Managed image" },
                  { label: "Deploy time", value: "Under 90 seconds" },
                  { label: "Regions", value: "8 locations" },
                  { label: "Support", value: "24/7, human" },
                ].map((row) => (
                  <div
                    key={row.label}
                    className="flex items-center justify-between gap-4 border-b border-white/70 pb-2 last:border-0 last:pb-0"
                  >
                    <dt className="text-[0.74rem] text-mutedblue">{row.label}</dt>
                    <dd className="mono text-[0.74rem] font-medium text-ink">
                      {row.value}
                    </dd>
                  </div>
                ))}
              </dl>

              <div className="relative mt-5 flex flex-wrap gap-2 text-[0.68rem] text-ink-soft/80">
                <span className="inline-flex items-center gap-1 rounded-full border border-white/90 bg-white/65 px-2 py-1">
                  <Timer className="size-3 text-[#0a63ff]" />
                  Instant setup
                </span>
                <span className="inline-flex items-center gap-1 rounded-full border border-white/90 bg-white/65 px-2 py-1">
                  <Globe2 className="size-3 text-[#0a63ff]" />
                  DDoS filtered
                </span>
                <span className="inline-flex items-center gap-1 rounded-full border border-white/90 bg-white/65 px-2 py-1">
                  <Sparkles className="size-3 text-[#0a63ff]" />
                  NVMe storage
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="plans" className="section pt-4">
        <div className="container-x">
          <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
            <h2 className="display text-[1.7rem] text-ink sm:text-[2rem]">
              {category.name} plans
            </h2>
            <p className="text-[0.76rem] text-mutedblue">
              All prices in USD, billed monthly. Upgrade or downgrade whenever.
            </p>
          </div>

          {plans.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {plans.map((plan) => (
                <PlanCard key={plan.id} plan={plan} />
              ))}
            </div>
          ) : (
            <div className="glass rounded-2xl p-8 text-center">
              <p className="text-[0.9rem] font-semibold text-ink">
                Plans for {category.name} are being restocked.
              </p>
              <p className="mt-1 text-[0.82rem] text-ink-soft/80">
                Open a ticket and we will build one for you today.
              </p>
              <Link href="/support" className="btn btn-secondary btn-sm mt-4">
                Ask support
              </Link>
            </div>
          )}

          {plans.length > 1 && (
            <div className="mt-8">
              <h3 className="text-[0.82rem] font-semibold text-ink">
                Compare line by line
              </h3>
              <div className="table-scroll glass mt-3 rounded-2xl">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th scope="col">Spec</th>
                      {plans.map((plan) => (
                        <th key={plan.id} scope="col">
                          {plan.name}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      {
                        label: "Memory",
                        values: plans.map((plan) => ramLabel(plan.ram_mb)),
                      },
                      {
                        label: "CPU",
                        values: plans.map((plan) => cpuLabel(plan.cpu_pct)),
                      },
                      {
                        label: "NVMe",
                        values: plans.map((plan) => diskLabel(plan.disk_mb)),
                      },
                      {
                        label: "Backups",
                        values: plans.map(
                          (plan) =>
                            `${plan.backups} slot${plan.backups === 1 ? "" : "s"}`,
                        ),
                      },
                      {
                        label: "Databases",
                        values: plans.map((plan) => String(plan.databases)),
                      },
                      {
                        label: "Price",
                        values: plans.map((plan) => `${money(plan.price_cents)}/mo`),
                      },
                    ].map((row) => (
                      <tr key={row.label}>
                        <th scope="row">{row.label}</th>
                        {row.values.map((value, index) => (
                          <td key={plans[index].id}>{value}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </section>

      <section className="section pt-0">
        <div className="container-x">
          <div className="console noise relative overflow-hidden rounded-2xl px-6 py-7 sm:px-8">
            <div className="console-grid pointer-events-none absolute inset-0 opacity-50" />
            <div className="relative flex flex-wrap items-center justify-between gap-5">
              <div>
                <p className="text-[0.92rem] font-semibold text-white">
                  Need different specs?
                </p>
                <p className="mt-1 max-w-[46ch] text-[0.8rem] leading-relaxed text-[#a6c8dd]">
                  Slide the RAM, CPU, disk and backup counts yourself. The price
                  updates before you commit.
                </p>
              </div>
              <Link href="/#pricing" className="btn btn-primary">
                Open the configurator
                <ArrowRight className="size-4" />
              </Link>
            </div>
          </div>

          {otherCategories.length > 0 && (
            <div className="mt-8">
              <p className="text-[0.78rem] font-semibold text-ink">
                Also hosting
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {otherCategories.map((item) => (
                  <Link
                    key={item.id}
                    href={`/store/${item.slug}`}
                    className="inline-flex items-center gap-1.5 rounded-full border border-white/90 bg-white/60 px-3 py-1.5 text-[0.74rem] font-medium text-ink-soft transition hover:border-[#bfe2ff] hover:bg-white"
                  >
                    <GameIcon slug={item.slug} className="size-3.5 text-[#0a63ff]" />
                    {item.name}
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
    </>
  );
}
