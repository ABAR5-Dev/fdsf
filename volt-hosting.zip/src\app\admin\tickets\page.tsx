import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { ArrowUpRight, Search, Ticket } from "lucide-react";
import { StatusPill } from "@/components/status-pill";
import {
  PRIORITY_META,
  TICKET_STATUS_META,
  relativeTime,
} from "@/lib/format";
import { getAllTickets } from "@/lib/queries";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Tickets" };

type PageProps = { searchParams: Promise<{ status?: string; q?: string }> };

const FILTERS = ["all", "open", "answered", "closed"] as const;

const CATEGORY_LABEL: Record<string, string> = {
  server: "Game server",
  panel: "Panel access",
  billing: "Billing",
  general: "General",
};

export default async function AdminTicketsPage({ searchParams }: PageProps) {
  await requireAdmin("/admin/tickets");
  const { status = "all", q = "" } = await searchParams;
  const query = q.trim().toLowerCase();
  const all = getAllTickets();

  const filtered = all.filter((ticket) => {
    if (status !== "all" && ticket.status !== status) return false;
    if (!query) return true;
    return `${ticket.subject} ${ticket.user_name} ${ticket.user_email} ${ticket.id}`
      .toLowerCase()
      .includes(query);
  });

  const counts = {
    all: all.length,
    open: all.filter((ticket) => ticket.status === "open").length,
    answered: all.filter((ticket) => ticket.status === "answered").length,
    closed: all.filter((ticket) => ticket.status === "closed").length,
  };

  return (
    <div className="mx-auto max-w-[1240px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">Tickets</h1>
          <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
            Replies are emailed to the customer and re-open the thread for them.
          </p>
        </div>
        <span className="text-[0.74rem] text-mutedblue">
          {counts.open} waiting on us
        </span>
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1">
          {FILTERS.map((key) => {
            const selected = key === status;
            return (
              <Link
                key={key}
                href={`/admin/tickets?status=${key}${query ? `&q=${encodeURIComponent(query)}` : ""}`}
                aria-current={selected ? "page" : undefined}
                className={`rounded-full px-2.5 py-1 text-[0.72rem] font-medium capitalize transition ${
                  selected
                    ? "bg-[#0a63ff] text-white shadow-sm"
                    : "border border-white/90 bg-white/55 text-ink-soft hover:bg-white/80"
                }`}
              >
                {key}
                <span
                  className={`ml-1.5 tabular text-[0.62rem] ${
                    selected ? "text-white/75" : "text-mutedblue"
                  }`}
                >
                  {counts[key]}
                </span>
              </Link>
            );
          })}
        </div>

        <form method="get" action="/admin/tickets" className="relative">
          <input type="hidden" name="status" value={status} />
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-[#8aa8bc]" />
          <input
            name="q"
            defaultValue={q}
            placeholder="Subject, customer or ticket id"
            className="input h-8 w-[250px] max-w-full pl-8 text-[0.74rem]"
          />
        </form>
      </div>

      <section className="glass mt-3 rounded-2xl p-2 sm:p-3">
        {filtered.length === 0 ? (
          <div className="py-14 text-center">
            <span className="mx-auto grid size-11 place-items-center rounded-xl bg-white/80 text-[#0a63ff]">
              <Ticket className="size-5" />
            </span>
            <p className="mt-3 text-[0.86rem] font-semibold text-ink">
              {query ? "No ticket matches." : "Inbox zero."}
            </p>
            <p className="mt-1 text-[0.76rem] text-mutedblue">
              {query
                ? "Try another subject or the customer email."
                : "New tickets land here and in Discord if the webhook is on."}
            </p>
          </div>
        ) : (
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th scope="col">Ticket</th>
                  <th scope="col">Customer</th>
                  <th scope="col">Priority</th>
                  <th scope="col">Messages</th>
                  <th scope="col">Updated</th>
                  <th scope="col">Status</th>
                  <th scope="col" aria-label="Open" />
                </tr>
              </thead>
              <tbody>
                {filtered.map((ticket) => {
                  const statusMeta =
                    TICKET_STATUS_META[ticket.status] ?? TICKET_STATUS_META.open;
                  const priority =
                    PRIORITY_META[ticket.priority] ?? PRIORITY_META.normal;
                  return (
                    <tr key={ticket.id}>
                      <td>
                        <Link
                          href={`/admin/tickets/${ticket.id}`}
                          className="block max-w-[340px] truncate text-[0.8rem] font-medium text-ink hover:text-[#0a63ff]"
                        >
                          {ticket.subject}
                        </Link>
                        <span className="text-[0.64rem] text-mutedblue">
                          {CATEGORY_LABEL[ticket.category] ?? ticket.category}
                        </span>
                      </td>
                      <td>
                        <span className="block text-[0.76rem] text-ink-soft">
                          {ticket.user_name}
                        </span>
                        <span className="text-[0.64rem] text-mutedblue">
                          {ticket.user_email}
                        </span>
                      </td>
                      <td className="whitespace-nowrap text-[0.72rem] text-ink-soft">
                        {priority.label}
                      </td>
                      <td className="mono text-[0.72rem] text-mutedblue">
                        {ticket.message_count}
                      </td>
                      <td className="whitespace-nowrap text-[0.7rem] text-mutedblue">
                        {relativeTime(ticket.updated_at)}
                      </td>
                      <td>
                        <StatusPill
                          label={statusMeta.label}
                          tone={statusMeta.tone}
                          dot
                        />
                      </td>
                      <td>
                        <Link
                          href={`/admin/tickets/${ticket.id}`}
                          aria-label={`Open ${ticket.subject}`}
                          className="grid size-7 place-items-center rounded-lg text-[#7fa5c2] transition hover:bg-white/70 hover:text-[#0a63ff]"
                        >
                          <ArrowUpRight className="size-3.5" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
