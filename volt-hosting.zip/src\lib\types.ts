export type Role = "customer" | "admin";

export type UserRow = {
  id: string;
  email: string;
  name: string;
  password_hash: string;
  role: Role;
  panel_user_id: number | null;
  panel_username: string | null;
  panel_password_enc: string | null;
  avatar_url: string;
  bio: string;
  discord_handle: string;
  created_at: string;
};

export type SessionUser = {
  id: string;
  email: string;
  name: string;
  role: Role;
  panelUsername: string | null;
  avatarUrl: string;
  bio: string;
  discordHandle: string;
  createdAt: string;
};

export type CategoryRow = {
  id: string;
  name: string;
  slug: string;
  tagline: string;
  description: string;
  icon: string;
  accent: string;
  sort_order: number;
  active: number;
  nest_id: string;
  egg_id: string;
  docker_image: string;
  startup: string;
  environment: string;
  created_at: string;
};

export type ProductRow = {
  id: string;
  category_id: string;
  name: string;
  slug: string;
  description: string;
  price_cents: number;
  ram_mb: number;
  cpu_pct: number;
  disk_mb: number;
  backups: number;
  databases: number;
  allocations: number;
  players: number;
  popular: number;
  active: number;
  sort_order: number;
  features: string;
  nest_id: string;
  egg_id: string;
  docker_image: string;
  startup: string;
  environment: string;
  allocation_id: string;
  created_at: string;
};

export type ProductWithCategory = ProductRow & {
  category_name: string;
  category_slug: string;
  category_icon: string;
  category_accent: string;
};

export type OrderStatus =
  | "pending"
  | "paid"
  | "provisioning"
  | "active"
  | "failed"
  | "cancelled"
  | "refunded";

export type OrderRow = {
  id: string;
  user_id: string;
  product_id: string | null;
  category_id: string | null;
  item_name: string;
  server_name: string;
  region: string;
  kind: "product" | "custom";
  specs: string;
  amount_cents: number;
  billing_months: number;
  status: OrderStatus;
  gateway_id: string | null;
  gateway_ref: string | null;
  provision_error: string | null;
  promo_code: string | null;
  discount_cents: number;
  created_at: string;
  paid_at: string | null;
};

export type OrderWithUser = OrderRow & {
  user_name: string;
  user_email: string;
  gateway_name: string | null;
};

export type ServerStatus =
  | "provisioning"
  | "installing"
  | "running"
  | "offline"
  | "suspended"
  | "failed";

export type ServerRow = {
  id: string;
  user_id: string;
  order_id: string | null;
  product_id: string | null;
  name: string;
  identifier: string;
  panel_server_id: number | null;
  panel_user_id: number | null;
  ram_mb: number;
  cpu_pct: number;
  disk_mb: number;
  backups: number;
  databases: number;
  allocations: number;
  nest_id: string;
  egg_id: string;
  docker_image: string;
  startup: string;
  environment: string;
  status: ServerStatus;
  ip: string;
  port: number | null;
  region: string;
  panel_username: string;
  panel_password_enc: string | null;
  created_at: string;
  renewal_at: string | null;
  last_synced_at: string | null;
  notes: string;
};

export type TicketStatus = "open" | "answered" | "closed";
export type TicketPriority = "low" | "normal" | "high" | "urgent";

export type TicketRow = {
  id: string;
  user_id: string;
  subject: string;
  category: string;
  priority: TicketPriority;
  status: TicketStatus;
  created_at: string;
  updated_at: string;
};

export type TicketWithUser = TicketRow & {
  user_name: string;
  user_email: string;
  message_count: number;
};

export type TicketMessageRow = {
  id: string;
  ticket_id: string;
  user_id: string | null;
  author_name: string;
  is_staff: number;
  body: string;
  created_at: string;
};

export type GatewayType = "stripe" | "manual" | "discord";

export type PromoKind = "percent" | "fixed";

export type PromoCodeRow = {
  id: string;
  code: string;
  description: string;
  kind: PromoKind;
  value: number;
  min_cents: number;
  max_uses: number;
  used_count: number;
  expires_at: string | null;
  active: number;
  created_at: string;
};

export type GatewayRow = {
  id: string;
  name: string;
  type: GatewayType;
  description: string;
  enabled: number;
  config: string;
  sort_order: number;
  created_at: string;
};

export type SiteSettings = {
  siteName: string;
  tagline: string;
  supportEmail: string;
  appUrl: string;
  discordInvite: string;
};

export type PricingSettings = {
  baseCents: number;
  ramPerGbCents: number;
  cpuPerCoreCents: number;
  diskPerGbCents: number;
  backupCents: number;
  quarterlyDiscount: number;
  yearlyDiscount: number;
};

export type PterodactylSettings = {
  enabled: boolean;
  panelUrl: string;
  apiKey: string;
  defaultNodeId: string;
  defaultNestId: string;
  defaultEggId: string;
  defaultDockerImage: string;
  defaultStartup: string;
  defaultEnvironment: string;
  defaultAllocationId: string;
};

export type SmtpSettings = {
  enabled: boolean;
  host: string;
  port: number;
  secure: boolean;
  user: string;
  pass: string;
  fromName: string;
  fromEmail: string;
};

export type DiscordSettings = {
  enabled: boolean;
  username: string;
  iconUrl: string;
  signupWebhook: string;
  purchaseWebhook: string;
  ticketWebhook: string;
};

export type PaymentSettings = {
  enabled: boolean;
  currency: string;
  note: string;
};

export type Specs = {
  ramMb: number;
  cpuPct: number;
  diskMb: number;
  backups: number;
  databases: number;
  allocations: number;
  players: number;
};

export type ActionState = {
  error?: string;
  success?: string;
  fieldErrors?: Record<string, string>;
} | null;
