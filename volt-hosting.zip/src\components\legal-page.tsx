import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export type LegalSection = {
  id: string;
  title: string;
  paragraphs?: string[];
  bullets?: string[];
};

export function LegalPage({
  title,
  updated,
  intro,
  sections,
  footer,
}: {
  title: string;
  updated: string;
  intro: string;
  sections: LegalSection[];
  footer: React.ReactNode;
}) {
  return (
    <div className="container-x py-8 sm:py-10">
      <nav aria-label="Breadcrumb" className="text-[0.72rem] text-mutedblue">
        <Link href="/" className="hover:text-ink">
          Home
        </Link>
        <span className="mx-1.5">/</span>
        <span className="text-ink">{title}</span>
      </nav>

      <div className="mt-5 grid items-start gap-8 lg:grid-cols-[minmax(0,1fr)_15rem]">
        <article className="max-w-[68ch]">
          <span className="chip">Legal</span>
          <h1 className="display mt-3 text-[2.1rem] text-ink sm:text-[2.7rem]">
            {title}
          </h1>
          <p className="mt-1.5 text-[0.72rem] text-mutedblue">Last updated {updated}</p>
          <p className="lede mt-4">{intro}</p>

          <div className="mt-8 space-y-8">
            {sections.map((section, index) => (
              <section
                key={section.id}
                id={section.id}
                className="scroll-mt-24 border-t border-[#dcecfa]/90 pt-6 first:border-t-0 first:pt-0"
              >
                <h2 className="flex items-baseline gap-2.5 text-[1.08rem] font-semibold text-ink">
                  <span className="mono text-[0.7rem] font-medium text-[#7fa5c2]">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                  {section.title}
                </h2>
                {section.paragraphs?.map((paragraph) => (
                  <p
                    key={paragraph.slice(0, 32)}
                    className="mt-3 text-[0.86rem] leading-[1.75] text-ink-soft/90"
                  >
                    {paragraph}
                  </p>
                ))}
                {section.bullets && (
                  <ul className="mt-3 space-y-2">
                    {section.bullets.map((bullet) => (
                      <li
                        key={bullet.slice(0, 32)}
                        className="flex gap-2.5 text-[0.86rem] leading-[1.7] text-ink-soft/90"
                      >
                        <span
                          aria-hidden="true"
                          className="mt-[0.62rem] size-1 shrink-0 rounded-full bg-[#7fb4e0]"
                        />
                        {bullet}
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            ))}
          </div>

          <div className="mt-10 rounded-2xl border border-[#cfe6ff] bg-[#eef7ff] p-5 text-[0.84rem] leading-relaxed text-[#2f5f85]">
            {footer}
          </div>

          <Link
            href="/"
            className="mt-6 inline-flex items-center gap-1.5 text-[0.76rem] font-medium text-mutedblue transition hover:text-ink"
          >
            <ArrowLeft className="size-3.5" />
            Back to home
          </Link>
        </article>

        <aside className="sticky top-24 hidden lg:block">
          <p className="text-[0.68rem] font-semibold text-ink">On this page</p>
          <ol className="mt-2.5 space-y-1.5">
            {sections.map((section) => (
              <li key={section.id}>
                <a
                  href={`#${section.id}`}
                  className="block text-[0.74rem] leading-snug text-ink-soft/75 transition hover:text-[#0847a8]"
                >
                  {section.title}
                </a>
              </li>
            ))}
          </ol>
        </aside>
      </div>
    </div>
  );
}
