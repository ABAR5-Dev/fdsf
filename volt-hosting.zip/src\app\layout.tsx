import type { Metadata, Viewport } from "next";
import {
  Bricolage_Grotesque,
  Instrument_Sans,
  JetBrains_Mono,
} from "next/font/google";
import "./globals.css";

const bricolage = Bricolage_Grotesque({
  subsets: ["latin"],
  variable: "--font-bricolage",
  display: "swap",
  axes: ["opsz"],
});

const instrument = Instrument_Sans({
  subsets: ["latin"],
  variable: "--font-instrument",
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Volt Hosting — Game servers, live in 90 seconds",
    template: "%s · Volt Hosting",
  },
  description:
    "Minecraft, FiveM, Rust, SA-MP and Discord bot hosting on Ryzen 9 hardware with NVMe storage. Pick a plan, pay, and your panel login lands in your inbox.",
  keywords: [
    "game server hosting",
    "Minecraft hosting",
    "FiveM hosting",
    "Rust server hosting",
    "SA-MP hosting",
    "Discord bot hosting",
  ],
  openGraph: {
    title: "Volt Hosting — Game servers, live in 90 seconds",
    description:
      "Pick a game, choose your RAM, and get a panel login in your inbox. DDoS-protected game hosting from €1.99.",
    type: "website",
    siteName: "Volt Hosting",
  },
};

export const viewport: Viewport = {
  themeColor: "#eef8ff",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="en"
      data-scroll-behavior="smooth"
      className={`${bricolage.variable} ${instrument.variable} ${jetbrains.variable}`}
    >
      <body>
        <div className="site-bg">{children}</div>
      </body>
    </html>
  );
}
