"use client";

import Link from "next/link";
import { useEffect } from "react";
import { RotateCcw, TriangleAlert } from "lucide-react";

export default function ErrorBoundary({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="container-x flex min-h-[72vh] max-w-[600px] flex-col items-center justify-center py-16 text-center">
      <span className="grid size-14 place-items-center rounded-2xl border border-[#f3d0d0] bg-[#fff5f5] text-[#b03b3b]">
        <TriangleAlert className="size-6" />
      </span>
      <p className="mono mt-5 text-[0.7rem] text-mutedblue">
        error 500{error.digest ? ` · ${error.digest.slice(0, 8)}` : ""}
      </p>
      <h1 className="display mt-2 text-[2.1rem] text-ink sm:text-[2.5rem]">
        Something broke on our side.
      </h1>
      <p className="mt-3 max-w-[46ch] text-[0.88rem] leading-relaxed text-ink-soft/85">
        The page could not finish loading. Your servers and orders are unaffected
        — try again, and if it keeps happening, support can trace it with the
        reference above.
      </p>
      <div className="mt-6 flex flex-wrap justify-center gap-2">
        <button type="button" onClick={reset} className="btn btn-primary btn-sm">
          <RotateCcw className="size-4" />
          Try again
        </button>
        <Link href="/" className="btn btn-secondary btn-sm">
          Back to home
        </Link>
        <Link href="/support" className="btn btn-secondary btn-sm">
          Contact support
        </Link>
      </div>
    </div>
  );
}
