import { initials } from "@/lib/format";

/**
 * Avatar with a deterministic initials fallback. Used in the site header, the
 * dashboard chrome and the admin customer list so a profile photo follows the
 * person everywhere their name does.
 */
export function Avatar({
  name,
  src,
  size = 32,
  className = "",
}: {
  name: string;
  src?: string;
  size?: number;
  className?: string;
}) {
  return (
    <span
      className={`grid shrink-0 place-items-center overflow-hidden rounded-full bg-gradient-to-br from-[#d8ecff] to-white font-bold text-[#0a4bb0] ring-1 ring-white ${className}`}
      style={{
        width: size,
        height: size,
        fontSize: Math.max(9, Math.round(size * 0.34)),
      }}
    >
      {src ? (
        // Local upload under /public; next/image adds no value at this size.
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt="" className="h-full w-full object-cover" />
      ) : (
        initials(name)
      )}
    </span>
  );
}
