"use client";

import { useActionState, useEffect, useRef } from "react";
import { Loader2, Send } from "lucide-react";
import { createTicketAction, replyTicketAction } from "@/lib/actions/support";
import type { ActionState } from "@/lib/types";

function Alert({ state }: { state: ActionState }) {
  if (!state?.error) return null;
  return (
    <p
      role="alert"
      className="rounded-lg border border-[#f3c6c6] bg-[#fff5f5] px-3 py-2 text-[0.78rem] text-[#a13b3b]"
    >
      {state.error}
    </p>
  );
}

export function NewTicketForm({ serverName }: { serverName?: string }) {
  const [state, action, pending] = useActionState(createTicketAction, null);

  return (
    <form action={action} className="space-y-4">
      <Alert state={state} />

      {serverName && (
        <p className="rounded-lg border border-white/90 bg-white/55 px-3 py-2 text-[0.74rem] text-ink-soft">
          About server <span className="font-semibold text-ink">{serverName}</span>.
          Include any error text you saw in the panel.
        </p>
      )}

      <div>
        <label htmlFor="subject" className="field-label">
          Subject
        </label>
        <input
          id="subject"
          name="subject"
          required
          minLength={4}
          maxLength={120}
          defaultValue={serverName ? `Issue with ${serverName}` : ""}
          placeholder="Server won't start after the last update"
          className="input"
        />
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label htmlFor="category" className="field-label">
            Topic
          </label>
          <select id="category" name="category" className="select" defaultValue="server">
            <option value="server">Game server</option>
            <option value="panel">Panel access</option>
            <option value="billing">Billing</option>
            <option value="general">Something else</option>
          </select>
        </div>
        <div>
          <label htmlFor="priority" className="field-label">
            Priority
          </label>
          <select id="priority" name="priority" className="select" defaultValue="normal">
            <option value="low">Low — no rush</option>
            <option value="normal">Normal</option>
            <option value="high">High — players affected</option>
            <option value="urgent">Urgent — server down</option>
          </select>
        </div>
      </div>

      <div>
        <label htmlFor="message" className="field-label">
          What is happening?
        </label>
        <textarea
          id="message"
          name="message"
          required
          minLength={15}
          rows={7}
          placeholder="Tell us what you tried, what you expected, and any error text from the console."
          className="textarea"
        />
        <p className="field-hint">
          Server name, panel username or order number helps us find it faster.
        </p>
      </div>

      <button type="submit" disabled={pending} className="btn btn-primary">
        {pending ? (
          <>
            <Loader2 className="size-4 animate-spin" />
            Opening ticket
          </>
        ) : (
          <>
            <Send className="size-4" />
            Open ticket
          </>
        )}
      </button>
    </form>
  );
}

export function ReplyBox({ ticketId }: { ticketId: string }) {
  const [state, action, pending] = useActionState(replyTicketAction, null);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state?.success) formRef.current?.reset();
  }, [state]);

  return (
    <form ref={formRef} action={action} className="mt-4">
      <input type="hidden" name="ticket_id" value={ticketId} />
      <label htmlFor="message" className="field-label">
        Reply
      </label>
      <textarea
        id="message"
        name="message"
        required
        rows={4}
        placeholder="Add an update or answer the last question."
        className="textarea"
      />
      {state?.error && (
        <p role="alert" className="mt-1.5 text-[0.74rem] text-[#a13b3b]">
          {state.error}
        </p>
      )}
      {state?.success && (
        <p className="mt-1.5 text-[0.74rem] text-[#0a7a4e]">{state.success}</p>
      )}
      <div className="mt-2 flex justify-end">
        <button type="submit" disabled={pending} className="btn btn-primary btn-sm">
          {pending ? (
            <>
              <Loader2 className="size-3.5 animate-spin" />
              Sending
            </>
          ) : (
            <>
              <Send className="size-3.5" />
              Send reply
            </>
          )}
        </button>
      </div>
    </form>
  );
}
