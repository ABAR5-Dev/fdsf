import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import {
  ArrowUpRight,
  Percent,
  Plus,
  Power,
  Tags,
  TicketPercent,
  Trash2,
} from "lucide-react";
import { ConfirmSubmitButton } from "@/components/app/confirm-submit-button";
import { StatusPill } from "@/components/status-pill";
import { dateLabel, money } from "@/lib/format";
import { promoExpired } from "@/lib/promo";
import { getPromoCodes } from "@/lib/queries";
import {
  deletePromoCodeAction,
  togglePromoCodeAction,
} from "@/lib/actions/admin";

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export const metadata: Metadata = { title: "Promo codes" };

export default async function AdminPromotionsPage() {
  await requireAdmin("/admin/promotions");
  const promos = getPromoCodes();
  const active = promos.filter((promo) => promo.active === 1).length;
  const redemptions = promos.reduce((sum, promo) => sum + promo.used_count, 0);

  return (
    <div className="mx-auto max-w-[1240px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="display text-[1.9rem] text-ink sm:text-[2.2rem]">
            Promo codes
          </h1>
          <p className="mt-1.5 text-[0.84rem] text-ink-soft/80">
            Discounts customers can enter at checkout. Usage counts once an order
            is paid.
          </p>
        </div>
        <Link href="/admin/promotions/new" className="btn btn-primary btn-sm">
          <Plus className="size-4" />
          New code
        </Link>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        {[
          { label: "Codes", value: promos.length, icon: Tags },
          { label: "Available", value: active, icon: TicketPercent },
          { label: "Redemptions", value: redemptions, icon: Percent },
        ].map((stat) => (
          <div
            key={stat.label}
            className="glass flex items-center gap-3 rounded-2xl px-4 py-3"
          >
            <span className="grid size-9 place-items-center rounded-xl bg-[#e6f2ff] text-[#0a63ff]">
              <stat.icon className="size-4" />
            </span>
            <div>
              <p className="text-[0.66rem] text-mutedblue">{stat.label}</p>
              <p className="mono text-[1.05rem] font-semibold text-ink">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <section className="glass mt-4 rounded-2xl p-2 sm:p-3">
        {promos.length === 0 ? (
          <div className="py-14 text-center">
            <span className="mx-auto grid size-11 place-items-center rounded-xl bg-white/80 text-[#0a63ff]">
              <TicketPercent className="size-5" />
            </span>
            <p className="mt-3 text-[0.86rem] font-semibold text-ink">
              No promo codes yet.
            </p>
            <p className="mt-1 text-[0.76rem] text-mutedblue">
              Create one and it appears in the checkout summary right away.
            </p>
            <Link href="/admin/promotions/new" className="btn btn-primary btn-sm mt-3">
              Create the first code
            </Link>
          </div>
        ) : (
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th scope="col">Code</th>
                  <th scope="col">Discount</th>
                  <th scope="col">Minimum</th>
                  <th scope="col">Used</th>
                  <th scope="col">Expires</th>
                  <th scope="col">Status</th>
                  <th scope="col" className="text-right">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {promos.map((promo) => {
                  const expired = promoExpired(promo.expires_at);
                  const exhausted =
                    promo.max_uses > 0 && promo.used_count >= promo.max_uses;
                  const live = promo.active === 1 && !expired && !exhausted;
                  return (
                    <tr key={promo.id}>
                      <td>
                        <div className="flex items-center gap-2">
                          <span className="mono rounded-lg border border-white/90 bg-white/70 px-1.5 py-0.5 text-[0.72rem] font-semibold uppercase text-ink">
                            {promo.code}
                          </span>
                        </div>
                        {promo.description && (
                          <p className="mt-0.5 max-w-[22ch] truncate text-[0.64rem] text-mutedblue">
                            {promo.description}
                          </p>
                        )}
                      </td>
                      <td className="whitespace-nowrap text-[0.76rem] text-ink">
                        {promo.kind === "percent"
                          ? `${promo.value}% off`
                          : `${money(promo.value)} off`}
                      </td>
                      <td className="mono whitespace-nowrap text-[0.72rem] text-mutedblue">
                        {promo.min_cents > 0 ? money(promo.min_cents) : "—"}
                      </td>
                      <td className="mono whitespace-nowrap text-[0.72rem]">
                        {promo.used_count}
                        {promo.max_uses > 0 ? ` / ${promo.max_uses}` : ""}
                      </td>
                      <td className="whitespace-nowrap text-[0.72rem] text-mutedblue">
                        {promo.expires_at ? dateLabel(promo.expires_at) : "Never"}
                      </td>
                      <td>
                        <StatusPill
                          label={
                            expired
                              ? "Expired"
                              : exhausted
                                ? "Used up"
                                : promo.active === 1
                                  ? "Available"
                                  : "Paused"
                          }
                          tone={
                            live ? "mint" : expired || exhausted ? "amber" : "slate"
                          }
                          dot
                        />
                      </td>
                      <td>
                        <div className="flex items-center justify-end gap-1">
                          <Link
                            href={`/admin/promotions/${promo.id}`}
                            aria-label={`Edit ${promo.code}`}
                            className="grid size-7 place-items-center rounded-lg text-[#7fa5c2] transition hover:bg-white/80 hover:text-[#0a63ff]"
                          >
                            <ArrowUpRight className="size-3.5" />
                          </Link>
                          <form action={togglePromoCodeAction}>
                            <input type="hidden" name="id" value={promo.id} />
                            <button
                              type="submit"
                              aria-label={
                                promo.active === 1
                                  ? `Pause ${promo.code}`
                                  : `Activate ${promo.code}`
                              }
                              className="grid size-7 place-items-center rounded-lg text-[#7fa5c2] transition hover:bg-white/80 hover:text-[#0a63ff]"
                            >
                              <Power className="size-3.5" />
                            </button>
                          </form>
                          <form action={deletePromoCodeAction}>
                            <input type="hidden" name="id" value={promo.id} />
                            <ConfirmSubmitButton
                              message={`Delete ${promo.code}? Orders that already used it keep their discount.`}
                              aria-label={`Delete ${promo.code}`}
                              className="grid size-7 place-items-center rounded-lg text-[#b58c8c] transition hover:bg-[#fff1f1] hover:text-[#a13b3b]"
                            >
                              <Trash2 className="size-3.5" />
                            </ConfirmSubmitButton>
                          </form>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <p className="mt-3 px-1 text-[0.7rem] leading-relaxed text-mutedblue">
        Discounts apply to the plan price for the chosen billing term, before
        tax. A code can only be redeemed once per order, and the server checks
        the limit again when the order is marked paid.
      </p>
    </div>
  );
}
