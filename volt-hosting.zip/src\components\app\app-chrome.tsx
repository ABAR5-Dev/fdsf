"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Activity,
  ArrowUpRight,
  BookOpen,
  CreditCard,
  Gauge,
  LayoutDashboard,
  LifeBuoy,
  LogOut,
  Mail,
  Menu,
  Package,
  ReceiptText,
  Server,
  Settings,
  ShoppingCart,
  Tags,
  Ticket,
  TicketPercent,
  UserRound,
  Users,
  Wallet,
  X,
} from "lucide-react";
import { Avatar } from "@/components/avatar";
import { Brand } from "@/components/brand";
import { logoutAction } from "@/lib/actions/auth";

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  Activity,
  BookOpen,
  CreditCard,
  Gauge,
  LayoutDashboard,
  LifeBuoy,
  Mail,
  Package,
  ReceiptText,
  Server,
  Settings,
  ShoppingCart,
  Tags,
  Ticket,
  TicketPercent,
  UserRound,
  Users,
  Wallet,
};

export type NavItem = {
  href: string;
  label: string;
  icon: string;
  exact?: boolean;
  badge?: number;
};

export type ChromeUser = {
  name: string;
  email: string;
  role: "customer" | "admin";
  avatarUrl?: string;
};

function isActive(pathname: string, item: NavItem) {
  if (item.exact) return pathname === item.href;
  return pathname === item.href || pathname.startsWith(`${item.href}/`);
}

function NavList({
  items,
  pathname,
  onNavigate,
}: {
  items: NavItem[];
  pathname: string;
  onNavigate?: () => void;
}) {
  return (
    <nav className="space-y-0.5" aria-label="Main">
      {items.map((item) => {
        const Icon = ICONS[item.icon] ?? LayoutDashboard;
        const active = isActive(pathname, item);
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            data-active={active}
            aria-current={active ? "page" : undefined}
            className="side-link"
          >
            <Icon className="size-4 shrink-0" />
            <span className="truncate">{item.label}</span>
            {typeof item.badge === "number" && item.badge > 0 && (
              <span className="ml-auto rounded-full bg-[#0a63ff] px-1.5 py-0.5 text-[0.6rem] font-bold leading-none text-white">
                {item.badge}
              </span>
            )}
          </Link>
        );
      })}
    </nav>
  );
}

export function AppChrome({
  items,
  user,
  area,
  children,
}: {
  items: NavItem[];
  user: ChromeUser;
  area: "customer" | "admin";
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  // Storing the path the drawer was opened on closes it on navigation without
  // a state-updating effect.
  const [openAt, setOpenAt] = useState<string | null>(null);
  const open = openAt === pathname;

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpenAt(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const otherArea =
    area === "admin"
      ? { href: "/dashboard", label: "Customer dashboard" }
      : user.role === "admin"
        ? { href: "/admin", label: "Admin panel" }
        : null;

  return (
    <div className="app-shell">
      <aside className="app-sidebar">
        <div className="px-2">
          <Brand href={area === "admin" ? "/admin" : "/dashboard"} />
        </div>
        <div className="mt-6 flex-1 overflow-y-auto scrollbar-thin">
          <p className="px-2 pb-2 text-[0.62rem] font-semibold uppercase tracking-[0.14em] text-[#89a5b8]">
            {area === "admin" ? "Administration" : "Your account"}
          </p>
          <NavList items={items} pathname={pathname} />
          {otherArea && (
            <Link
              href={otherArea.href}
              className="mt-3 flex items-center gap-1.5 px-3 text-[0.72rem] font-semibold text-[#0a63ff] hover:underline"
            >
              {otherArea.label}
              <ArrowUpRight className="size-3" />
            </Link>
          )}
        </div>

        <div className="mt-4 space-y-2 border-t border-white/70 pt-3">
          <Link
            href="/"
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-[0.72rem] text-mutedblue transition hover:bg-white/60 hover:text-ink"
          >
            <ArrowUpRight className="size-3.5" />
            View the website
          </Link>
          <div className="rounded-xl border border-white/80 bg-white/55 p-2.5">
            <div className="flex items-center gap-2">
              <Avatar name={user.name} src={user.avatarUrl} size={32} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-[0.76rem] font-semibold text-ink">
                  {user.name}
                </p>
                <p className="truncate text-[0.64rem] text-mutedblue">{user.email}</p>
              </div>
            </div>
            <form action={logoutAction} className="mt-2">
              <button
                type="submit"
                className="flex w-full items-center gap-1.5 rounded-lg px-2 py-1.5 text-[0.72rem] font-medium text-[#7a5a5a] transition hover:bg-[#fff1f1] hover:text-[#a13b3b]"
              >
                <LogOut className="size-3.5" />
                Sign out
              </button>
            </form>
          </div>
        </div>
      </aside>

      <div className="min-w-0">
        <header className="sticky top-0 z-30 border-b border-white/60 bg-[rgba(242,250,255,0.78)] backdrop-blur-xl">
          <div className="flex h-14 items-center justify-between gap-3 px-4 sm:px-6">
            <div className="flex min-w-0 items-center gap-2">
              <button
                type="button"
                onClick={() => setOpenAt(pathname)}
                aria-label="Open menu"
                className="grid size-8 place-items-center rounded-lg border border-white/90 bg-white/70 text-ink-soft lg:hidden"
              >
                <Menu className="size-4" />
              </button>
              <div className="lg:hidden">
                <Brand
                  href={area === "admin" ? "/admin" : "/dashboard"}
                  compact
                />
              </div>
              <p className="hidden text-[0.76rem] font-semibold text-ink-soft lg:block">
                {area === "admin" ? "Admin panel" : "Customer dashboard"}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <Link
                href={area === "admin" ? "/admin/tickets" : "/dashboard/support/new"}
                className="btn btn-secondary btn-sm"
              >
                <LifeBuoy className="size-3.5" />
                <span className="hidden sm:inline">Support</span>
              </Link>
              <Link href="/store" className="btn btn-primary btn-sm">
                <Server className="size-3.5" />
                <span className="hidden sm:inline">New server</span>
              </Link>
              <span className="ml-1 hidden sm:block">
                <Avatar name={user.name} src={user.avatarUrl} size={32} />
              </span>
            </div>
          </div>
        </header>

        <main className="px-4 py-6 sm:px-6 lg:px-8">{children}</main>
      </div>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            type="button"
            aria-label="Close menu"
            onClick={() => setOpenAt(null)}
            className="absolute inset-0 bg-[#06233c]/30 backdrop-blur-sm"
          />
          <div className="absolute inset-y-0 left-0 flex w-[82%] max-w-[300px] flex-col overflow-y-auto rounded-r-2xl border-r border-white/80 bg-[#f4fbff] p-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <Brand />
              <button
                type="button"
                onClick={() => setOpenAt(null)}
                aria-label="Close menu"
                className="grid size-8 place-items-center rounded-lg border border-white/90 bg-white/70 text-ink-soft"
              >
                <X className="size-4" />
              </button>
            </div>
            <div className="mt-5">
              <NavList
                items={items}
                pathname={pathname}
                onNavigate={() => setOpenAt(null)}
              />
            </div>
            {otherArea && (
              <Link
                href={otherArea.href}
                onClick={() => setOpenAt(null)}
                className="mt-3 flex items-center gap-1.5 px-3 text-[0.75rem] font-semibold text-[#0a63ff]"
              >
                {otherArea.label}
                <ArrowUpRight className="size-3" />
              </Link>
            )}
            <div className="mt-auto space-y-3 border-t border-white/70 pt-4">
              <Link
                href="/"
                onClick={() => setOpenAt(null)}
                className="flex items-center gap-2 text-[0.76rem] text-mutedblue"
              >
                <ArrowUpRight className="size-3.5" />
                View the website
              </Link>
              <div className="rounded-xl border border-white/80 bg-white/60 p-2.5">
                <div className="flex items-center gap-2">
                  <Avatar name={user.name} src={user.avatarUrl} size={28} />
                  <div className="min-w-0">
                    <p className="truncate text-[0.76rem] font-semibold text-ink">
                      {user.name}
                    </p>
                    <p className="truncate text-[0.64rem] text-mutedblue">
                      {user.email}
                    </p>
                  </div>
                </div>
                <form action={logoutAction} className="mt-2">
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 text-[0.72rem] font-medium text-[#a13b3b]"
                  >
                    <LogOut className="size-3.5" />
                    Sign out
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
