import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  ArrowUpRight,
  CalendarClock,
  ExternalLink,
  Globe2,
  MemoryStick,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  UserRound,
} from "lucide-react";
import { CredentialCard } from "@/components/app/credential-card";
import { ServerNotesForm } from "@/components/app/server-notes-form";
import { StatusPill } from "@/components/status-pill";
import { decryptSecret } from "@/lib/crypto";
import {
  SERVER_STATUS_META,
  cpuLabel,
  dateLabel,
  dateTimeLabel,
  diskLabel,
  ramLabel,
  relativeTime,
} from "@/lib/format";
import {
  getOrderWithUser,
  getPterodactyl,
  getServerById,
  getUserById,
} from "@/lib/queries";
import {
  suspendServerAction,
  syncServerAction,
} from "@/lib/actions/admin";

type PageProps = { params: Promise<{ id: string }> };

// Signed-in route: reads the session on every request and blocks on the
// server by design, so instant-navigation validation is not useful here.
export const instant = false;

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const server = getServerById(id);
  return { title: server?.name ?? "Server" };
}

function prettyJson(raw: string) {
  if (!raw) return "—";
  try {
    return JSON.stringify(JSON.parse(raw), null, 2);
  } catch {
    return raw;
  }
}

export default async function AdminServerPage({ params }: PageProps) {
  await requireAdmin("/admin/servers");
  const { id } = await params;
  const server = getServerById(id);
  if (!server) notFound();

  const customer = getUserById(server.user_id);
  const order = server.order_id ? getOrderWithUser(server.order_id) : undefined;
  const pterodactyl = getPterodactyl();
  const password = decryptSecret(server.panel_password_enc);
  const meta = SERVER_STATUS_META[server.status] ?? SERVER_STATUS_META.offline;
  const address = server.ip
    ? `${server.ip}${server.port ? `:${server.port}` : ""}`
    : "Unassigned";

  return (
    <div className="mx-auto max-w-[1120px]">
      <Link
        href="/admin/servers"
        className="inline-flex items-center gap-1.5 text-[0.74rem] font-medium text-mutedblue transition hover:text-ink"
      >
        <ArrowLeft className="size-3.5" />
        Servers
      </Link>

      <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="display text-[1.7rem] leading-tight text-ink sm:text-[2rem]">
              {server.name}
            </h1>
            <StatusPill label={meta.label} tone={meta.tone} dot />
          </div>
          <p className="mono mt-1.5 text-[0.72rem] text-mutedblue">
            {server.identifier} · {server.region} · created{" "}
            {relativeTime(server.created_at)}
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <form action={syncServerAction}>
            <input type="hidden" name="server_id" value={server.id} />
            <button type="submit" className="btn btn-secondary btn-sm">
              <RefreshCw className="size-3.5" />
              Sync from panel
            </button>
          </form>
          <form action={suspendServerAction}>
            <input type="hidden" name="server_id" value={server.id} />
            <button type="submit" className="btn btn-secondary btn-sm">
              <ShieldAlert className="size-3.5" />
              {server.status === "suspended" ? "Unsuspend" : "Suspend"}
            </button>
          </form>
          <a
            href={pterodactyl.panelUrl}
            target="_blank"
            rel="noreferrer"
            className="btn btn-primary btn-sm"
          >
            Open panel
            <ExternalLink className="size-3.5" />
          </a>
        </div>
      </div>

      <div className="mt-4 grid items-start gap-4 lg:grid-cols-[1.15fr_0.85fr]">
        <div className="space-y-4">
          <section className="glass rounded-2xl p-4">
            <h2 className="text-[0.88rem] font-semibold text-ink">Resources</h2>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
              {[
                { label: "Memory", value: ramLabel(server.ram_mb) },
                { label: "CPU", value: cpuLabel(server.cpu_pct) },
                { label: "Disk", value: diskLabel(server.disk_mb) },
                {
                  label: "Backups",
                  value: `${server.backups} slot${server.backups === 1 ? "" : "s"}`,
                },
                { label: "Databases", value: String(server.databases) },
                { label: "Allocations", value: String(server.allocations) },
              ].map((item) => (
                <div
                  key={item.label}
                  className="rounded-xl border border-white/90 bg-white/55 px-3 py-2.5"
                >
                  <p className="text-[0.62rem] text-mutedblue">{item.label}</p>
                  <p className="mono mt-1 text-[0.8rem] font-semibold text-ink">
                    {item.value}
                  </p>
                </div>
              ))}
            </div>
          </section>

          <section className="glass rounded-2xl p-4">
            <h2 className="text-[0.88rem] font-semibold text-ink">Panel mapping</h2>
            <dl className="mt-3 grid gap-2 text-[0.74rem] sm:grid-cols-2">
              {[
                { label: "Panel server id", value: String(server.panel_server_id ?? "—") },
                { label: "Panel user id", value: String(server.panel_user_id ?? "—") },
                { label: "Nest", value: server.nest_id || "Default" },
                { label: "Egg", value: server.egg_id || "Default" },
                { label: "Node allocation", value: String(server.port ?? "—") },
                { label: "IP", value: server.ip || "—" },
              ].map((row) => (
                <div
                  key={row.label}
                  className="flex items-center justify-between gap-3 rounded-lg border border-white/90 bg-white/50 px-2.5 py-2"
                >
                  <dt className="text-mutedblue">{row.label}</dt>
                  <dd className="mono truncate text-ink" title={row.value}>
                    {row.value}
                  </dd>
                </div>
              ))}
            </dl>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              <div>
                <p className="text-[0.64rem] font-medium text-mutedblue">Startup</p>
                <pre className="console mt-1 max-h-28 overflow-auto rounded-lg p-2 text-[0.66rem]">
                  {server.startup || "—"}
                </pre>
              </div>
              <div>
                <p className="text-[0.64rem] font-medium text-mutedblue">
                  Environment
                </p>
                <pre className="console mt-1 max-h-28 overflow-auto rounded-lg p-2 text-[0.66rem]">
                  {prettyJson(server.environment)}
                </pre>
              </div>
            </div>
          </section>

          <section className="glass rounded-2xl p-4">
            <h2 className="text-[0.88rem] font-semibold text-ink">Internal notes</h2>
            <p className="mt-0.5 text-[0.7rem] text-mutedblue">
              Node history, migrations, anything the next person on support needs.
            </p>
            <ServerNotesForm serverId={server.id} notes={server.notes} />
          </section>
        </div>

        <div className="space-y-4">
          <section className="glass rounded-2xl p-4">
            <h2 className="flex items-center gap-1.5 text-[0.88rem] font-semibold text-ink">
              <UserRound className="size-4 text-[#0a63ff]" />
              Customer
            </h2>
            {customer ? (
              <>
                <p className="mt-2 text-[0.82rem] font-semibold text-ink">
                  {customer.name}
                </p>
                <p className="text-[0.74rem] text-mutedblue">{customer.email}</p>
                <p className="mt-1 text-[0.66rem] text-mutedblue">
                  Joined {dateLabel(customer.created_at)} · {customer.role}
                </p>
                <a
                  href={`mailto:${customer.email}?subject=${encodeURIComponent(
                    `About your server ${server.name}`,
                  )}`}
                  className="btn btn-secondary btn-sm mt-3 w-full"
                >
                  Email customer
                </a>
              </>
            ) : (
              <p className="mt-1.5 text-[0.76rem] text-mutedblue">Customer missing.</p>
            )}
          </section>

          <CredentialCard
            panelUrl={pterodactyl.panelUrl}
            username={server.panel_username}
            password={password}
          />

          {order && (
            <section className="glass rounded-2xl p-4">
              <h2 className="text-[0.88rem] font-semibold text-ink">Billing</h2>
              <dl className="mt-2 space-y-1.5 text-[0.74rem]">
                <div className="flex justify-between gap-3">
                  <dt className="text-mutedblue">Order</dt>
                  <dd className="truncate text-ink">{order.item_name}</dd>
                </div>
                <div className="flex justify-between gap-3">
                  <dt className="text-mutedblue">Renews</dt>
                  <dd className="text-ink">
                    {server.renewal_at ? dateLabel(server.renewal_at) : "—"}
                  </dd>
                </div>
                <div className="flex justify-between gap-3">
                  <dt className="text-mutedblue">Paid</dt>
                  <dd className="text-ink">
                    {order.paid_at ? dateTimeLabel(order.paid_at) : "No"}
                  </dd>
                </div>
              </dl>
              <Link
                href={`/admin/orders/${order.id}`}
                className="mt-3 inline-flex items-center gap-1 text-[0.74rem] font-semibold text-[#0a63ff] hover:underline"
              >
                Open order
                <ArrowUpRight className="size-3" />
              </Link>
            </section>
          )}

          <section className="glass-quiet rounded-2xl p-4 text-[0.72rem] leading-relaxed text-ink-soft/85">
            <p className="flex items-center gap-1.5 font-semibold text-ink">
              <Globe2 className="size-3.5 text-[#0a63ff]" />
              Address
            </p>
            <p className="mono mt-0.5">{address}</p>
            <p className="mt-2 flex items-center gap-1.5 font-semibold text-ink">
              <CalendarClock className="size-3.5 text-[#0a63ff]" />
              Last sync
            </p>
            <p className="mt-0.5">
              {server.last_synced_at
                ? dateTimeLabel(server.last_synced_at)
                : "Never synced"}
            </p>
            <p className="mt-2 flex items-center gap-1.5 font-semibold text-ink">
              <MemoryStick className="size-3.5 text-[#0a63ff]" />
              Protection
            </p>
            <p className="mt-0.5 flex items-center gap-1">
              <ShieldCheck className="size-3 text-[#0a63ff]" />
              Game-aware DDoS filtering
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
