import type { Metadata } from "next";
import { LegalPage } from "@/components/legal-page";
import { getSite } from "@/lib/queries";

export const metadata: Metadata = {
  title: "Terms of service",
  description:
    "The agreement between you and Volt Hosting for game server hosting: accounts, billing, acceptable use, backups and refunds.",
};

export default function TermsPage() {
  const site = getSite();
  const name = site.siteName;

  return (
    <LegalPage
      title="Terms of service"
      updated="27 November 2026"
      intro={`These terms cover your account and every service you buy from ${name}. By creating an account or paying an invoice, you agree to them.`}
      sections={[
        {
          id: "agreement",
          title: "This agreement",
          paragraphs: [
            `These terms are a contract between you and ${name} ("we", "us"). They apply from the moment you create an account, place an order, or use a server we operate. If you are agreeing on behalf of a community or company, you confirm you are allowed to do so.`,
            "We may update these terms as the service changes. Material changes will be announced by email or in the dashboard before they take effect. Continuing to use the service after that date means you accept the updated terms.",
          ],
        },
        {
          id: "accounts",
          title: "Accounts and security",
          bullets: [
            "Give accurate information and keep your email address current — it is where credentials and invoices go.",
            "You are responsible for activity under your account. Use a unique password and do not share your panel login.",
            "One account per person. Automated signups, disposable addresses and account farming are not allowed.",
            "Tell us immediately if you believe your account or panel access was compromised.",
          ],
        },
        {
          id: "orders",
          title: "Orders, pricing and renewal",
          paragraphs: [
            "Prices are shown in USD and exclude any tax your jurisdiction adds at checkout. An order is an offer to buy; the contract forms when payment is confirmed and provisioning begins.",
            "Plans renew automatically at the end of each billing term. Quarterly and yearly terms are charged up front and priced with the discount displayed at checkout. You can cancel renewal at any time from the dashboard; cancellation stops the next invoice and does not refund the current term.",
          ],
        },
        {
          id: "provisioning",
          title: "Provisioning and panel access",
          paragraphs: [
            "Paid orders are provisioned automatically. Panel credentials are generated for your account and emailed to the address on file. Typically the server is installing within 90 seconds; if your chosen region is at capacity we will place you on the next node and tell you the ETA.",
            "You must not resell panel access or share a single server between unrelated paying customers without our written agreement.",
          ],
        },
        {
          id: "acceptable-use",
          title: "Acceptable use",
          paragraphs: [
            "Our network is built for game servers and the communities around them. The following are not allowed on any plan:",
          ],
          bullets: [
            "Attacking, scanning or flooding third parties, or hosting material that does so.",
            "Crypto mining, password cracking, botnets, malware distribution, phishing or fraud.",
            "Illegal content, including content that sexualises minors, or content that infringes another person's rights.",
            "Unsolicited bulk email, scraping that degrades another service, or evading another platform's rate limits.",
            "Deliberately exhausting shared infrastructure in a way that affects other customers.",
          ],
        },
        {
          id: "backups",
          title: "Backups and your data",
          paragraphs: [
            "Plans include a number of backup slots. Backups are a convenience, not a guarantee: keep your own copies of worlds, databases and configuration that matter to you, and export them before a wipe or migration.",
            "You own your content. You grant us the limited licence needed to store, transmit and back it up so we can run the service. We do not inspect game data except where needed to resolve a ticket, investigate abuse, or comply with law.",
          ],
        },
        {
          id: "refunds",
          title: "Refunds and cancellations",
          paragraphs: [
            "New game server purchases are covered by a 72-hour first-purchase guarantee. Open a billing ticket within 72 hours of the first invoice and we will refund it. Renewals, add-ons after the first invoice, and accounts suspended for abuse are not covered.",
            "If we cancel a plan for reasons other than your breach, we refund the unused portion of the current term on request.",
          ],
        },
        {
          id: "availability",
          title: "Availability and support",
          paragraphs: [
            "We target 99.99% network availability and publish current conditions on the status page. Planned maintenance is announced in advance where practical. Catalog plans do not carry a contractual SLA or service credits; if you need one, talk to us about a custom agreement.",
            "Support is provided by ticket, email and Discord under the response targets published on the support page. Those targets are goals, not guarantees, and do not apply during a declared major incident when the team is focused on recovery.",
          ],
        },
        {
          id: "suspension",
          title: "Suspension and termination",
          paragraphs: [
            "We may suspend a server or account immediately if it poses a security risk, is the subject of a credible abuse report, or is used in breach of these terms. Where the situation allows, we will contact you first and give you a chance to fix it.",
            "If you cancel, your server is stopped at the end of the paid term. We keep the data for seven days so you can export it, then delete it. You can request an export at any time before deletion.",
          ],
        },
        {
          id: "liability",
          title: "Liability",
          paragraphs: [
            "The service is provided as it is. To the extent the law allows, we exclude implied warranties and are not liable for lost profits, lost data, or indirect and consequential loss. Our total liability for any claim is limited to the fees you paid us in the three months before the event giving rise to it.",
            "Nothing in these terms limits liability that cannot lawfully be limited, including for fraud or death or personal injury caused by negligence.",
          ],
        },
        {
          id: "contact",
          title: "Contact",
          paragraphs: [
            `Questions about these terms, a refund, or a legal request: ${site.supportEmail}. For account-specific issues, a support ticket reaches the team fastest.`,
          ],
        },
      ]}
      footer={
        <>
          <p className="font-semibold text-[#083f72]">A note on plain language</p>
          <p className="mt-1.5">
            This is a real agreement, but it is written to be read. If a clause
            is unclear, ask us before you buy — we would rather explain it than
            have you agree to something you did not understand.
          </p>
        </>
      }
    />
  );
}
