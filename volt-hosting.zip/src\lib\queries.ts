import { db } from "./db";
import {
  DISCORD_DEFAULTS,
  PAYMENT_DEFAULTS,
  PRICING_DEFAULTS,
  PTERODACTYL_DEFAULTS,
  SITE_DEFAULTS,
  SMTP_DEFAULTS,
} from "./defaults";
import type {
  CategoryRow,
  DiscordSettings,
  GatewayRow,
  OrderRow,
  OrderWithUser,
  PaymentSettings,
  PricingSettings,
  ProductWithCategory,
  PromoCodeRow,
  PterodactylSettings,
  ServerRow,
  SiteSettings,
  SmtpSettings,
  TicketMessageRow,
  TicketWithUser,
  UserRow,
} from "./types";

export function getSetting<T>(key: string, fallback: T): T {
  const row = db.prepare("SELECT value FROM settings WHERE key = ?").get(key) as
    | { value: string }
    | undefined;
  if (!row) return fallback;
  try {
    return JSON.parse(row.value) as T;
  } catch {
    return fallback;
  }
}

export function setSetting(key: string, value: unknown) {
  db.prepare(
    "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
  ).run(key, JSON.stringify(value));
}

export const getSite = (): SiteSettings => ({
  ...SITE_DEFAULTS,
  ...getSetting<Partial<SiteSettings>>("site", {}),
});
export const getPricing = (): PricingSettings => ({
  ...PRICING_DEFAULTS,
  ...getSetting<Partial<PricingSettings>>("pricing", {}),
});
export const getPterodactyl = (): PterodactylSettings => ({
  ...PTERODACTYL_DEFAULTS,
  ...getSetting<Partial<PterodactylSettings>>("pterodactyl", {}),
});
export const getSmtp = (): SmtpSettings => ({
  ...SMTP_DEFAULTS,
  ...getSetting<Partial<SmtpSettings>>("smtp", {}),
});
export const getDiscord = (): DiscordSettings => ({
  ...DISCORD_DEFAULTS,
  ...getSetting<Partial<DiscordSettings>>("discord", {}),
});
export const getPayments = (): PaymentSettings => ({
  ...PAYMENT_DEFAULTS,
  ...getSetting<Partial<PaymentSettings>>("payments", {}),
});

export function getPromoCodes(): PromoCodeRow[] {
  return db
    .prepare("SELECT * FROM promo_codes ORDER BY active DESC, created_at DESC")
    .all() as PromoCodeRow[];
}

export function getPromoCodeById(id: string): PromoCodeRow | undefined {
  return db.prepare("SELECT * FROM promo_codes WHERE id = ?").get(id) as
    | PromoCodeRow
    | undefined;
}

export function getCategories(options?: {
  activeOnly?: boolean;
}): CategoryRow[] {
  const sql = options?.activeOnly
    ? "SELECT * FROM categories WHERE active = 1 ORDER BY sort_order, name"
    : "SELECT * FROM categories ORDER BY sort_order, name";
  return db.prepare(sql).all() as CategoryRow[];
}

export function getCategoryBySlug(slug: string): CategoryRow | undefined {
  return db
    .prepare("SELECT * FROM categories WHERE slug = ?")
    .get(slug) as CategoryRow | undefined;
}

export function getCategoryById(id: string): CategoryRow | undefined {
  return db
    .prepare("SELECT * FROM categories WHERE id = ?")
    .get(id) as CategoryRow | undefined;
}

const PRODUCT_SELECT = `
  SELECT p.*, c.name AS category_name, c.slug AS category_slug,
         c.icon AS category_icon, c.accent AS category_accent
  FROM products p
  JOIN categories c ON c.id = p.category_id
`;

export function getProducts(options?: {
  activeOnly?: boolean;
  categoryId?: string;
  categorySlug?: string;
  limit?: number;
}): ProductWithCategory[] {
  const where: string[] = [];
  const params: (string | number)[] = [];
  if (options?.activeOnly) where.push("p.active = 1", "c.active = 1");
  if (options?.categoryId) {
    where.push("p.category_id = ?");
    params.push(options.categoryId);
  }
  if (options?.categorySlug) {
    where.push("c.slug = ?");
    params.push(options.categorySlug);
  }
  let sql = PRODUCT_SELECT;
  if (where.length) sql += ` WHERE ${where.join(" AND ")}`;
  sql += " ORDER BY c.sort_order, p.sort_order, p.price_cents";
  if (options?.limit) sql += " LIMIT ?";
  if (options?.limit) params.push(options.limit);
  return db.prepare(sql).all(...params) as ProductWithCategory[];
}

export function getFeaturedProducts(): ProductWithCategory[] {
  return db
    .prepare(
      `${PRODUCT_SELECT} WHERE p.active = 1 AND c.active = 1 ORDER BY p.popular DESC, p.sort_order LIMIT 3`,
    )
    .all() as ProductWithCategory[];
}

export function getProductBySlug(
  slug: string,
): ProductWithCategory | undefined {
  return db
    .prepare(`${PRODUCT_SELECT} WHERE p.slug = ?`)
    .get(slug) as ProductWithCategory | undefined;
}

export function getProductById(
  id: string,
): ProductWithCategory | undefined {
  return db
    .prepare(`${PRODUCT_SELECT} WHERE p.id = ?`)
    .get(id) as ProductWithCategory | undefined;
}

export function getGateways(options?: { enabledOnly?: boolean }): GatewayRow[] {
  const sql = options?.enabledOnly
    ? "SELECT * FROM gateways WHERE enabled = 1 ORDER BY sort_order, name"
    : "SELECT * FROM gateways ORDER BY sort_order, name";
  return db.prepare(sql).all() as GatewayRow[];
}

export function getGatewayById(id: string): GatewayRow | undefined {
  return db
    .prepare("SELECT * FROM gateways WHERE id = ?")
    .get(id) as GatewayRow | undefined;
}

export function getUserByEmail(email: string): UserRow | undefined {
  return db
    .prepare("SELECT * FROM users WHERE email = ? COLLATE NOCASE")
    .get(email) as UserRow | undefined;
}

export function getUserById(id: string): UserRow | undefined {
  return db.prepare("SELECT * FROM users WHERE id = ?").get(id) as
    | UserRow
    | undefined;
}

export function getUsers(): UserRow[] {
  return db
    .prepare("SELECT * FROM users ORDER BY created_at DESC")
    .all() as UserRow[];
}

export function getOrdersForUser(userId: string): OrderRow[] {
  return db
    .prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC")
    .all(userId) as OrderRow[];
}

export function getOrderById(id: string): OrderRow | undefined {
  return db.prepare("SELECT * FROM orders WHERE id = ?").get(id) as
    | OrderRow
    | undefined;
}

export function getOrderWithUser(id: string): OrderWithUser | undefined {
  return db
    .prepare(
      `SELECT o.*, u.name AS user_name, u.email AS user_email, g.name AS gateway_name
       FROM orders o
       JOIN users u ON u.id = o.user_id
       LEFT JOIN gateways g ON g.id = o.gateway_id
       WHERE o.id = ?`,
    )
    .get(id) as OrderWithUser | undefined;
}

export function getAllOrders(limit = 100): OrderWithUser[] {
  return db
    .prepare(
      `SELECT o.*, u.name AS user_name, u.email AS user_email, g.name AS gateway_name
       FROM orders o
       JOIN users u ON u.id = o.user_id
       LEFT JOIN gateways g ON g.id = o.gateway_id
       ORDER BY o.created_at DESC LIMIT ?`,
    )
    .all(limit) as OrderWithUser[];
}

export function getServersForUser(userId: string): ServerRow[] {
  return db
    .prepare("SELECT * FROM servers WHERE user_id = ? ORDER BY created_at DESC")
    .all(userId) as ServerRow[];
}

export function getAllServers(): (ServerRow & { user_name: string; user_email: string })[] {
  return db
    .prepare(
      `SELECT s.*, u.name AS user_name, u.email AS user_email
       FROM servers s JOIN users u ON u.id = s.user_id
       ORDER BY s.created_at DESC`,
    )
    .all() as (ServerRow & { user_name: string; user_email: string })[];
}

export function getServerById(id: string): ServerRow | undefined {
  return db.prepare("SELECT * FROM servers WHERE id = ?").get(id) as
    | ServerRow
    | undefined;
}

export function getServerByOrderId(orderId: string): ServerRow | undefined {
  return db
    .prepare("SELECT * FROM servers WHERE order_id = ?")
    .get(orderId) as ServerRow | undefined;
}

export function getServerForUser(
  id: string,
  userId: string,
): ServerRow | undefined {
  return db
    .prepare("SELECT * FROM servers WHERE id = ? AND user_id = ?")
    .get(id, userId) as ServerRow | undefined;
}

export function getTicketsForUser(userId: string): TicketWithUser[] {
  return db
    .prepare(
      `SELECT t.*, u.name AS user_name, u.email AS user_email,
        (SELECT COUNT(*) FROM ticket_messages m WHERE m.ticket_id = t.id) AS message_count
       FROM tickets t JOIN users u ON u.id = t.user_id
       WHERE t.user_id = ?
       ORDER BY t.updated_at DESC`,
    )
    .all(userId) as TicketWithUser[];
}

export function getAllTickets(): TicketWithUser[] {
  return db
    .prepare(
      `SELECT t.*, u.name AS user_name, u.email AS user_email,
        (SELECT COUNT(*) FROM ticket_messages m WHERE m.ticket_id = t.id) AS message_count
       FROM tickets t JOIN users u ON u.id = t.user_id
       ORDER BY CASE t.status WHEN 'open' THEN 0 WHEN 'answered' THEN 1 ELSE 2 END, t.updated_at DESC`,
    )
    .all() as TicketWithUser[];
}

export function getTicketById(id: string): TicketWithUser | undefined {
  return db
    .prepare(
      `SELECT t.*, u.name AS user_name, u.email AS user_email,
        (SELECT COUNT(*) FROM ticket_messages m WHERE m.ticket_id = t.id) AS message_count
       FROM tickets t JOIN users u ON u.id = t.user_id
       WHERE t.id = ?`,
    )
    .get(id) as TicketWithUser | undefined;
}

export function getTicketMessages(ticketId: string): TicketMessageRow[] {
  return db
    .prepare(
      "SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY created_at ASC",
    )
    .all(ticketId) as TicketMessageRow[];
}

export function getAdminStats() {
  const users = (
    db.prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'customer'").get() as {
      n: number;
    }
  ).n;
  const servers = (
    db
      .prepare("SELECT COUNT(*) AS n FROM servers WHERE status != 'failed'")
      .get() as { n: number }
  ).n;
  const openTickets = (
    db
      .prepare(
        "SELECT COUNT(*) AS n FROM tickets WHERE status != 'closed'",
      )
      .get() as { n: number }
  ).n;
  const revenue = (
    db
      .prepare(
        "SELECT COALESCE(SUM(amount_cents), 0) AS n FROM orders WHERE paid_at IS NOT NULL AND status != 'refunded'",
      )
      .get() as { n: number }
  ).n;
  const pendingOrders = (
    db
      .prepare("SELECT COUNT(*) AS n FROM orders WHERE status = 'pending'")
      .get() as { n: number }
  ).n;

  return { users, servers, openTickets, revenue, pendingOrders };
}

export function getRevenueByDay(days = 7): { day: string; cents: number }[] {
  const rows = db
    .prepare(
      `SELECT substr(paid_at, 1, 10) AS day, SUM(amount_cents) AS cents
       FROM orders
       WHERE paid_at IS NOT NULL AND paid_at >= ?
       GROUP BY day ORDER BY day ASC`,
    )
    .all(new Date(Date.now() - days * 86_400_000).toISOString()) as {
    day: string;
    cents: number;
  }[];
  return rows;
}

export function getRecentSignups(limit = 5): UserRow[] {
  return db
    .prepare(
      "SELECT * FROM users WHERE role = 'customer' ORDER BY created_at DESC LIMIT ?",
    )
    .all(limit) as UserRow[];
}

export function getEmailLog(limit = 50) {
  return db
    .prepare("SELECT * FROM email_log ORDER BY created_at DESC LIMIT ?")
    .all(limit) as {
    id: string;
    to_email: string;
    subject: string;
    status: string;
    error: string | null;
    created_at: string;
  }[];
}

export function getPlatformCounts() {
  return {
    categories: (
      db.prepare("SELECT COUNT(*) AS n FROM categories").get() as { n: number }
    ).n,
    products: (
      db.prepare("SELECT COUNT(*) AS n FROM products").get() as { n: number }
    ).n,
    gateways: (
      db.prepare("SELECT COUNT(*) AS n FROM gateways").get() as { n: number }
    ).n,
  };
}
